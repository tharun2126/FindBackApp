-- FindBack Database Schema
-- AI-Powered Lost-and-Found Item Matching System

-- Create database
CREATE DATABASE IF NOT EXISTS findback;
USE findback;

-- Drop tables if they exist (for clean setup)
DROP TABLE IF EXISTS notifications;
DROP TABLE IF EXISTS claims;
DROP TABLE IF EXISTS matches;
DROP TABLE IF EXISTS found_items;
DROP TABLE IF EXISTS lost_items;
DROP TABLE IF EXISTS users;

-- Users table
CREATE TABLE users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    role ENUM('USER', 'ADMIN') DEFAULT 'USER',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_username (username),
    INDEX idx_email (email),
    INDEX idx_role (role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Lost items table
CREATE TABLE lost_items (
    lost_item_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    category VARCHAR(50) NOT NULL,
    brand VARCHAR(100),
    colour VARCHAR(50),
    description TEXT NOT NULL,
    location_lost VARCHAR(255) NOT NULL,
    date_lost DATETIME NOT NULL,
    image_path VARCHAR(255),
    status ENUM('ACTIVE', 'RESOLVED') DEFAULT 'ACTIVE',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    INDEX idx_lost_items_user (user_id),
    INDEX idx_lost_items_category (category),
    INDEX idx_lost_items_status (status),
    INDEX idx_lost_items_date (date_lost)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Found items table
CREATE TABLE found_items (
    found_item_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    category VARCHAR(50) NOT NULL,
    brand VARCHAR(100),
    colour VARCHAR(50),
    description TEXT NOT NULL,
    location_found VARCHAR(255) NOT NULL,
    date_found DATETIME NOT NULL,
    image_path VARCHAR(255),
    status ENUM('ACTIVE', 'RESOLVED') DEFAULT 'ACTIVE',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    INDEX idx_found_items_user (user_id),
    INDEX idx_found_items_category (category),
    INDEX idx_found_items_status (status),
    INDEX idx_found_items_date (date_found)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Matches table (AI-generated matches)
CREATE TABLE matches (
    match_id INT PRIMARY KEY AUTO_INCREMENT,
    lost_item_id INT NOT NULL,
    found_item_id INT NOT NULL,
    semantic_similarity_score DECIMAL(5,4),
    image_similarity_score DECIMAL(5,4),
    attribute_similarity_score DECIMAL(5,4),
    overall_confidence_score DECIMAL(5,4) NOT NULL,
    match_status ENUM('PENDING', 'REVIEWED', 'CONFIRMED', 'REJECTED') DEFAULT 'PENDING',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (lost_item_id) REFERENCES lost_items(lost_item_id) ON DELETE CASCADE,
    FOREIGN KEY (found_item_id) REFERENCES found_items(found_item_id) ON DELETE CASCADE,
    UNIQUE KEY unique_match (lost_item_id, found_item_id),
    INDEX idx_matches_lost (lost_item_id),
    INDEX idx_matches_found (found_item_id),
    INDEX idx_matches_status (match_status),
    INDEX idx_matches_confidence (overall_confidence_score)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Claims table (user claims on matched items)
CREATE TABLE claims (
    claim_id INT PRIMARY KEY AUTO_INCREMENT,
    match_id INT NOT NULL,
    user_id INT NOT NULL,
    claim_status ENUM('PENDING', 'UNDER_REVIEW', 'VERIFIED', 'REJECTED') DEFAULT 'PENDING',
    verification_notes TEXT,
    admin_id INT,
    verified_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (match_id) REFERENCES matches(match_id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (admin_id) REFERENCES users(user_id) ON DELETE SET NULL,
    INDEX idx_claims_user (user_id),
    INDEX idx_claims_status (claim_status),
    INDEX idx_claims_match (match_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Notifications table (in-app notifications)
CREATE TABLE notifications (
    notification_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    notification_type ENUM('MATCH_FOUND', 'CLAIM_STATUS', 'ITEM_RETURNED', 'SYSTEM') NOT NULL,
    related_match_id INT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (related_match_id) REFERENCES matches(match_id) ON DELETE SET NULL,
    INDEX idx_notifications_user (user_id),
    INDEX idx_notifications_read (is_read),
    INDEX idx_notifications_type (notification_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert default admin user (password: admin123 - hashed with BCrypt)
INSERT INTO users (username, email, password_hash, full_name, phone, role)
VALUES ('admin', 'admin@findback.com', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'System Administrator', '0000000000', 'ADMIN');

-- Display schema creation summary
SELECT 'Database schema created successfully' AS status;
SELECT COUNT(*) AS user_count FROM users;
SELECT COUNT(*) AS lost_item_count FROM lost_items;
SELECT COUNT(*) AS found_item_count FROM found_items;
SELECT COUNT(*) AS match_count FROM matches;
SELECT COUNT(*) AS claim_count FROM claims;
SELECT COUNT(*) AS notification_count FROM notifications;
