package com.findback.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Database configuration class for managing database connections.
 * 
 * This class loads database configuration from properties file and provides
 * methods to establish database connections using JDBC.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public class DatabaseConfig {
    
    private static final Logger logger = LoggerFactory.getLogger(DatabaseConfig.class);
    
    private static final String CONFIG_FILE = "config.properties";
    private static Properties properties;
    
    // Default database configuration values
    private static final String DEFAULT_URL = "jdbc:mysql://localhost:3306/findback";
    private static final String DEFAULT_USERNAME = "root";
    private static final String DEFAULT_PASSWORD = "";
    private static final String DEFAULT_DRIVER = "com.mysql.cj.jdbc.Driver";
    
    private static boolean initialized = false;
    
    /**
     * Private constructor to prevent instantiation.
     */
    private DatabaseConfig() {
        throw new AssertionError("DatabaseConfig class should not be instantiated");
    }
    
    /**
     * Initialize the database configuration by loading properties from config file.
     * If config file is not found, uses default values.
     */
    public static void initialize() {
        if (initialized) {
            logger.warn("DatabaseConfig already initialized");
            return;
        }
        
        properties = new Properties();
        
        try (InputStream input = DatabaseConfig.class.getClassLoader()
                .getResourceAsStream(CONFIG_FILE)) {
            
            if (input == null) {
                logger.warn("Config file '{}' not found in classpath. Using default values.", CONFIG_FILE);
                setDefaultProperties();
            } else {
                properties.load(input);
                logger.info("Database configuration loaded from '{}'", CONFIG_FILE);
            }
            
            initialized = true;
            logger.info("DatabaseConfig initialized successfully");
            
            // Test database connection
            testConnection();
            
        } catch (IOException e) {
            logger.error("Error loading configuration file", e);
            setDefaultProperties();
            initialized = true;
            testConnection();
        }
    }
    
    /**
     * Set default database configuration properties.
     */
    private static void setDefaultProperties() {
        properties.setProperty("db.url", DEFAULT_URL);
        properties.setProperty("db.username", DEFAULT_USERNAME);
        properties.setProperty("db.password", DEFAULT_PASSWORD);
        properties.setProperty("db.driver", DEFAULT_DRIVER);
        logger.info("Using default database configuration");
    }
    
    /**
     * Test database connection to verify configuration.
     */
    private static void testConnection() {
        try (Connection connection = getConnection()) {
            logger.info("Database connection test successful");
        } catch (SQLException e) {
            logger.warn("Database connection test failed: {}", e.getMessage());
            logger.warn("Please ensure MySQL is running and database 'findback' exists");
        } catch (Exception e) {
            logger.warn("Unexpected error during connection test: {}", e.getMessage());
        }
    }
    
    /**
     * Get a new database connection.
     * 
     * @return A new JDBC Connection object
     * @throws SQLException if connection fails
     */
    public static Connection getConnection() throws SQLException {
        if (!initialized) {
            initialize();
        }
        
        String url = properties.getProperty("db.url");
        String username = properties.getProperty("db.username");
        String password = properties.getProperty("db.password");
        
        try {
            Class.forName(properties.getProperty("db.driver"));
        } catch (ClassNotFoundException e) {
            logger.error("JDBC Driver not found", e);
            throw new SQLException("JDBC Driver not found: " + e.getMessage());
        }
        
        return DriverManager.getConnection(url, username, password);
    }
    
    /**
     * Get database URL.
     * 
     * @return Database URL
     */
    public static String getDatabaseUrl() {
        return properties.getProperty("db.url");
    }
    
    /**
     * Get database username.
     * 
     * @return Database username
     */
    public static String getDatabaseUsername() {
        return properties.getProperty("db.username");
    }
    
    /**
     * Get database password.
     * 
     * @return Database password
     */
    public static String getDatabasePassword() {
        return properties.getProperty("db.password");
    }
    
    /**
     * Check if configuration is initialized.
     * 
     * @return true if initialized, false otherwise
     */
    public static boolean isInitialized() {
        return initialized;
    }
}
