package com.findback.ai;

import java.time.LocalDateTime;

/**
 * Service interface for attribute similarity calculation.
 * 
 * Defines the contract for calculating similarity between item attributes
 * such as category, brand, colour, location, and date/time.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public interface AttributeSimilarityService {
    
    /**
     * Calculate attribute similarity between two sets of item attributes.
     * 
     * @param category1 the first item's category
     * @param brand1 the first item's brand
     * @param colour1 the first item's colour
     * @param location1 the first item's location
     * @param date1 the first item's date/time
     * @param category2 the second item's category
     * @param brand2 the second item's brand
     * @param colour2 the second item's colour
     * @param location2 the second item's location
     * @param date2 the second item's date/time
     * @return similarity score between 0.0 and 1.0
     */
    double calculateSimilarity(String category1, String brand1, String colour1, 
                               String location1, LocalDateTime date1,
                               String category2, String brand2, String colour2, 
                               String location2, LocalDateTime date2);
}
