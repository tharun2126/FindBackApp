package com.findback.ai.impl;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Cosine similarity calculator for TF-IDF vectors.
 * 
 * Calculates the cosine similarity between two vectors, which measures
 * the cosine of the angle between them.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public class CosineSimilarity {
    
    /**
     * Calculate cosine similarity between two vectors.
     * 
     * @param vector1 the first vector (map of term to score)
     * @param vector2 the second vector (map of term to score)
     * @return similarity score between 0.0 and 1.0
     */
    public static double calculateSimilarity(Map<String, Double> vector1, Map<String, Double> vector2) {
        if (vector1 == null || vector2 == null || vector1.isEmpty() || vector2.isEmpty()) {
            return 0.0;
        }
        
        // Calculate dot product
        double dotProduct = 0.0;
        for (String term : vector1.keySet()) {
            if (vector2.containsKey(term)) {
                dotProduct += vector1.get(term) * vector2.get(term);
            }
        }
        
        // Calculate magnitudes
        double magnitude1 = calculateMagnitude(vector1);
        double magnitude2 = calculateMagnitude(vector2);
        
        if (magnitude1 == 0.0 || magnitude2 == 0.0) {
            return 0.0;
        }
        
        // Calculate cosine similarity
        double similarity = dotProduct / (magnitude1 * magnitude2);
        
        // Ensure result is between 0 and 1
        return Math.max(0.0, Math.min(1.0, similarity));
    }
    
    /**
     * Calculate the magnitude (Euclidean norm) of a vector.
     * 
     * @param vector the vector
     * @return the magnitude
     */
    private static double calculateMagnitude(Map<String, Double> vector) {
        double sumSquares = 0.0;
        for (double value : vector.values()) {
            sumSquares += value * value;
        }
        return Math.sqrt(sumSquares);
    }
    
    /**
     * Calculate cosine similarity between two text documents.
     * 
     * Uses a simplified approach with term frequency vectors for pairwise comparison.
     * 
     * @param text1 the first text
     * @param text2 the second text
     * @return similarity score between 0.0 and 1.0
     */
    public static double calculateTextSimilarity(String text1, String text2) {
        if (text1 == null || text2 == null || text1.trim().isEmpty() || text2.trim().isEmpty()) {
            return 0.0;
        }
        
        // Normalize texts
        String normalized1 = text1.toLowerCase().replaceAll("[^a-zA-Z0-9\\s]", " ").replaceAll("\\s+", " ").trim();
        String normalized2 = text2.toLowerCase().replaceAll("[^a-zA-Z0-9\\s]", " ").replaceAll("\\s+", " ").trim();
        
        if (normalized1.isEmpty() || normalized2.isEmpty()) {
            return 0.0;
        }
        
        // Split into words
        String[] words1 = normalized1.split("\\s+");
        String[] words2 = normalized2.split("\\s+");
        
        // Build term frequency maps
        java.util.Map<String, Integer> tf1 = new java.util.HashMap<>();
        java.util.Map<String, Integer> tf2 = new java.util.HashMap<>();
        
        for (String word : words1) {
            if (word.length() > 1) {
                tf1.put(word, tf1.getOrDefault(word, 0) + 1);
            }
        }
        
        for (String word : words2) {
            if (word.length() > 1) {
                tf2.put(word, tf2.getOrDefault(word, 0) + 1);
            }
        }
        
        // Get all unique terms
        java.util.Set<String> allTerms = new java.util.HashSet<>();
        allTerms.addAll(tf1.keySet());
        allTerms.addAll(tf2.keySet());
        
        // Calculate dot product and magnitudes
        double dotProduct = 0.0;
        double magnitude1 = 0.0;
        double magnitude2 = 0.0;
        
        for (String term : allTerms) {
            int count1 = tf1.getOrDefault(term, 0);
            int count2 = tf2.getOrDefault(term, 0);
            
            dotProduct += count1 * count2;
            magnitude1 += count1 * count1;
            magnitude2 += count2 * count2;
        }
        
        if (magnitude1 == 0.0 || magnitude2 == 0.0) {
            return 0.0;
        }
        
        double similarity = dotProduct / (Math.sqrt(magnitude1) * Math.sqrt(magnitude2));
        return Math.max(0.0, Math.min(1.0, similarity));
    }
}
