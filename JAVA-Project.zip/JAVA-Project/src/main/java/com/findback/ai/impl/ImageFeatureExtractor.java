package com.findback.ai.impl;

import java.awt.image.BufferedImage;
import java.awt.Color;

/**
 * Extracts color histogram features from images for similarity comparison.
 * 
 * Uses RGB color space with configurable bin sizes for histogram generation.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public class ImageFeatureExtractor {
    
    private static final int BIN_SIZE = 32; // Number of bins per color channel
    
    /**
     * Extract RGB color histogram from an image.
     * 
     * @param image the image to extract features from
     * @return 3D histogram array [red_bins][green_bins][blue_bins]
     */
    public static double[][][] extractHistogram(BufferedImage image) {
        if (image == null) {
            return new double[BIN_SIZE][BIN_SIZE][BIN_SIZE];
        }
        
        double[][][] histogram = new double[BIN_SIZE][BIN_SIZE][BIN_SIZE];
        int width = image.getWidth();
        int height = image.getHeight();
        int totalPixels = width * height;
        
        // Sample pixels (for performance, sample every 10th pixel if image is large)
        int step = Math.max(1, totalPixels / 10000);
        
        for (int y = 0; y < height; y += step) {
            for (int x = 0; x < width; x += step) {
                Color color = new Color(image.getRGB(x, y));
                
                int redBin = color.getRed() / (256 / BIN_SIZE);
                int greenBin = color.getGreen() / (256 / BIN_SIZE);
                int blueBin = color.getBlue() / (256 / BIN_SIZE);
                
                // Clamp to valid range
                redBin = Math.min(BIN_SIZE - 1, redBin);
                greenBin = Math.min(BIN_SIZE - 1, greenBin);
                blueBin = Math.min(BIN_SIZE - 1, blueBin);
                
                histogram[redBin][greenBin][blueBin]++;
            }
        }
        
        // Normalize histogram
        for (int r = 0; r < BIN_SIZE; r++) {
            for (int g = 0; g < BIN_SIZE; g++) {
                for (int b = 0; b < BIN_SIZE; b++) {
                    histogram[r][g][b] /= totalPixels;
                }
            }
        }
        
        return histogram;
    }
    
    /**
     * Extract a simplified 1D histogram (concatenated RGB).
     * 
     * @param image the image to extract features from
     * @return 1D histogram array
     */
    public static double[] extractFlatHistogram(BufferedImage image) {
        if (image == null) {
            return new double[BIN_SIZE * 3];
        }
        
        double[][][] histogram3D = extractHistogram(image);
        double[] flatHistogram = new double[BIN_SIZE * 3];
        
        // Concatenate RGB histograms
        for (int i = 0; i < BIN_SIZE; i++) {
            // Sum across green and blue for red channel
            double redSum = 0;
            double greenSum = 0;
            double blueSum = 0;
            
            for (int j = 0; j < BIN_SIZE; j++) {
                for (int k = 0; k < BIN_SIZE; k++) {
                    redSum += histogram3D[i][j][k];
                    greenSum += histogram3D[j][i][k];
                    blueSum += histogram3D[j][k][i];
                }
            }
            
            flatHistogram[i] = redSum;
            flatHistogram[BIN_SIZE + i] = greenSum;
            flatHistogram[BIN_SIZE * 2 + i] = blueSum;
        }
        
        return flatHistogram;
    }
}
