package com.findback.ai.impl;

import com.findback.ai.ImageSimilarityService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

/**
 * Implementation of ImageSimilarityService using color histogram comparison.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public class ImageSimilarityServiceImpl implements ImageSimilarityService {
    
    private static final Logger logger = LoggerFactory.getLogger(ImageSimilarityServiceImpl.class);
    
    @Override
    public double calculateSimilarity(BufferedImage image1, BufferedImage image2) {
        logger.debug("Calculating image similarity between two BufferedImages");
        
        if (image1 == null || image2 == null) {
            logger.debug("One or both images are null, returning 0.0");
            return 0.0;
        }
        
        try {
            // Extract histograms
            double[] histogram1 = ImageFeatureExtractor.extractFlatHistogram(image1);
            double[] histogram2 = ImageFeatureExtractor.extractFlatHistogram(image2);
            
            // Calculate similarity using histogram intersection
            double similarity = HistogramComparator.calculateIntersection(histogram1, histogram2);
            
            logger.debug("Image similarity calculated: {}", similarity);
            return similarity;
            
        } catch (Exception e) {
            logger.error("Error calculating image similarity", e);
            return 0.0;
        }
    }
    
    @Override
    public double calculateSimilarity(String imagePath1, String imagePath2) {
        logger.debug("Calculating image similarity between file paths: {} and {}", imagePath1, imagePath2);
        
        if (imagePath1 == null || imagePath2 == null) {
            logger.debug("One or both image paths are null, returning 0.0");
            return 0.0;
        }
        
        if (imagePath1.trim().isEmpty() || imagePath2.trim().isEmpty()) {
            logger.debug("One or both image paths are empty, returning 0.0");
            return 0.0;
        }
        
        try {
            BufferedImage image1 = loadImage(imagePath1);
            BufferedImage image2 = loadImage(imagePath2);
            
            if (image1 == null || image2 == null) {
                logger.debug("One or both images could not be loaded, returning 0.0");
                return 0.0;
            }
            
            return calculateSimilarity(image1, image2);
            
        } catch (Exception e) {
            logger.error("Error loading images for similarity calculation", e);
            return 0.0;
        }
    }
    
    /**
     * Load an image from file path.
     * 
     * @param imagePath the path to the image file
     * @return the loaded BufferedImage, or null if loading fails
     */
    private BufferedImage loadImage(String imagePath) {
        try {
            File imageFile = new File(imagePath);
            if (!imageFile.exists()) {
                logger.warn("Image file does not exist: {}", imagePath);
                return null;
            }
            
            BufferedImage image = ImageIO.read(imageFile);
            if (image == null) {
                logger.warn("Could not read image file (unsupported format): {}", imagePath);
                return null;
            }
            
            logger.debug("Successfully loaded image: {}", imagePath);
            return image;
            
        } catch (IOException e) {
            logger.error("Error loading image: {}", imagePath, e);
            return null;
        }
    }
}
