package com.findback.ai.impl;

import com.findback.ai.SemanticSimilarityService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Implementation of SemanticSimilarityService using TF-IDF and cosine similarity.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public class SemanticSimilarityServiceImpl implements SemanticSimilarityService {
    
    private static final Logger logger = LoggerFactory.getLogger(SemanticSimilarityServiceImpl.class);
    
    @Override
    public double calculateSimilarity(String text1, String text2) {
        logger.debug("Calculating semantic similarity between two texts");
        
        if (text1 == null || text2 == null) {
            logger.debug("One or both texts are null, returning 0.0");
            return 0.0;
        }
        
        if (text1.trim().isEmpty() || text2.trim().isEmpty()) {
            logger.debug("One or both texts are empty, returning 0.0");
            return 0.0;
        }
        
        // Normalize both texts
        String normalizedText1 = normalizeText(text1);
        String normalizedText2 = normalizeText(text2);
        
        // Calculate cosine similarity using TF-IDF
        double similarity = CosineSimilarity.calculateTextSimilarity(normalizedText1, normalizedText2);
        
        logger.debug("Semantic similarity calculated: {}", similarity);
        return similarity;
    }
    
    @Override
    public String normalizeText(String text) {
        if (text == null || text.trim().isEmpty()) {
            return "";
        }
        
        // Convert to lowercase
        String normalized = text.toLowerCase();
        
        // Remove punctuation (keep letters, numbers, and spaces)
        normalized = normalized.replaceAll("[^a-zA-Z0-9\\s]", " ");
        
        // Normalize whitespace
        normalized = normalized.replaceAll("\\s+", " ").trim();
        
        return normalized;
    }
}
