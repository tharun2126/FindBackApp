package com.findback.ai.impl;

/**
 * Compares image histograms using histogram intersection.
 * 
 * Histogram intersection is a robust method for comparing color distributions.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public class HistogramComparator {
    
    /**
     * Calculate histogram intersection similarity between two histograms.
     * 
     * @param histogram1 the first histogram
     * @param histogram2 the second histogram
     * @return similarity score between 0.0 and 1.0
     */
    public static double calculateIntersection(double[] histogram1, double[] histogram2) {
        if (histogram1 == null || histogram2 == null) {
            return 0.0;
        }
        
        if (histogram1.length != histogram2.length) {
            return 0.0;
        }
        
        double intersection = 0.0;
        double sum1 = 0.0;
        double sum2 = 0.0;
        
        for (int i = 0; i < histogram1.length; i++) {
            intersection += Math.min(histogram1[i], histogram2[i]);
            sum1 += histogram1[i];
            sum2 += histogram2[i];
        }
        
        if (sum1 == 0.0 || sum2 == 0.0) {
            return 0.0;
        }
        
        // Normalize by the sum of the smaller histogram
        double normalization = Math.min(sum1, sum2);
        return intersection / normalization;
    }
    
    /**
     * Calculate Euclidean distance between two histograms.
     * 
     * @param histogram1 the first histogram
     * @param histogram2 the second histogram
     * @return distance (lower is more similar)
     */
    public static double calculateEuclideanDistance(double[] histogram1, double[] histogram2) {
        if (histogram1 == null || histogram2 == null) {
            return Double.MAX_VALUE;
        }
        
        if (histogram1.length != histogram2.length) {
            return Double.MAX_VALUE;
        }
        
        double sumSquares = 0.0;
        for (int i = 0; i < histogram1.length; i++) {
            double diff = histogram1[i] - histogram2[i];
            sumSquares += diff * diff;
        }
        
        return Math.sqrt(sumSquares);
    }
    
    /**
     * Convert Euclidean distance to similarity score.
     * 
     * @param distance the Euclidean distance
     * @param maxDistance the maximum possible distance
     * @return similarity score between 0.0 and 1.0
     */
    public static double distanceToSimilarity(double distance, double maxDistance) {
        if (maxDistance == 0.0) {
            return 0.0;
        }
        return Math.max(0.0, 1.0 - (distance / maxDistance));
    }
}
