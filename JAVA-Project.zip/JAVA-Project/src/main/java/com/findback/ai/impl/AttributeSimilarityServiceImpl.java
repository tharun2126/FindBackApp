package com.findback.ai.impl;

import com.findback.ai.AttributeSimilarityService;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

/**
 * Implementation of AttributeSimilarityService using weighted attribute comparison.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public class AttributeSimilarityServiceImpl implements AttributeSimilarityService {
    
    private static final Logger logger = LoggerFactory.getLogger(AttributeSimilarityServiceImpl.class);
    
    // Weights for different attributes
    private static final double CATEGORY_WEIGHT = 0.35;
    private static final double BRAND_WEIGHT = 0.25;
    private static final double COLOUR_WEIGHT = 0.15;
    private static final double LOCATION_WEIGHT = 0.15;
    private static final double DATE_WEIGHT = 0.10;
    
    // Maximum days difference for date similarity to be non-zero
    private static final int MAX_DAYS_DIFFERENCE = 30;
    
    @Override
    public double calculateSimilarity(String category1, String brand1, String colour1, 
                                       String location1, LocalDateTime date1,
                                       String category2, String brand2, String colour2, 
                                       String location2, LocalDateTime date2) {
        logger.debug("Calculating attribute similarity");
        
        double categoryScore = calculateCategorySimilarity(category1, category2);
        double brandScore = calculateBrandSimilarity(brand1, brand2);
        double colourScore = calculateColourSimilarity(colour1, colour2);
        double locationScore = calculateLocationSimilarity(location1, location2);
        double dateScore = calculateDateSimilarity(date1, date2);
        
        // Calculate weighted sum
        double overallSimilarity = (categoryScore * CATEGORY_WEIGHT) +
                                   (brandScore * BRAND_WEIGHT) +
                                   (colourScore * COLOUR_WEIGHT) +
                                   (locationScore * LOCATION_WEIGHT) +
                                   (dateScore * DATE_WEIGHT);
        
        logger.debug("Attribute similarity - Category: {}, Brand: {}, Colour: {}, Location: {}, Date: {}, Overall: {}", 
                    categoryScore, brandScore, colourScore, locationScore, dateScore, overallSimilarity);
        
        return overallSimilarity;
    }
    
    /**
     * Calculate category similarity (exact match or partial match).
     */
    private double calculateCategorySimilarity(String category1, String category2) {
        if (category1 == null || category2 == null) {
            return 0.0;
        }
        
        String c1 = category1.toLowerCase().trim();
        String c2 = category2.toLowerCase().trim();
        
        if (c1.equals(c2)) {
            return 1.0;
        }
        
        // Check for partial match (one contains the other)
        if (c1.contains(c2) || c2.contains(c1)) {
            return 0.5;
        }
        
        return 0.0;
    }
    
    /**
     * Calculate brand similarity (exact match or partial match).
     */
    private double calculateBrandSimilarity(String brand1, String brand2) {
        // Brand is optional - if both are null/empty, don't penalize
        if ((brand1 == null || brand1.trim().isEmpty()) && 
            (brand2 == null || brand2.trim().isEmpty())) {
            return 0.5; // Neutral score when both are missing
        }
        
        if (brand1 == null || brand2 == null) {
            return 0.0;
        }
        
        String b1 = brand1.toLowerCase().trim();
        String b2 = brand2.toLowerCase().trim();
        
        if (b1.isEmpty() || b2.isEmpty()) {
            return 0.0;
        }
        
        if (b1.equals(b2)) {
            return 1.0;
        }
        
        // Check for partial match
        if (b1.contains(b2) || b2.contains(b1)) {
            return 0.5;
        }
        
        return 0.0;
    }
    
    /**
     * Calculate colour similarity (exact match or partial match).
     */
    private double calculateColourSimilarity(String colour1, String colour2) {
        // Colour is optional
        if ((colour1 == null || colour1.trim().isEmpty()) && 
            (colour2 == null || colour2.trim().isEmpty())) {
            return 0.5; // Neutral score when both are missing
        }
        
        if (colour1 == null || colour2 == null) {
            return 0.0;
        }
        
        String c1 = colour1.toLowerCase().trim();
        String c2 = colour2.toLowerCase().trim();
        
        if (c1.isEmpty() || c2.isEmpty()) {
            return 0.0;
        }
        
        if (c1.equals(c2)) {
            return 1.0;
        }
        
        // Check for partial match
        if (c1.contains(c2) || c2.contains(c1)) {
            return 0.5;
        }
        
        return 0.0;
    }
    
    /**
     * Calculate location similarity using simple string comparison.
     */
    private double calculateLocationSimilarity(String location1, String location2) {
        if (location1 == null || location2 == null) {
            return 0.0;
        }
        
        String l1 = location1.toLowerCase().trim();
        String l2 = location2.toLowerCase().trim();
        
        if (l1.equals(l2)) {
            return 1.0;
        }
        
        // Check for partial match (one contains the other)
        if (l1.contains(l2) || l2.contains(l1)) {
            return 0.5;
        }
        
        // Check for word overlap
        String[] words1 = l1.split("\\s+");
        String[] words2 = l2.split("\\s+");
        int commonWords = 0;
        
        for (String word1 : words1) {
            for (String word2 : words2) {
                if (word1.equals(word2) && word1.length() > 2) {
                    commonWords++;
                    break;
                }
            }
        }
        
        if (commonWords > 0) {
            double overlapRatio = (double) commonWords / Math.max(words1.length, words2.length);
            return Math.min(0.5, overlapRatio);
        }
        
        return 0.0;
    }
    
    /**
     * Calculate date/time similarity based on proximity.
     */
    private double calculateDateSimilarity(LocalDateTime date1, LocalDateTime date2) {
        if (date1 == null || date2 == null) {
            return 0.0;
        }
        
        long daysDifference = Math.abs(ChronoUnit.DAYS.between(date1, date2));
        
        if (daysDifference == 0) {
            return 1.0;
        }
        
        if (daysDifference >= MAX_DAYS_DIFFERENCE) {
            return 0.0;
        }
        
        // Linear decay based on days difference
        return 1.0 - ((double) daysDifference / MAX_DAYS_DIFFERENCE);
    }
}
