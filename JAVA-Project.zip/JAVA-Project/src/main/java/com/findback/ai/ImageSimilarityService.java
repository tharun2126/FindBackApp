package com.findback.ai;

import java.awt.image.BufferedImage;

/**
 * Service interface for image similarity calculation.
 * 
 * Defines the contract for calculating similarity between images
 * using color histogram comparison.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public interface ImageSimilarityService {
    
    /**
     * Calculate image similarity between two images.
     * 
     * @param image1 the first image
     * @param image2 the second image
     * @return similarity score between 0.0 and 1.0
     */
    double calculateSimilarity(BufferedImage image1, BufferedImage image2);
    
    /**
     * Calculate image similarity between two image file paths.
     * 
     * @param imagePath1 the path to the first image
     * @param imagePath2 the path to the second image
     * @return similarity score between 0.0 and 1.0, or 0.0 if images cannot be loaded
     */
    double calculateSimilarity(String imagePath1, String imagePath2);
}
