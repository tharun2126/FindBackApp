package com.findback.ai.impl;

import com.findback.ai.AttributeSimilarityService;
import com.findback.ai.ImageSimilarityService;
import com.findback.ai.MatchingEngine;
import com.findback.ai.SemanticSimilarityService;
import com.findback.model.FoundItem;
import com.findback.model.LostItem;
import com.findback.model.Match;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

/**
 * Implementation of MatchingEngine that combines semantic, image, and attribute similarity.
 * 
 * Uses weighted combination:
 * - Semantic similarity: 30%
 * - Image similarity: 40%
 * - Attribute similarity: 30%
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public class MatchingEngineImpl implements MatchingEngine {
    
    private static final Logger logger = LoggerFactory.getLogger(MatchingEngineImpl.class);
    
    // Weighting factors
    private static final double SEMANTIC_WEIGHT = 0.30;
    private static final double IMAGE_WEIGHT = 0.40;
    private static final double ATTRIBUTE_WEIGHT = 0.30;
    
    // Default thresholds (can be overridden by config)
    private double matchingThreshold = 0.70;
    private double notificationThreshold = 0.80;
    
    private final SemanticSimilarityService semanticSimilarityService;
    private final ImageSimilarityService imageSimilarityService;
    private final AttributeSimilarityService attributeSimilarityService;
    
    /**
     * Constructor with dependency injection.
     * 
     * @param semanticSimilarityService the semantic similarity service
     * @param imageSimilarityService the image similarity service
     * @param attributeSimilarityService the attribute similarity service
     */
    public MatchingEngineImpl(SemanticSimilarityService semanticSimilarityService,
                              ImageSimilarityService imageSimilarityService,
                              AttributeSimilarityService attributeSimilarityService) {
        this.semanticSimilarityService = semanticSimilarityService;
        this.imageSimilarityService = imageSimilarityService;
        this.attributeSimilarityService = attributeSimilarityService;
        
        // Load thresholds from system properties or config
        loadThresholds();
    }
    
    /**
     * Constructor with custom thresholds.
     */
    public MatchingEngineImpl(SemanticSimilarityService semanticSimilarityService,
                              ImageSimilarityService imageSimilarityService,
                              AttributeSimilarityService attributeSimilarityService,
                              double matchingThreshold,
                              double notificationThreshold) {
        this(semanticSimilarityService, imageSimilarityService, attributeSimilarityService);
        this.matchingThreshold = matchingThreshold;
        this.notificationThreshold = notificationThreshold;
    }
    
    /**
     * Load thresholds from configuration.
     */
    private void loadThresholds() {
        try {
            String matchingThresholdStr = System.getProperty("matching.threshold");
            String notificationThresholdStr = System.getProperty("notification.threshold");
            
            if (matchingThresholdStr != null) {
                this.matchingThreshold = Double.parseDouble(matchingThresholdStr);
            }
            if (notificationThresholdStr != null) {
                this.notificationThreshold = Double.parseDouble(notificationThresholdStr);
            }
            
            logger.info("Loaded thresholds - Matching: {}, Notification: {}", 
                       matchingThreshold, notificationThreshold);
        } catch (Exception e) {
            logger.warn("Could not load thresholds from config, using defaults", e);
        }
    }
    
    @Override
    public Match calculateMatch(LostItem lostItem, FoundItem foundItem) {
        logger.debug("Calculating match between lost item {} and found item {}", 
                    lostItem.getLostItemId(), foundItem.getFoundItemId());
        
        // Calculate semantic similarity
        double semanticSimilarity = semanticSimilarityService.calculateSimilarity(
            lostItem.getDescription(), foundItem.getDescription());
        
        // Calculate image similarity (if both images are available)
        double imageSimilarity = 0.0;
        if (lostItem.getImagePath() != null && !lostItem.getImagePath().trim().isEmpty() &&
            foundItem.getImagePath() != null && !foundItem.getImagePath().trim().isEmpty()) {
            imageSimilarity = imageSimilarityService.calculateSimilarity(
                lostItem.getImagePath(), foundItem.getImagePath());
        } else {
            logger.debug("One or both images not available, image similarity set to 0.0");
        }
        
        // Calculate attribute similarity
        double attributeSimilarity = attributeSimilarityService.calculateSimilarity(
            lostItem.getCategory(), lostItem.getBrand(), lostItem.getColour(),
            lostItem.getLocationLost(), lostItem.getDateLost(),
            foundItem.getCategory(), foundItem.getBrand(), foundItem.getColour(),
            foundItem.getLocationFound(), foundItem.getDateFound());
        
        // Calculate overall confidence using weighted formula
        double overallConfidence = (semanticSimilarity * SEMANTIC_WEIGHT) +
                                   (imageSimilarity * IMAGE_WEIGHT) +
                                   (attributeSimilarity * ATTRIBUTE_WEIGHT);
        
        // Create match object
        Match match = new Match();
        match.setLostItemId(lostItem.getLostItemId());
        match.setFoundItemId(foundItem.getFoundItemId());
        match.setSemanticSimilarityScore(toBigDecimal(semanticSimilarity));
        match.setImageSimilarityScore(toBigDecimal(imageSimilarity));
        match.setAttributeSimilarityScore(toBigDecimal(attributeSimilarity));
        match.setOverallConfidenceScore(toBigDecimal(overallConfidence));
        match.setMatchStatus(Match.MatchStatus.PENDING);
        
        logger.debug("Match calculated - Semantic: {}, Image: {}, Attribute: {}, Overall: {}", 
                    semanticSimilarity, imageSimilarity, attributeSimilarity, overallConfidence);
        
        return match;
    }
    
    @Override
    public List<Match> findMatches(FoundItem foundItem, List<LostItem> lostItems) {
        logger.debug("Finding matches for found item {} against {} lost items", 
                    foundItem.getFoundItemId(), lostItems.size());
        
        List<Match> matches = new ArrayList<>();
        
        for (LostItem lostItem : lostItems) {
            Match match = calculateMatch(lostItem, foundItem);
            
            // Only include matches above threshold
            if (match.getOverallConfidenceScore().doubleValue() >= matchingThreshold) {
                matches.add(match);
            }
        }
        
        logger.info("Found {} matches above threshold {} for found item {}", 
                   matches.size(), matchingThreshold, foundItem.getFoundItemId());
        
        return matches;
    }
    
    @Override
    public List<Match> findMatches(LostItem lostItem, List<FoundItem> foundItems) {
        logger.debug("Finding matches for lost item {} against {} found items", 
                    lostItem.getLostItemId(), foundItems.size());
        
        List<Match> matches = new ArrayList<>();
        
        for (FoundItem foundItem : foundItems) {
            Match match = calculateMatch(lostItem, foundItem);
            
            // Only include matches above threshold
            if (match.getOverallConfidenceScore().doubleValue() >= matchingThreshold) {
                matches.add(match);
            }
        }
        
        logger.info("Found {} matches above threshold {} for lost item {}", 
                   matches.size(), matchingThreshold, lostItem.getLostItemId());
        
        return matches;
    }
    
    @Override
    public double getMatchingThreshold() {
        return matchingThreshold;
    }
    
    @Override
    public double getNotificationThreshold() {
        return notificationThreshold;
    }
    
    /**
     * Convert double to BigDecimal with 4 decimal places.
     */
    private BigDecimal toBigDecimal(double value) {
        return BigDecimal.valueOf(value)
                .setScale(4, RoundingMode.HALF_UP);
    }
}
