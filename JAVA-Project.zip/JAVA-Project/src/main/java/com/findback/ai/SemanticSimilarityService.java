package com.findback.ai;

import java.awt.image.BufferedImage;

/**
 * Service interface for semantic/text similarity calculation.
 * 
 * Defines the contract for calculating similarity between text descriptions
 * using TF-IDF vectorization and cosine similarity.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public interface SemanticSimilarityService {
    
    /**
     * Calculate semantic similarity between two text descriptions.
     * 
     * @param text1 the first text description
     * @param text2 the second text description
     * @return similarity score between 0.0 and 1.0
     */
    double calculateSimilarity(String text1, String text2);
    
    /**
     * Normalize text for comparison.
     * 
     * @param text the text to normalize
     * @return normalized text
     */
    String normalizeText(String text);
}
