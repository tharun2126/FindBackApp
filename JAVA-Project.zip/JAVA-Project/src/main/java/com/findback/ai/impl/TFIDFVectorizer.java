package com.findback.ai.impl;

import java.util.*;
import java.util.stream.Collectors;

/**
 * TF-IDF (Term Frequency-Inverse Document Frequency) vectorizer.
 * 
 * Converts text documents into TF-IDF feature vectors for similarity comparison.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public class TFIDFVectorizer {
    
    private final List<String> documents;
    private final Map<String, Integer> documentFrequency;
    private final int totalDocuments;
    
    /**
     * Constructor with documents to vectorize.
     * 
     * @param documents the list of documents
     */
    public TFIDFVectorizer(List<String> documents) {
        this.documents = documents;
        this.documentFrequency = new HashMap<>();
        this.totalDocuments = documents.size();
        buildDocumentFrequency();
    }
    
    /**
     * Build document frequency map.
     */
    private void buildDocumentFrequency() {
        for (String document : documents) {
            Set<String> terms = tokenize(document);
            for (String term : terms) {
                documentFrequency.put(term, documentFrequency.getOrDefault(term, 0) + 1);
            }
        }
    }
    
    /**
     * Tokenize text into terms.
     * 
     * @param text the text to tokenize
     * @return set of unique terms
     */
    public static Set<String> tokenize(String text) {
        if (text == null || text.trim().isEmpty()) {
            return new HashSet<>();
        }
        
        // Normalize: lowercase, remove punctuation, split on whitespace
        String normalized = text.toLowerCase()
                .replaceAll("[^a-zA-Z0-9\\s]", " ")
                .replaceAll("\\s+", " ")
                .trim();
        
        // Split into terms and filter empty strings
        return Arrays.stream(normalized.split(" "))
                .filter(term -> !term.isEmpty())
                .filter(term -> term.length() > 1) // Filter single characters
                .collect(Collectors.toSet());
    }
    
    /**
     * Calculate term frequency for a document.
     * 
     * @param document the document
     * @param term the term
     * @return term frequency
     */
    private double calculateTermFrequency(String document, String term) {
        if (document == null || document.isEmpty()) {
            return 0.0;
        }
        
        String[] words = document.toLowerCase().split("\\s+");
        int count = 0;
        int totalWords = words.length;
        
        for (String word : words) {
            if (word.equalsIgnoreCase(term)) {
                count++;
            }
        }
        
        if (totalWords == 0) {
            return 0.0;
        }
        
        return (double) count / totalWords;
    }
    
    /**
     * Calculate inverse document frequency for a term.
     * 
     * @param term the term
     * @return inverse document frequency
     */
    private double calculateInverseDocumentFrequency(String term) {
        int df = documentFrequency.getOrDefault(term, 0);
        if (df == 0) {
            return 0.0;
        }
        // Add smoothing to handle small document sets
        return Math.log((double) (totalDocuments + 1) / (df + 1)) + 1.0;
    }
    
    /**
     * Calculate TF-IDF score for a term in a document.
     * 
     * @param document the document
     * @param term the term
     * @return TF-IDF score
     */
    public double calculateTFIDF(String document, String term) {
        double tf = calculateTermFrequency(document, term);
        double idf = calculateInverseDocumentFrequency(term);
        return tf * idf;
    }
    
    /**
     * Convert a document to a TF-IDF vector.
     * 
     * @param document the document
     * @return map of term to TF-IDF score
     */
    public Map<String, Double> vectorize(String document) {
        Map<String, Double> vector = new HashMap<>();
        Set<String> terms = tokenize(document);
        
        for (String term : terms) {
            vector.put(term, calculateTFIDF(document, term));
        }
        
        return vector;
    }
    
    /**
     * Get all unique terms across all documents.
     * 
     * @return set of all unique terms
     */
    public Set<String> getAllTerms() {
        return documentFrequency.keySet();
    }
}
