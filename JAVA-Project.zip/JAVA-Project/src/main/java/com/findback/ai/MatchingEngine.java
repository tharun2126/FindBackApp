package com.findback.ai;

import com.findback.model.FoundItem;
import com.findback.model.LostItem;
import com.findback.model.Match;

import java.math.BigDecimal;
import java.util.List;

/**
 * Engine for matching lost items with found items using AI/ML similarity analysis.
 * 
 * This engine combines semantic, image, and attribute similarity to generate
 * overall match confidence scores.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public interface MatchingEngine {
    
    /**
     * Calculate match similarity between a lost item and a found item.
     * 
     * @param lostItem the lost item
     * @param foundItem the found item
     * @return Match object with similarity scores and overall confidence
     */
    Match calculateMatch(LostItem lostItem, FoundItem foundItem);
    
    /**
     * Find matches for a specific found item against all active lost items.
     * 
     * @param foundItem the found item to match
     * @param lostItems the list of lost items to compare against
     * @return list of matches with confidence scores
     */
    List<Match> findMatches(FoundItem foundItem, List<LostItem> lostItems);
    
    /**
     * Find matches for a specific lost item against all active found items.
     * 
     * @param lostItem the lost item to match
     * @param foundItems the list of found items to compare against
     * @return list of matches with confidence scores
     */
    List<Match> findMatches(LostItem lostItem, List<FoundItem> foundItems);
    
    /**
     * Get the matching threshold from configuration.
     * 
     * @return the threshold (0.0 to 1.0) for saving significant matches
     */
    double getMatchingThreshold();
    
    /**
     * Get the notification threshold from configuration.
     * 
     * @return the threshold (0.0 to 1.0) for high-confidence notifications
     */
    double getNotificationThreshold();
}
