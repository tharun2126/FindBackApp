package com.findback;

import com.findback.config.DatabaseConfig;
import com.findback.dao.FoundItemDAO;
import com.findback.dao.LostItemDAO;
import com.findback.dao.UserDAO;
import com.findback.dao.impl.FoundItemDAOImpl;
import com.findback.dao.impl.LostItemDAOImpl;
import com.findback.dao.impl.UserDAOImpl;
import com.findback.service.FoundItemService;
import com.findback.service.LostItemService;
import com.findback.service.UserService;
import com.findback.service.impl.FoundItemServiceImpl;
import com.findback.service.impl.LostItemServiceImpl;
import com.findback.service.impl.UserServiceImpl;
import com.findback.ui.frame.MainFrame;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.*;

/**
 * Main entry point for the FindBack application.
 * 
 * FindBack is an AI-Powered Lost-and-Found Item Matching System
 * that uses image and semantic similarity analysis to match lost items
 * with found items.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public class FindBackApp {
    
    private static final Logger logger = LoggerFactory.getLogger(FindBackApp.class);
    
    /**
     * Main method to start the application.
     * 
     * @param args Command line arguments (not used)
     */
    public static void main(String[] args) {
        logger.info("Starting FindBack Application...");
        logger.info("FindBack: AI-Powered Lost-and-Found Item Matching System");
        
        try {
            // Initialize database configuration
            DatabaseConfig.initialize();
            logger.info("Database configuration initialized successfully");
            
            // Initialize DAOs
            UserDAO userDAO = new UserDAOImpl();
            LostItemDAO lostItemDAO = new LostItemDAOImpl();
            FoundItemDAO foundItemDAO = new FoundItemDAOImpl();
            
            // Initialize Services with dependency injection
            UserService userService = new UserServiceImpl(userDAO);
            LostItemService lostItemService = new LostItemServiceImpl(lostItemDAO);
            FoundItemService foundItemService = new FoundItemServiceImpl(foundItemDAO);
            
            // Initialize and show UI on Event Dispatch Thread
            SwingUtilities.invokeLater(() -> {
                try {
                    // Set System Look and Feel for modern OS-native appearance
                    try {
                        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                    } catch (Exception e) {
                        logger.warn("Could not set system look and feel, using default", e);
                    }
                    
                    MainFrame mainFrame = new MainFrame(userService, lostItemService, foundItemService);
                    mainFrame.setVisible(true);
                    logger.info("UI displayed successfully");
                } catch (Exception e) {
                    logger.error("Failed to initialize UI", e);
                    JOptionPane.showMessageDialog(null, 
                            "Failed to initialize application: " + e.getMessage(), 
                            "Error", JOptionPane.ERROR_MESSAGE);
                    System.exit(1);
                }
            });
            
        } catch (Exception e) {
            logger.error("Failed to start FindBack application", e);
            System.err.println("Error starting application: " + e.getMessage());
            System.exit(1);
        }
        
        logger.info("FindBack Application started successfully");
    }
}
