package com.findback.exception;

/**
 * Custom exception for authentication-related errors.
 * 
 * This exception is thrown when authentication operations fail,
 * such as invalid credentials or user not found.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public class AuthenticationException extends RuntimeException {
    
    /**
     * Constructs a new AuthenticationException with the specified detail message.
     * 
     * @param message the detail message
     */
    public AuthenticationException(String message) {
        super(message);
    }
    
    /**
     * Constructs a new AuthenticationException with the specified detail message and cause.
     * 
     * @param message the detail message
     * @param cause the cause of the exception
     */
    public AuthenticationException(String message, Throwable cause) {
        super(message, cause);
    }
}
