package com.findback.exception;

/**
 * Custom exception for database-related errors.
 * 
 * This exception is thrown when database operations fail,
 * providing a clear separation between database errors
 * and other application errors.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public class DatabaseException extends RuntimeException {
    
    /**
     * Constructs a new DatabaseException with the specified detail message.
     * 
     * @param message the detail message
     */
    public DatabaseException(String message) {
        super(message);
    }
    
    /**
     * Constructs a new DatabaseException with the specified detail message and cause.
     * 
     * @param message the detail message
     * @param cause the cause of the exception
     */
    public DatabaseException(String message, Throwable cause) {
        super(message, cause);
    }
}
