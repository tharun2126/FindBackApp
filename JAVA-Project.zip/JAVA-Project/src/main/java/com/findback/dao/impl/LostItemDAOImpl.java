package com.findback.dao.impl;

import com.findback.config.DatabaseConfig;
import com.findback.dao.LostItemDAO;
import com.findback.exception.DatabaseException;
import com.findback.model.LostItem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * JDBC implementation of LostItemDAO interface.
 * 
 * Provides database operations for lost item management using JDBC.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public class LostItemDAOImpl implements LostItemDAO {
    
    private static final Logger logger = LoggerFactory.getLogger(LostItemDAOImpl.class);
    
    // SQL queries
    private static final String INSERT_LOST_ITEM = 
            "INSERT INTO lost_items (user_id, category, brand, colour, description, location_lost, date_lost, image_path, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    private static final String UPDATE_LOST_ITEM = 
            "UPDATE lost_items SET user_id = ?, category = ?, brand = ?, colour = ?, description = ?, location_lost = ?, date_lost = ?, image_path = ?, status = ? WHERE lost_item_id = ?";
    
    private static final String DELETE_LOST_ITEM = 
            "DELETE FROM lost_items WHERE lost_item_id = ?";
    
    private static final String SELECT_LOST_ITEM_BY_ID = 
            "SELECT lost_item_id, user_id, category, brand, colour, description, location_lost, date_lost, image_path, status, created_at, updated_at FROM lost_items WHERE lost_item_id = ?";
    
    private static final String SELECT_LOST_ITEMS_BY_USER_ID = 
            "SELECT lost_item_id, user_id, category, brand, colour, description, location_lost, date_lost, image_path, status, created_at, updated_at FROM lost_items WHERE user_id = ? ORDER BY created_at DESC";
    
    private static final String SELECT_ACTIVE_LOST_ITEMS = 
            "SELECT lost_item_id, user_id, category, brand, colour, description, location_lost, date_lost, image_path, status, created_at, updated_at FROM lost_items WHERE status = 'ACTIVE' ORDER BY created_at DESC";
    
    private static final String SELECT_LOST_ITEMS_BY_CATEGORY = 
            "SELECT lost_item_id, user_id, category, brand, colour, description, location_lost, date_lost, image_path, status, created_at, updated_at FROM lost_items WHERE category = ? ORDER BY created_at DESC";
    
    /**
     * Map a ResultSet row to a LostItem object.
     * 
     * @param rs the ResultSet containing the lost item data
     * @return LostItem object mapped from the ResultSet
     * @throws SQLException if a database access error occurs
     */
    private LostItem mapResultSetToLostItem(ResultSet rs) throws SQLException {
        LostItem lostItem = new LostItem();
        lostItem.setLostItemId(rs.getInt("lost_item_id"));
        lostItem.setUserId(rs.getInt("user_id"));
        lostItem.setCategory(rs.getString("category"));
        lostItem.setBrand(rs.getString("brand"));
        lostItem.setColour(rs.getString("colour"));
        lostItem.setDescription(rs.getString("description"));
        lostItem.setLocationLost(rs.getString("location_lost"));
        lostItem.setDateLost(rs.getTimestamp("date_lost").toLocalDateTime());
        lostItem.setImagePath(rs.getString("image_path"));
        lostItem.setStatus(LostItem.ItemStatus.valueOf(rs.getString("status")));
        lostItem.setCreatedAt(rs.getTimestamp("created_at").toLocalDateTime());
        lostItem.setUpdatedAt(rs.getTimestamp("updated_at").toLocalDateTime());
        return lostItem;
    }
    
    @Override
    public LostItem save(LostItem lostItem) {
        logger.debug("Saving new lost item for user ID: {}", lostItem.getUserId());
        
        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement statement = connection.prepareStatement(INSERT_LOST_ITEM, Statement.RETURN_GENERATED_KEYS)) {
            
            statement.setInt(1, lostItem.getUserId());
            statement.setString(2, lostItem.getCategory());
            statement.setString(3, lostItem.getBrand());
            statement.setString(4, lostItem.getColour());
            statement.setString(5, lostItem.getDescription());
            statement.setString(6, lostItem.getLocationLost());
            statement.setTimestamp(7, Timestamp.valueOf(lostItem.getDateLost()));
            statement.setString(8, lostItem.getImagePath());
            statement.setString(9, lostItem.getStatus().name());
            
            int affectedRows = statement.executeUpdate();
            
            if (affectedRows == 0) {
                throw new DatabaseException("Creating lost item failed, no rows affected.");
            }
            
            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    lostItem.setLostItemId(generatedKeys.getInt(1));
                    logger.info("Lost item saved successfully with ID: {}", lostItem.getLostItemId());
                    return lostItem;
                } else {
                    throw new DatabaseException("Creating lost item failed, no ID obtained.");
                }
            }
            
        } catch (SQLException e) {
            logger.error("Error saving lost item for user ID: {}", lostItem.getUserId(), e);
            throw new DatabaseException("Failed to save lost item", e);
        }
    }
    
    @Override
    public LostItem update(LostItem lostItem) {
        logger.debug("Updating lost item with ID: {}", lostItem.getLostItemId());
        
        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement statement = connection.prepareStatement(UPDATE_LOST_ITEM)) {
            
            statement.setInt(1, lostItem.getUserId());
            statement.setString(2, lostItem.getCategory());
            statement.setString(3, lostItem.getBrand());
            statement.setString(4, lostItem.getColour());
            statement.setString(5, lostItem.getDescription());
            statement.setString(6, lostItem.getLocationLost());
            statement.setTimestamp(7, Timestamp.valueOf(lostItem.getDateLost()));
            statement.setString(8, lostItem.getImagePath());
            statement.setString(9, lostItem.getStatus().name());
            statement.setInt(10, lostItem.getLostItemId());
            
            int affectedRows = statement.executeUpdate();
            
            if (affectedRows == 0) {
                throw new DatabaseException("Updating lost item failed, no rows affected.");
            }
            
            logger.info("Lost item updated successfully with ID: {}", lostItem.getLostItemId());
            return lostItem;
            
        } catch (SQLException e) {
            logger.error("Error updating lost item with ID: {}", lostItem.getLostItemId(), e);
            throw new DatabaseException("Failed to update lost item", e);
        }
    }
    
    @Override
    public boolean delete(Integer lostItemId) {
        logger.debug("Deleting lost item with ID: {}", lostItemId);
        
        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement statement = connection.prepareStatement(DELETE_LOST_ITEM)) {
            
            statement.setInt(1, lostItemId);
            
            int affectedRows = statement.executeUpdate();
            boolean deleted = affectedRows > 0;
            
            if (deleted) {
                logger.info("Lost item deleted successfully with ID: {}", lostItemId);
            } else {
                logger.warn("No lost item found to delete with ID: {}", lostItemId);
            }
            
            return deleted;
            
        } catch (SQLException e) {
            logger.error("Error deleting lost item with ID: {}", lostItemId, e);
            throw new DatabaseException("Failed to delete lost item with ID: " + lostItemId, e);
        }
    }
    
    @Override
    public Optional<LostItem> findById(Integer lostItemId) {
        logger.debug("Finding lost item by ID: {}", lostItemId);
        
        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement statement = connection.prepareStatement(SELECT_LOST_ITEM_BY_ID)) {
            
            statement.setInt(1, lostItemId);
            
            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapResultSetToLostItem(rs));
                }
            }
            
            return Optional.empty();
            
        } catch (SQLException e) {
            logger.error("Error finding lost item by ID: {}", lostItemId, e);
            throw new DatabaseException("Failed to find lost item by ID: " + lostItemId, e);
        }
    }
    
    @Override
    public List<LostItem> findByUserId(Integer userId) {
        logger.debug("Finding lost items by user ID: {}", userId);
        
        List<LostItem> lostItems = new ArrayList<>();
        
        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement statement = connection.prepareStatement(SELECT_LOST_ITEMS_BY_USER_ID)) {
            
            statement.setInt(1, userId);
            
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    lostItems.add(mapResultSetToLostItem(rs));
                }
            }
            
            logger.info("Found {} lost items for user ID: {}", lostItems.size(), userId);
            return lostItems;
            
        } catch (SQLException e) {
            logger.error("Error finding lost items by user ID: {}", userId, e);
            throw new DatabaseException("Failed to find lost items by user ID: " + userId, e);
        }
    }
    
    @Override
    public List<LostItem> findActive() {
        logger.debug("Finding all active lost items");
        
        List<LostItem> lostItems = new ArrayList<>();
        
        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement statement = connection.prepareStatement(SELECT_ACTIVE_LOST_ITEMS);
             ResultSet rs = statement.executeQuery()) {
            
            while (rs.next()) {
                lostItems.add(mapResultSetToLostItem(rs));
            }
            
            logger.info("Found {} active lost items", lostItems.size());
            return lostItems;
            
        } catch (SQLException e) {
            logger.error("Error finding active lost items", e);
            throw new DatabaseException("Failed to find active lost items", e);
        }
    }
    
    @Override
    public List<LostItem> findByCategory(String category) {
        logger.debug("Finding lost items by category: {}", category);
        
        List<LostItem> lostItems = new ArrayList<>();
        
        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement statement = connection.prepareStatement(SELECT_LOST_ITEMS_BY_CATEGORY)) {
            
            statement.setString(1, category);
            
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    lostItems.add(mapResultSetToLostItem(rs));
                }
            }
            
            logger.info("Found {} lost items in category: {}", lostItems.size(), category);
            return lostItems;
            
        } catch (SQLException e) {
            logger.error("Error finding lost items by category: {}", category, e);
            throw new DatabaseException("Failed to find lost items by category: " + category, e);
        }
    }
}
