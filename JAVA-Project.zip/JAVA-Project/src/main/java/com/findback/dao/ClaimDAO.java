package com.findback.dao;

import com.findback.model.Claim;

import java.util.List;
import java.util.Optional;

/**
 * Data Access Object interface for Claim entities.
 * 
 * Defines the database operations for claim management.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public interface ClaimDAO {
    
    /**
     * Save a new claim to the database.
     * 
     * @param claim the claim to save
     * @return the saved claim with generated ID
     */
    Claim save(Claim claim);
    
    /**
     * Update an existing claim in the database.
     * 
     * @param claim the claim to update
     * @return the updated claim
     */
    Claim update(Claim claim);
    
    /**
     * Delete a claim by ID.
     * 
     * @param claimId the claim ID to delete
     * @return true if deleted, false otherwise
     */
    boolean delete(Integer claimId);
    
    /**
     * Find a claim by ID.
     * 
     * @param claimId the claim ID to search for
     * @return Optional containing the claim if found
     */
    Optional<Claim> findById(Integer claimId);
    
    /**
     * Find all claims by user ID.
     * 
     * @param userId the user ID to search for
     * @return list of claims for the user
     */
    List<Claim> findByUserId(Integer userId);
    
    /**
     * Find all claims by match ID.
     * 
     * @param matchId the match ID to search for
     * @return list of claims for the match
     */
    List<Claim> findByMatchId(Integer matchId);
    
    /**
     * Find all claims by status.
     * 
     * @param status the claim status to search for
     * @return list of claims with the specified status
     */
    List<Claim> findByStatus(Claim.ClaimStatus status);
}
