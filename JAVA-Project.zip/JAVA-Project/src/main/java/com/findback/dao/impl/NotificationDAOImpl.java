package com.findback.dao.impl;

import com.findback.config.DatabaseConfig;
import com.findback.dao.NotificationDAO;
import com.findback.exception.DatabaseException;
import com.findback.model.Notification;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * JDBC implementation of NotificationDAO interface.
 * 
 * Provides database operations for notification management using JDBC.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public class NotificationDAOImpl implements NotificationDAO {
    
    private static final Logger logger = LoggerFactory.getLogger(NotificationDAOImpl.class);
    
    // SQL queries
    private static final String INSERT_NOTIFICATION = 
            "INSERT INTO notifications (user_id, title, message, notification_type, related_match_id, is_read) VALUES (?, ?, ?, ?, ?, ?)";
    
    private static final String UPDATE_NOTIFICATION = 
            "UPDATE notifications SET user_id = ?, title = ?, message = ?, notification_type = ?, related_match_id = ?, is_read = ? WHERE notification_id = ?";
    
    private static final String DELETE_NOTIFICATION = 
            "DELETE FROM notifications WHERE notification_id = ?";
    
    private static final String SELECT_NOTIFICATION_BY_ID = 
            "SELECT notification_id, user_id, title, message, notification_type, related_match_id, is_read, created_at FROM notifications WHERE notification_id = ?";
    
    private static final String SELECT_NOTIFICATIONS_BY_USER_ID = 
            "SELECT notification_id, user_id, title, message, notification_type, related_match_id, is_read, created_at FROM notifications WHERE user_id = ? ORDER BY created_at DESC";
    
    private static final String SELECT_UNREAD_NOTIFICATIONS = 
            "SELECT notification_id, user_id, title, message, notification_type, related_match_id, is_read, created_at FROM notifications WHERE user_id = ? AND is_read = false ORDER BY created_at DESC";
    
    private static final String MARK_AS_READ = 
            "UPDATE notifications SET is_read = true WHERE notification_id = ?";
    
    /**
     * Map a ResultSet row to a Notification object.
     * 
     * @param rs the ResultSet containing the notification data
     * @return Notification object mapped from the ResultSet
     * @throws SQLException if a database access error occurs
     */
    private Notification mapResultSetToNotification(ResultSet rs) throws SQLException {
        Notification notification = new Notification();
        notification.setNotificationId(rs.getInt("notification_id"));
        notification.setUserId(rs.getInt("user_id"));
        notification.setTitle(rs.getString("title"));
        notification.setMessage(rs.getString("message"));
        notification.setNotificationType(Notification.NotificationType.valueOf(rs.getString("notification_type")));
        
        Integer relatedMatchId = (Integer) rs.getObject("related_match_id");
        notification.setRelatedMatchId(relatedMatchId);
        
        notification.setRead(rs.getBoolean("is_read"));
        notification.setCreatedAt(rs.getTimestamp("created_at").toLocalDateTime());
        return notification;
    }
    
    @Override
    public Notification save(Notification notification) {
        logger.debug("Saving new notification for user ID: {}", notification.getUserId());
        
        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement statement = connection.prepareStatement(INSERT_NOTIFICATION, Statement.RETURN_GENERATED_KEYS)) {
            
            statement.setInt(1, notification.getUserId());
            statement.setString(2, notification.getTitle());
            statement.setString(3, notification.getMessage());
            statement.setString(4, notification.getNotificationType().name());
            
            if (notification.getRelatedMatchId() != null) {
                statement.setInt(5, notification.getRelatedMatchId());
            } else {
                statement.setNull(5, Types.INTEGER);
            }
            
            statement.setBoolean(6, notification.isRead());
            
            int affectedRows = statement.executeUpdate();
            
            if (affectedRows == 0) {
                throw new DatabaseException("Creating notification failed, no rows affected.");
            }
            
            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    notification.setNotificationId(generatedKeys.getInt(1));
                    logger.info("Notification saved successfully with ID: {}", notification.getNotificationId());
                    return notification;
                } else {
                    throw new DatabaseException("Creating notification failed, no ID obtained.");
                }
            }
            
        } catch (SQLException e) {
            logger.error("Error saving notification", e);
            throw new DatabaseException("Failed to save notification", e);
        }
    }
    
    @Override
    public Notification update(Notification notification) {
        logger.debug("Updating notification with ID: {}", notification.getNotificationId());
        
        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement statement = connection.prepareStatement(UPDATE_NOTIFICATION)) {
            
            statement.setInt(1, notification.getUserId());
            statement.setString(2, notification.getTitle());
            statement.setString(3, notification.getMessage());
            statement.setString(4, notification.getNotificationType().name());
            
            if (notification.getRelatedMatchId() != null) {
                statement.setInt(5, notification.getRelatedMatchId());
            } else {
                statement.setNull(5, Types.INTEGER);
            }
            
            statement.setBoolean(6, notification.isRead());
            statement.setInt(7, notification.getNotificationId());
            
            int affectedRows = statement.executeUpdate();
            
            if (affectedRows == 0) {
                throw new DatabaseException("Updating notification failed, no rows affected.");
            }
            
            logger.info("Notification updated successfully with ID: {}", notification.getNotificationId());
            return notification;
            
        } catch (SQLException e) {
            logger.error("Error updating notification with ID: {}", notification.getNotificationId(), e);
            throw new DatabaseException("Failed to update notification", e);
        }
    }
    
    @Override
    public boolean delete(Integer notificationId) {
        logger.debug("Deleting notification with ID: {}", notificationId);
        
        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement statement = connection.prepareStatement(DELETE_NOTIFICATION)) {
            
            statement.setInt(1, notificationId);
            
            int affectedRows = statement.executeUpdate();
            boolean deleted = affectedRows > 0;
            
            if (deleted) {
                logger.info("Notification deleted successfully with ID: {}", notificationId);
            } else {
                logger.warn("No notification found to delete with ID: {}", notificationId);
            }
            
            return deleted;
            
        } catch (SQLException e) {
            logger.error("Error deleting notification with ID: {}", notificationId, e);
            throw new DatabaseException("Failed to delete notification with ID: " + notificationId, e);
        }
    }
    
    @Override
    public Optional<Notification> findById(Integer notificationId) {
        logger.debug("Finding notification by ID: {}", notificationId);
        
        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement statement = connection.prepareStatement(SELECT_NOTIFICATION_BY_ID)) {
            
            statement.setInt(1, notificationId);
            
            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapResultSetToNotification(rs));
                }
            }
            
            return Optional.empty();
            
        } catch (SQLException e) {
            logger.error("Error finding notification by ID: {}", notificationId, e);
            throw new DatabaseException("Failed to find notification by ID: " + notificationId, e);
        }
    }
    
    @Override
    public List<Notification> findByUserId(Integer userId) {
        logger.debug("Finding notifications by user ID: {}", userId);
        
        List<Notification> notifications = new ArrayList<>();
        
        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement statement = connection.prepareStatement(SELECT_NOTIFICATIONS_BY_USER_ID)) {
            
            statement.setInt(1, userId);
            
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    notifications.add(mapResultSetToNotification(rs));
                }
            }
            
            logger.info("Found {} notifications for user ID: {}", notifications.size(), userId);
            return notifications;
            
        } catch (SQLException e) {
            logger.error("Error finding notifications by user ID: {}", userId, e);
            throw new DatabaseException("Failed to find notifications by user ID: " + userId, e);
        }
    }
    
    @Override
    public List<Notification> findUnread(Integer userId) {
        logger.debug("Finding unread notifications for user ID: {}", userId);
        
        List<Notification> notifications = new ArrayList<>();
        
        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement statement = connection.prepareStatement(SELECT_UNREAD_NOTIFICATIONS)) {
            
            statement.setInt(1, userId);
            
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    notifications.add(mapResultSetToNotification(rs));
                }
            }
            
            logger.info("Found {} unread notifications for user ID: {}", notifications.size(), userId);
            return notifications;
            
        } catch (SQLException e) {
            logger.error("Error finding unread notifications for user ID: {}", userId, e);
            throw new DatabaseException("Failed to find unread notifications for user ID: " + userId, e);
        }
    }
    
    @Override
    public boolean markAsRead(Integer notificationId) {
        logger.debug("Marking notification as read with ID: {}", notificationId);
        
        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement statement = connection.prepareStatement(MARK_AS_READ)) {
            
            statement.setInt(1, notificationId);
            
            int affectedRows = statement.executeUpdate();
            boolean marked = affectedRows > 0;
            
            if (marked) {
                logger.info("Notification marked as read with ID: {}", notificationId);
            } else {
                logger.warn("No notification found to mark as read with ID: {}", notificationId);
            }
            
            return marked;
            
        } catch (SQLException e) {
            logger.error("Error marking notification as read with ID: {}", notificationId, e);
            throw new DatabaseException("Failed to mark notification as read with ID: " + notificationId, e);
        }
    }
}
