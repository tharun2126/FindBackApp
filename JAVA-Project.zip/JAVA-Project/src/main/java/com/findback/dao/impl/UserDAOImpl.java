package com.findback.dao.impl;

import com.findback.config.DatabaseConfig;
import com.findback.dao.UserDAO;
import com.findback.exception.DatabaseException;
import com.findback.model.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * JDBC implementation of UserDAO interface.
 * 
 * Provides database operations for user management using JDBC.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public class UserDAOImpl implements UserDAO {
    
    private static final Logger logger = LoggerFactory.getLogger(UserDAOImpl.class);
    
    // SQL queries
    private static final String INSERT_USER = 
            "INSERT INTO users (username, email, password_hash, full_name, phone, role) VALUES (?, ?, ?, ?, ?, ?)";
    
    private static final String UPDATE_USER = 
            "UPDATE users SET username = ?, email = ?, password_hash = ?, full_name = ?, phone = ?, role = ? WHERE user_id = ?";
    
    private static final String DELETE_USER = 
            "DELETE FROM users WHERE user_id = ?";
    
    private static final String SELECT_USER_BY_ID = 
            "SELECT user_id, username, email, password_hash, full_name, phone, role, created_at, updated_at FROM users WHERE user_id = ?";
    
    private static final String SELECT_USER_BY_USERNAME = 
            "SELECT user_id, username, email, password_hash, full_name, phone, role, created_at, updated_at FROM users WHERE username = ?";
    
    private static final String SELECT_USER_BY_EMAIL = 
            "SELECT user_id, username, email, password_hash, full_name, phone, role, created_at, updated_at FROM users WHERE email = ?";
    
    private static final String SELECT_ALL_USERS = 
            "SELECT user_id, username, email, password_hash, full_name, phone, role, created_at, updated_at FROM users ORDER BY created_at DESC";
    
    /**
     * Map a ResultSet row to a User object.
     * 
     * @param rs the ResultSet containing the user data
     * @return User object mapped from the ResultSet
     * @throws SQLException if a database access error occurs
     */
    private User mapResultSetToUser(ResultSet rs) throws SQLException {
        User user = new User();
        user.setUserId(rs.getInt("user_id"));
        user.setUsername(rs.getString("username"));
        user.setEmail(rs.getString("email"));
        user.setPasswordHash(rs.getString("password_hash"));
        user.setFullName(rs.getString("full_name"));
        user.setPhone(rs.getString("phone"));
        user.setRole(User.UserRole.valueOf(rs.getString("role")));
        user.setCreatedAt(rs.getTimestamp("created_at").toLocalDateTime());
        user.setUpdatedAt(rs.getTimestamp("updated_at").toLocalDateTime());
        return user;
    }
    
    @Override
    public Optional<User> findByUsername(String username) {
        logger.debug("Finding user by username: {}", username);
        
        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement statement = connection.prepareStatement(SELECT_USER_BY_USERNAME)) {
            
            statement.setString(1, username);
            
            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapResultSetToUser(rs));
                }
            }
            
            return Optional.empty();
            
        } catch (SQLException e) {
            logger.error("Error finding user by username: {}", username, e);
            throw new DatabaseException("Failed to find user by username: " + username, e);
        }
    }
    
    @Override
    public Optional<User> findByEmail(String email) {
        logger.debug("Finding user by email: {}", email);
        
        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement statement = connection.prepareStatement(SELECT_USER_BY_EMAIL)) {
            
            statement.setString(1, email);
            
            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapResultSetToUser(rs));
                }
            }
            
            return Optional.empty();
            
        } catch (SQLException e) {
            logger.error("Error finding user by email: {}", email, e);
            throw new DatabaseException("Failed to find user by email: " + email, e);
        }
    }
    
    @Override
    public User save(User user) {
        logger.debug("Saving new user: {}", user.getUsername());
        
        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement statement = connection.prepareStatement(INSERT_USER, Statement.RETURN_GENERATED_KEYS)) {
            
            statement.setString(1, user.getUsername());
            statement.setString(2, user.getEmail());
            statement.setString(3, user.getPasswordHash());
            statement.setString(4, user.getFullName());
            statement.setString(5, user.getPhone());
            statement.setString(6, user.getRole().name());
            
            int affectedRows = statement.executeUpdate();
            
            if (affectedRows == 0) {
                throw new DatabaseException("Creating user failed, no rows affected.");
            }
            
            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    user.setUserId(generatedKeys.getInt(1));
                    logger.info("User saved successfully with ID: {}", user.getUserId());
                    return user;
                } else {
                    throw new DatabaseException("Creating user failed, no ID obtained.");
                }
            }
            
        } catch (SQLException e) {
            logger.error("Error saving user: {}", user.getUsername(), e);
            throw new DatabaseException("Failed to save user: " + user.getUsername(), e);
        }
    }
    
    @Override
    public User update(User user) {
        logger.debug("Updating user: {}", user.getUsername());
        
        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement statement = connection.prepareStatement(UPDATE_USER)) {
            
            statement.setString(1, user.getUsername());
            statement.setString(2, user.getEmail());
            statement.setString(3, user.getPasswordHash());
            statement.setString(4, user.getFullName());
            statement.setString(5, user.getPhone());
            statement.setString(6, user.getRole().name());
            statement.setInt(7, user.getUserId());
            
            int affectedRows = statement.executeUpdate();
            
            if (affectedRows == 0) {
                throw new DatabaseException("Updating user failed, no rows affected.");
            }
            
            logger.info("User updated successfully: {}", user.getUsername());
            return user;
            
        } catch (SQLException e) {
            logger.error("Error updating user: {}", user.getUsername(), e);
            throw new DatabaseException("Failed to update user: " + user.getUsername(), e);
        }
    }
    
    @Override
    public boolean delete(Integer userId) {
        logger.debug("Deleting user with ID: {}", userId);
        
        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement statement = connection.prepareStatement(DELETE_USER)) {
            
            statement.setInt(1, userId);
            
            int affectedRows = statement.executeUpdate();
            boolean deleted = affectedRows > 0;
            
            if (deleted) {
                logger.info("User deleted successfully with ID: {}", userId);
            } else {
                logger.warn("No user found to delete with ID: {}", userId);
            }
            
            return deleted;
            
        } catch (SQLException e) {
            logger.error("Error deleting user with ID: {}", userId, e);
            throw new DatabaseException("Failed to delete user with ID: " + userId, e);
        }
    }
    
    @Override
    public Optional<User> findById(Integer userId) {
        logger.debug("Finding user by ID: {}", userId);
        
        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement statement = connection.prepareStatement(SELECT_USER_BY_ID)) {
            
            statement.setInt(1, userId);
            
            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapResultSetToUser(rs));
                }
            }
            
            return Optional.empty();
            
        } catch (SQLException e) {
            logger.error("Error finding user by ID: {}", userId, e);
            throw new DatabaseException("Failed to find user by ID: " + userId, e);
        }
    }
    
    @Override
    public List<User> findAll() {
        logger.debug("Finding all users");
        
        List<User> users = new ArrayList<>();
        
        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement statement = connection.prepareStatement(SELECT_ALL_USERS);
             ResultSet rs = statement.executeQuery()) {
            
            while (rs.next()) {
                users.add(mapResultSetToUser(rs));
            }
            
            logger.info("Found {} users", users.size());
            return users;
            
        } catch (SQLException e) {
            logger.error("Error finding all users", e);
            throw new DatabaseException("Failed to find all users", e);
        }
    }
}
