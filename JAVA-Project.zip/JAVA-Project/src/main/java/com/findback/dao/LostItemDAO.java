package com.findback.dao;

import com.findback.model.LostItem;

import java.util.List;
import java.util.Optional;

/**
 * Data Access Object interface for LostItem entities.
 * 
 * Defines the database operations for lost item management.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public interface LostItemDAO {
    
    /**
     * Save a new lost item to the database.
     * 
     * @param lostItem the lost item to save
     * @return the saved lost item with generated ID
     */
    LostItem save(LostItem lostItem);
    
    /**
     * Update an existing lost item in the database.
     * 
     * @param lostItem the lost item to update
     * @return the updated lost item
     */
    LostItem update(LostItem lostItem);
    
    /**
     * Delete a lost item by ID.
     * 
     * @param lostItemId the lost item ID to delete
     * @return true if deleted, false otherwise
     */
    boolean delete(Integer lostItemId);
    
    /**
     * Find a lost item by ID.
     * 
     * @param lostItemId the lost item ID to search for
     * @return Optional containing the lost item if found
     */
    Optional<LostItem> findById(Integer lostItemId);
    
    /**
     * Find all lost items by user ID.
     * 
     * @param userId the user ID to search for
     * @return list of lost items for the user
     */
    List<LostItem> findByUserId(Integer userId);
    
    /**
     * Find all active lost items.
     * 
     * @return list of active lost items
     */
    List<LostItem> findActive();
    
    /**
     * Find lost items by category.
     * 
     * @param category the category to search for
     * @return list of lost items in the category
     */
    List<LostItem> findByCategory(String category);
}
