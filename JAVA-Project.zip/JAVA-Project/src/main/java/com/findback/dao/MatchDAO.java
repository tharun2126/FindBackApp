package com.findback.dao;

import com.findback.model.Match;

import java.util.List;
import java.util.Optional;

/**
 * Data Access Object interface for Match entities.
 * 
 * Defines the database operations for match management.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public interface MatchDAO {
    
    /**
     * Save a new match to the database.
     * 
     * @param match the match to save
     * @return the saved match with generated ID
     */
    Match save(Match match);
    
    /**
     * Update an existing match in the database.
     * 
     * @param match the match to update
     * @return the updated match
     */
    Match update(Match match);
    
    /**
     * Delete a match by ID.
     * 
     * @param matchId the match ID to delete
     * @return true if deleted, false otherwise
     */
    boolean delete(Integer matchId);
    
    /**
     * Find a match by ID.
     * 
     * @param matchId the match ID to search for
     * @return Optional containing the match if found
     */
    Optional<Match> findById(Integer matchId);
    
    /**
     * Find all matches by lost item ID.
     * 
     * @param lostItemId the lost item ID to search for
     * @return list of matches for the lost item
     */
    List<Match> findByLostItemId(Integer lostItemId);
    
    /**
     * Find all matches by found item ID.
     * 
     * @param foundItemId the found item ID to search for
     * @return list of matches for the found item
     */
    List<Match> findByFoundItemId(Integer foundItemId);
    
    /**
     * Find all high confidence matches.
     * 
     * @param threshold the confidence threshold (0.0 to 1.0)
     * @return list of high confidence matches
     */
    List<Match> findHighConfidenceMatches(double threshold);
}
