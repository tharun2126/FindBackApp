package com.findback.dao;

import com.findback.model.FoundItem;

import java.util.List;
import java.util.Optional;

/**
 * Data Access Object interface for FoundItem entities.
 * 
 * Defines the database operations for found item management.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public interface FoundItemDAO {
    
    /**
     * Save a new found item to the database.
     * 
     * @param foundItem the found item to save
     * @return the saved found item with generated ID
     */
    FoundItem save(FoundItem foundItem);
    
    /**
     * Update an existing found item in the database.
     * 
     * @param foundItem the found item to update
     * @return the updated found item
     */
    FoundItem update(FoundItem foundItem);
    
    /**
     * Delete a found item by ID.
     * 
     * @param foundItemId the found item ID to delete
     * @return true if deleted, false otherwise
     */
    boolean delete(Integer foundItemId);
    
    /**
     * Find a found item by ID.
     * 
     * @param foundItemId the found item ID to search for
     * @return Optional containing the found item if found
     */
    Optional<FoundItem> findById(Integer foundItemId);
    
    /**
     * Find all found items by user ID.
     * 
     * @param userId the user ID to search for
     * @return list of found items for the user
     */
    List<FoundItem> findByUserId(Integer userId);
    
    /**
     * Find all active found items.
     * 
     * @return list of active found items
     */
    List<FoundItem> findActive();
    
    /**
     * Find found items by category.
     * 
     * @param category the category to search for
     * @return list of found items in the category
     */
    List<FoundItem> findByCategory(String category);
}
