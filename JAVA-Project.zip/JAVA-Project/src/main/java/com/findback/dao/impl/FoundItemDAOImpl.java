package com.findback.dao.impl;

import com.findback.config.DatabaseConfig;
import com.findback.dao.FoundItemDAO;
import com.findback.exception.DatabaseException;
import com.findback.model.FoundItem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * JDBC implementation of FoundItemDAO interface.
 * 
 * Provides database operations for found item management using JDBC.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public class FoundItemDAOImpl implements FoundItemDAO {
    
    private static final Logger logger = LoggerFactory.getLogger(FoundItemDAOImpl.class);
    
    // SQL queries
    private static final String INSERT_FOUND_ITEM = 
            "INSERT INTO found_items (user_id, category, brand, colour, description, location_found, date_found, image_path, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    private static final String UPDATE_FOUND_ITEM = 
            "UPDATE found_items SET user_id = ?, category = ?, brand = ?, colour = ?, description = ?, location_found = ?, date_found = ?, image_path = ?, status = ? WHERE found_item_id = ?";
    
    private static final String DELETE_FOUND_ITEM = 
            "DELETE FROM found_items WHERE found_item_id = ?";
    
    private static final String SELECT_FOUND_ITEM_BY_ID = 
            "SELECT found_item_id, user_id, category, brand, colour, description, location_found, date_found, image_path, status, created_at, updated_at FROM found_items WHERE found_item_id = ?";
    
    private static final String SELECT_FOUND_ITEMS_BY_USER_ID = 
            "SELECT found_item_id, user_id, category, brand, colour, description, location_found, date_found, image_path, status, created_at, updated_at FROM found_items WHERE user_id = ? ORDER BY created_at DESC";
    
    private static final String SELECT_ACTIVE_FOUND_ITEMS = 
            "SELECT found_item_id, user_id, category, brand, colour, description, location_found, date_found, image_path, status, created_at, updated_at FROM found_items WHERE status = 'ACTIVE' ORDER BY created_at DESC";
    
    private static final String SELECT_FOUND_ITEMS_BY_CATEGORY = 
            "SELECT found_item_id, user_id, category, brand, colour, description, location_found, date_found, image_path, status, created_at, updated_at FROM found_items WHERE category = ? ORDER BY created_at DESC";
    
    /**
     * Map a ResultSet row to a FoundItem object.
     * 
     * @param rs the ResultSet containing the found item data
     * @return FoundItem object mapped from the ResultSet
     * @throws SQLException if a database access error occurs
     */
    private FoundItem mapResultSetToFoundItem(ResultSet rs) throws SQLException {
        FoundItem foundItem = new FoundItem();
        foundItem.setFoundItemId(rs.getInt("found_item_id"));
        foundItem.setUserId(rs.getInt("user_id"));
        foundItem.setCategory(rs.getString("category"));
        foundItem.setBrand(rs.getString("brand"));
        foundItem.setColour(rs.getString("colour"));
        foundItem.setDescription(rs.getString("description"));
        foundItem.setLocationFound(rs.getString("location_found"));
        foundItem.setDateFound(rs.getTimestamp("date_found").toLocalDateTime());
        foundItem.setImagePath(rs.getString("image_path"));
        foundItem.setStatus(FoundItem.ItemStatus.valueOf(rs.getString("status")));
        foundItem.setCreatedAt(rs.getTimestamp("created_at").toLocalDateTime());
        foundItem.setUpdatedAt(rs.getTimestamp("updated_at").toLocalDateTime());
        return foundItem;
    }
    
    @Override
    public FoundItem save(FoundItem foundItem) {
        logger.debug("Saving new found item for user ID: {}", foundItem.getUserId());
        
        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement statement = connection.prepareStatement(INSERT_FOUND_ITEM, Statement.RETURN_GENERATED_KEYS)) {
            
            statement.setInt(1, foundItem.getUserId());
            statement.setString(2, foundItem.getCategory());
            statement.setString(3, foundItem.getBrand());
            statement.setString(4, foundItem.getColour());
            statement.setString(5, foundItem.getDescription());
            statement.setString(6, foundItem.getLocationFound());
            statement.setTimestamp(7, Timestamp.valueOf(foundItem.getDateFound()));
            statement.setString(8, foundItem.getImagePath());
            statement.setString(9, foundItem.getStatus().name());
            
            int affectedRows = statement.executeUpdate();
            
            if (affectedRows == 0) {
                throw new DatabaseException("Creating found item failed, no rows affected.");
            }
            
            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    foundItem.setFoundItemId(generatedKeys.getInt(1));
                    logger.info("Found item saved successfully with ID: {}", foundItem.getFoundItemId());
                    return foundItem;
                } else {
                    throw new DatabaseException("Creating found item failed, no ID obtained.");
                }
            }
            
        } catch (SQLException e) {
            logger.error("Error saving found item for user ID: {}", foundItem.getUserId(), e);
            throw new DatabaseException("Failed to save found item", e);
        }
    }
    
    @Override
    public FoundItem update(FoundItem foundItem) {
        logger.debug("Updating found item with ID: {}", foundItem.getFoundItemId());
        
        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement statement = connection.prepareStatement(UPDATE_FOUND_ITEM)) {
            
            statement.setInt(1, foundItem.getUserId());
            statement.setString(2, foundItem.getCategory());
            statement.setString(3, foundItem.getBrand());
            statement.setString(4, foundItem.getColour());
            statement.setString(5, foundItem.getDescription());
            statement.setString(6, foundItem.getLocationFound());
            statement.setTimestamp(7, Timestamp.valueOf(foundItem.getDateFound()));
            statement.setString(8, foundItem.getImagePath());
            statement.setString(9, foundItem.getStatus().name());
            statement.setInt(10, foundItem.getFoundItemId());
            
            int affectedRows = statement.executeUpdate();
            
            if (affectedRows == 0) {
                throw new DatabaseException("Updating found item failed, no rows affected.");
            }
            
            logger.info("Found item updated successfully with ID: {}", foundItem.getFoundItemId());
            return foundItem;
            
        } catch (SQLException e) {
            logger.error("Error updating found item with ID: {}", foundItem.getFoundItemId(), e);
            throw new DatabaseException("Failed to update found item", e);
        }
    }
    
    @Override
    public boolean delete(Integer foundItemId) {
        logger.debug("Deleting found item with ID: {}", foundItemId);
        
        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement statement = connection.prepareStatement(DELETE_FOUND_ITEM)) {
            
            statement.setInt(1, foundItemId);
            
            int affectedRows = statement.executeUpdate();
            boolean deleted = affectedRows > 0;
            
            if (deleted) {
                logger.info("Found item deleted successfully with ID: {}", foundItemId);
            } else {
                logger.warn("No found item found to delete with ID: {}", foundItemId);
            }
            
            return deleted;
            
        } catch (SQLException e) {
            logger.error("Error deleting found item with ID: {}", foundItemId, e);
            throw new DatabaseException("Failed to delete found item with ID: " + foundItemId, e);
        }
    }
    
    @Override
    public Optional<FoundItem> findById(Integer foundItemId) {
        logger.debug("Finding found item by ID: {}", foundItemId);
        
        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement statement = connection.prepareStatement(SELECT_FOUND_ITEM_BY_ID)) {
            
            statement.setInt(1, foundItemId);
            
            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapResultSetToFoundItem(rs));
                }
            }
            
            return Optional.empty();
            
        } catch (SQLException e) {
            logger.error("Error finding found item by ID: {}", foundItemId, e);
            throw new DatabaseException("Failed to find found item by ID: " + foundItemId, e);
        }
    }
    
    @Override
    public List<FoundItem> findByUserId(Integer userId) {
        logger.debug("Finding found items by user ID: {}", userId);
        
        List<FoundItem> foundItems = new ArrayList<>();
        
        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement statement = connection.prepareStatement(SELECT_FOUND_ITEMS_BY_USER_ID)) {
            
            statement.setInt(1, userId);
            
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    foundItems.add(mapResultSetToFoundItem(rs));
                }
            }
            
            logger.info("Found {} found items for user ID: {}", foundItems.size(), userId);
            return foundItems;
            
        } catch (SQLException e) {
            logger.error("Error finding found items by user ID: {}", userId, e);
            throw new DatabaseException("Failed to find found items by user ID: " + userId, e);
        }
    }
    
    @Override
    public List<FoundItem> findActive() {
        logger.debug("Finding all active found items");
        
        List<FoundItem> foundItems = new ArrayList<>();
        
        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement statement = connection.prepareStatement(SELECT_ACTIVE_FOUND_ITEMS);
             ResultSet rs = statement.executeQuery()) {
            
            while (rs.next()) {
                foundItems.add(mapResultSetToFoundItem(rs));
            }
            
            logger.info("Found {} active found items", foundItems.size());
            return foundItems;
            
        } catch (SQLException e) {
            logger.error("Error finding active found items", e);
            throw new DatabaseException("Failed to find active found items", e);
        }
    }
    
    @Override
    public List<FoundItem> findByCategory(String category) {
        logger.debug("Finding found items by category: {}", category);
        
        List<FoundItem> foundItems = new ArrayList<>();
        
        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement statement = connection.prepareStatement(SELECT_FOUND_ITEMS_BY_CATEGORY)) {
            
            statement.setString(1, category);
            
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    foundItems.add(mapResultSetToFoundItem(rs));
                }
            }
            
            logger.info("Found {} found items in category: {}", foundItems.size(), category);
            return foundItems;
            
        } catch (SQLException e) {
            logger.error("Error finding found items by category: {}", category, e);
            throw new DatabaseException("Failed to find found items by category: " + category, e);
        }
    }
}
