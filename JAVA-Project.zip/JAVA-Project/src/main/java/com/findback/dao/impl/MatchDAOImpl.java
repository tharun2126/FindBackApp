package com.findback.dao.impl;

import com.findback.config.DatabaseConfig;
import com.findback.dao.MatchDAO;
import com.findback.exception.DatabaseException;
import com.findback.model.Match;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * JDBC implementation of MatchDAO interface.
 * 
 * Provides database operations for match management using JDBC.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public class MatchDAOImpl implements MatchDAO {
    
    private static final Logger logger = LoggerFactory.getLogger(MatchDAOImpl.class);
    
    // SQL queries
    private static final String INSERT_MATCH = 
            "INSERT INTO matches (lost_item_id, found_item_id, semantic_similarity_score, image_similarity_score, attribute_similarity_score, overall_confidence_score, match_status) VALUES (?, ?, ?, ?, ?, ?, ?)";
    
    private static final String UPDATE_MATCH = 
            "UPDATE matches SET lost_item_id = ?, found_item_id = ?, semantic_similarity_score = ?, image_similarity_score = ?, attribute_similarity_score = ?, overall_confidence_score = ?, match_status = ? WHERE match_id = ?";
    
    private static final String DELETE_MATCH = 
            "DELETE FROM matches WHERE match_id = ?";
    
    private static final String SELECT_MATCH_BY_ID = 
            "SELECT match_id, lost_item_id, found_item_id, semantic_similarity_score, image_similarity_score, attribute_similarity_score, overall_confidence_score, match_status, created_at FROM matches WHERE match_id = ?";
    
    private static final String SELECT_MATCHES_BY_LOST_ITEM_ID = 
            "SELECT match_id, lost_item_id, found_item_id, semantic_similarity_score, image_similarity_score, attribute_similarity_score, overall_confidence_score, match_status, created_at FROM matches WHERE lost_item_id = ? ORDER BY overall_confidence_score DESC";
    
    private static final String SELECT_MATCHES_BY_FOUND_ITEM_ID = 
            "SELECT match_id, lost_item_id, found_item_id, semantic_similarity_score, image_similarity_score, attribute_similarity_score, overall_confidence_score, match_status, created_at FROM matches WHERE found_item_id = ? ORDER BY overall_confidence_score DESC";
    
    private static final String SELECT_HIGH_CONFIDENCE_MATCHES = 
            "SELECT match_id, lost_item_id, found_item_id, semantic_similarity_score, image_similarity_score, attribute_similarity_score, overall_confidence_score, match_status, created_at FROM matches WHERE overall_confidence_score >= ? ORDER BY overall_confidence_score DESC";
    
    /**
     * Map a ResultSet row to a Match object.
     * 
     * @param rs the ResultSet containing the match data
     * @return Match object mapped from the ResultSet
     * @throws SQLException if a database access error occurs
     */
    private Match mapResultSetToMatch(ResultSet rs) throws SQLException {
        Match match = new Match();
        match.setMatchId(rs.getInt("match_id"));
        match.setLostItemId(rs.getInt("lost_item_id"));
        match.setFoundItemId(rs.getInt("found_item_id"));
        
        BigDecimal semanticScore = rs.getBigDecimal("semantic_similarity_score");
        match.setSemanticSimilarityScore(semanticScore);
        
        BigDecimal imageScore = rs.getBigDecimal("image_similarity_score");
        match.setImageSimilarityScore(imageScore);
        
        BigDecimal attributeScore = rs.getBigDecimal("attribute_similarity_score");
        match.setAttributeSimilarityScore(attributeScore);
        
        match.setOverallConfidenceScore(rs.getBigDecimal("overall_confidence_score"));
        match.setMatchStatus(Match.MatchStatus.valueOf(rs.getString("match_status")));
        match.setCreatedAt(rs.getTimestamp("created_at").toLocalDateTime());
        return match;
    }
    
    @Override
    public Match save(Match match) {
        logger.debug("Saving new match between lost item {} and found item {}", 
                    match.getLostItemId(), match.getFoundItemId());
        
        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement statement = connection.prepareStatement(INSERT_MATCH, Statement.RETURN_GENERATED_KEYS)) {
            
            statement.setInt(1, match.getLostItemId());
            statement.setInt(2, match.getFoundItemId());
            statement.setBigDecimal(3, match.getSemanticSimilarityScore());
            statement.setBigDecimal(4, match.getImageSimilarityScore());
            statement.setBigDecimal(5, match.getAttributeSimilarityScore());
            statement.setBigDecimal(6, match.getOverallConfidenceScore());
            statement.setString(7, match.getMatchStatus().name());
            
            int affectedRows = statement.executeUpdate();
            
            if (affectedRows == 0) {
                throw new DatabaseException("Creating match failed, no rows affected.");
            }
            
            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    match.setMatchId(generatedKeys.getInt(1));
                    logger.info("Match saved successfully with ID: {}", match.getMatchId());
                    return match;
                } else {
                    throw new DatabaseException("Creating match failed, no ID obtained.");
                }
            }
            
        } catch (SQLException e) {
            logger.error("Error saving match", e);
            throw new DatabaseException("Failed to save match", e);
        }
    }
    
    @Override
    public Match update(Match match) {
        logger.debug("Updating match with ID: {}", match.getMatchId());
        
        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement statement = connection.prepareStatement(UPDATE_MATCH)) {
            
            statement.setInt(1, match.getLostItemId());
            statement.setInt(2, match.getFoundItemId());
            statement.setBigDecimal(3, match.getSemanticSimilarityScore());
            statement.setBigDecimal(4, match.getImageSimilarityScore());
            statement.setBigDecimal(5, match.getAttributeSimilarityScore());
            statement.setBigDecimal(6, match.getOverallConfidenceScore());
            statement.setString(7, match.getMatchStatus().name());
            statement.setInt(8, match.getMatchId());
            
            int affectedRows = statement.executeUpdate();
            
            if (affectedRows == 0) {
                throw new DatabaseException("Updating match failed, no rows affected.");
            }
            
            logger.info("Match updated successfully with ID: {}", match.getMatchId());
            return match;
            
        } catch (SQLException e) {
            logger.error("Error updating match with ID: {}", match.getMatchId(), e);
            throw new DatabaseException("Failed to update match", e);
        }
    }
    
    @Override
    public boolean delete(Integer matchId) {
        logger.debug("Deleting match with ID: {}", matchId);
        
        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement statement = connection.prepareStatement(DELETE_MATCH)) {
            
            statement.setInt(1, matchId);
            
            int affectedRows = statement.executeUpdate();
            boolean deleted = affectedRows > 0;
            
            if (deleted) {
                logger.info("Match deleted successfully with ID: {}", matchId);
            } else {
                logger.warn("No match found to delete with ID: {}", matchId);
            }
            
            return deleted;
            
        } catch (SQLException e) {
            logger.error("Error deleting match with ID: {}", matchId, e);
            throw new DatabaseException("Failed to delete match with ID: " + matchId, e);
        }
    }
    
    @Override
    public Optional<Match> findById(Integer matchId) {
        logger.debug("Finding match by ID: {}", matchId);
        
        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement statement = connection.prepareStatement(SELECT_MATCH_BY_ID)) {
            
            statement.setInt(1, matchId);
            
            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapResultSetToMatch(rs));
                }
            }
            
            return Optional.empty();
            
        } catch (SQLException e) {
            logger.error("Error finding match by ID: {}", matchId, e);
            throw new DatabaseException("Failed to find match by ID: " + matchId, e);
        }
    }
    
    @Override
    public List<Match> findByLostItemId(Integer lostItemId) {
        logger.debug("Finding matches by lost item ID: {}", lostItemId);
        
        List<Match> matches = new ArrayList<>();
        
        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement statement = connection.prepareStatement(SELECT_MATCHES_BY_LOST_ITEM_ID)) {
            
            statement.setInt(1, lostItemId);
            
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    matches.add(mapResultSetToMatch(rs));
                }
            }
            
            logger.info("Found {} matches for lost item ID: {}", matches.size(), lostItemId);
            return matches;
            
        } catch (SQLException e) {
            logger.error("Error finding matches by lost item ID: {}", lostItemId, e);
            throw new DatabaseException("Failed to find matches by lost item ID: " + lostItemId, e);
        }
    }
    
    @Override
    public List<Match> findByFoundItemId(Integer foundItemId) {
        logger.debug("Finding matches by found item ID: {}", foundItemId);
        
        List<Match> matches = new ArrayList<>();
        
        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement statement = connection.prepareStatement(SELECT_MATCHES_BY_FOUND_ITEM_ID)) {
            
            statement.setInt(1, foundItemId);
            
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    matches.add(mapResultSetToMatch(rs));
                }
            }
            
            logger.info("Found {} matches for found item ID: {}", matches.size(), foundItemId);
            return matches;
            
        } catch (SQLException e) {
            logger.error("Error finding matches by found item ID: {}", foundItemId, e);
            throw new DatabaseException("Failed to find matches by found item ID: " + foundItemId, e);
        }
    }
    
    @Override
    public List<Match> findHighConfidenceMatches(double threshold) {
        logger.debug("Finding high confidence matches with threshold: {}", threshold);
        
        List<Match> matches = new ArrayList<>();
        
        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement statement = connection.prepareStatement(SELECT_HIGH_CONFIDENCE_MATCHES)) {
            
            statement.setDouble(1, threshold);
            
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    matches.add(mapResultSetToMatch(rs));
                }
            }
            
            logger.info("Found {} high confidence matches with threshold: {}", matches.size(), threshold);
            return matches;
            
        } catch (SQLException e) {
            logger.error("Error finding high confidence matches with threshold: {}", threshold, e);
            throw new DatabaseException("Failed to find high confidence matches", e);
        }
    }
}
