package com.findback.dao;

import com.findback.model.User;

import java.util.List;
import java.util.Optional;

/**
 * Data Access Object interface for User entities.
 * 
 * Defines the database operations for user management.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public interface UserDAO {
    
    /**
     * Find a user by username.
     * 
     * @param username the username to search for
     * @return Optional containing the user if found
     */
    Optional<User> findByUsername(String username);
    
    /**
     * Find a user by email.
     * 
     * @param email the email to search for
     * @return Optional containing the user if found
     */
    Optional<User> findByEmail(String email);
    
    /**
     * Save a new user to the database.
     * 
     * @param user the user to save
     * @return the saved user with generated ID
     */
    User save(User user);
    
    /**
     * Update an existing user in the database.
     * 
     * @param user the user to update
     * @return the updated user
     */
    User update(User user);
    
    /**
     * Delete a user by ID.
     * 
     * @param userId the user ID to delete
     * @return true if deleted, false otherwise
     */
    boolean delete(Integer userId);
    
    /**
     * Find a user by ID.
     * 
     * @param userId the user ID to search for
     * @return Optional containing the user if found
     */
    Optional<User> findById(Integer userId);
    
    /**
     * Find all users in the database.
     * 
     * @return list of all users
     */
    List<User> findAll();
}
