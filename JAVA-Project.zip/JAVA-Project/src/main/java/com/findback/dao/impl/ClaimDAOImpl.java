package com.findback.dao.impl;

import com.findback.config.DatabaseConfig;
import com.findback.dao.ClaimDAO;
import com.findback.exception.DatabaseException;
import com.findback.model.Claim;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * JDBC implementation of ClaimDAO interface.
 * 
 * Provides database operations for claim management using JDBC.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public class ClaimDAOImpl implements ClaimDAO {
    
    private static final Logger logger = LoggerFactory.getLogger(ClaimDAOImpl.class);
    
    // SQL queries
    private static final String INSERT_CLAIM = 
            "INSERT INTO claims (match_id, user_id, claim_status, verification_notes, admin_id, verified_at) VALUES (?, ?, ?, ?, ?, ?)";
    
    private static final String UPDATE_CLAIM = 
            "UPDATE claims SET match_id = ?, user_id = ?, claim_status = ?, verification_notes = ?, admin_id = ?, verified_at = ? WHERE claim_id = ?";
    
    private static final String DELETE_CLAIM = 
            "DELETE FROM claims WHERE claim_id = ?";
    
    private static final String SELECT_CLAIM_BY_ID = 
            "SELECT claim_id, match_id, user_id, claim_status, verification_notes, admin_id, verified_at, created_at, updated_at FROM claims WHERE claim_id = ?";
    
    private static final String SELECT_CLAIMS_BY_USER_ID = 
            "SELECT claim_id, match_id, user_id, claim_status, verification_notes, admin_id, verified_at, created_at, updated_at FROM claims WHERE user_id = ? ORDER BY created_at DESC";
    
    private static final String SELECT_CLAIMS_BY_MATCH_ID = 
            "SELECT claim_id, match_id, user_id, claim_status, verification_notes, admin_id, verified_at, created_at, updated_at FROM claims WHERE match_id = ? ORDER BY created_at DESC";
    
    private static final String SELECT_CLAIMS_BY_STATUS = 
            "SELECT claim_id, match_id, user_id, claim_status, verification_notes, admin_id, verified_at, created_at, updated_at FROM claims WHERE claim_status = ? ORDER BY created_at DESC";
    
    /**
     * Map a ResultSet row to a Claim object.
     * 
     * @param rs the ResultSet containing the claim data
     * @return Claim object mapped from the ResultSet
     * @throws SQLException if a database access error occurs
     */
    private Claim mapResultSetToClaim(ResultSet rs) throws SQLException {
        Claim claim = new Claim();
        claim.setClaimId(rs.getInt("claim_id"));
        claim.setMatchId(rs.getInt("match_id"));
        claim.setUserId(rs.getInt("user_id"));
        claim.setClaimStatus(Claim.ClaimStatus.valueOf(rs.getString("claim_status")));
        claim.setVerificationNotes(rs.getString("verification_notes"));
        
        Integer adminId = (Integer) rs.getObject("admin_id");
        claim.setAdminId(adminId);
        
        Timestamp verifiedAt = rs.getTimestamp("verified_at");
        if (verifiedAt != null) {
            claim.setVerifiedAt(verifiedAt.toLocalDateTime());
        }
        
        claim.setCreatedAt(rs.getTimestamp("created_at").toLocalDateTime());
        claim.setUpdatedAt(rs.getTimestamp("updated_at").toLocalDateTime());
        return claim;
    }
    
    @Override
    public Claim save(Claim claim) {
        logger.debug("Saving new claim for match ID: {} by user ID: {}", 
                    claim.getMatchId(), claim.getUserId());
        
        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement statement = connection.prepareStatement(INSERT_CLAIM, Statement.RETURN_GENERATED_KEYS)) {
            
            statement.setInt(1, claim.getMatchId());
            statement.setInt(2, claim.getUserId());
            statement.setString(3, claim.getClaimStatus().name());
            statement.setString(4, claim.getVerificationNotes());
            
            if (claim.getAdminId() != null) {
                statement.setInt(5, claim.getAdminId());
            } else {
                statement.setNull(5, Types.INTEGER);
            }
            
            if (claim.getVerifiedAt() != null) {
                statement.setTimestamp(6, Timestamp.valueOf(claim.getVerifiedAt()));
            } else {
                statement.setNull(6, Types.TIMESTAMP);
            }
            
            int affectedRows = statement.executeUpdate();
            
            if (affectedRows == 0) {
                throw new DatabaseException("Creating claim failed, no rows affected.");
            }
            
            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    claim.setClaimId(generatedKeys.getInt(1));
                    logger.info("Claim saved successfully with ID: {}", claim.getClaimId());
                    return claim;
                } else {
                    throw new DatabaseException("Creating claim failed, no ID obtained.");
                }
            }
            
        } catch (SQLException e) {
            logger.error("Error saving claim", e);
            throw new DatabaseException("Failed to save claim", e);
        }
    }
    
    @Override
    public Claim update(Claim claim) {
        logger.debug("Updating claim with ID: {}", claim.getClaimId());
        
        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement statement = connection.prepareStatement(UPDATE_CLAIM)) {
            
            statement.setInt(1, claim.getMatchId());
            statement.setInt(2, claim.getUserId());
            statement.setString(3, claim.getClaimStatus().name());
            statement.setString(4, claim.getVerificationNotes());
            
            if (claim.getAdminId() != null) {
                statement.setInt(5, claim.getAdminId());
            } else {
                statement.setNull(5, Types.INTEGER);
            }
            
            if (claim.getVerifiedAt() != null) {
                statement.setTimestamp(6, Timestamp.valueOf(claim.getVerifiedAt()));
            } else {
                statement.setNull(6, Types.TIMESTAMP);
            }
            
            statement.setInt(7, claim.getClaimId());
            
            int affectedRows = statement.executeUpdate();
            
            if (affectedRows == 0) {
                throw new DatabaseException("Updating claim failed, no rows affected.");
            }
            
            logger.info("Claim updated successfully with ID: {}", claim.getClaimId());
            return claim;
            
        } catch (SQLException e) {
            logger.error("Error updating claim with ID: {}", claim.getClaimId(), e);
            throw new DatabaseException("Failed to update claim", e);
        }
    }
    
    @Override
    public boolean delete(Integer claimId) {
        logger.debug("Deleting claim with ID: {}", claimId);
        
        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement statement = connection.prepareStatement(DELETE_CLAIM)) {
            
            statement.setInt(1, claimId);
            
            int affectedRows = statement.executeUpdate();
            boolean deleted = affectedRows > 0;
            
            if (deleted) {
                logger.info("Claim deleted successfully with ID: {}", claimId);
            } else {
                logger.warn("No claim found to delete with ID: {}", claimId);
            }
            
            return deleted;
            
        } catch (SQLException e) {
            logger.error("Error deleting claim with ID: {}", claimId, e);
            throw new DatabaseException("Failed to delete claim with ID: " + claimId, e);
        }
    }
    
    @Override
    public Optional<Claim> findById(Integer claimId) {
        logger.debug("Finding claim by ID: {}", claimId);
        
        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement statement = connection.prepareStatement(SELECT_CLAIM_BY_ID)) {
            
            statement.setInt(1, claimId);
            
            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapResultSetToClaim(rs));
                }
            }
            
            return Optional.empty();
            
        } catch (SQLException e) {
            logger.error("Error finding claim by ID: {}", claimId, e);
            throw new DatabaseException("Failed to find claim by ID: " + claimId, e);
        }
    }
    
    @Override
    public List<Claim> findByUserId(Integer userId) {
        logger.debug("Finding claims by user ID: {}", userId);
        
        List<Claim> claims = new ArrayList<>();
        
        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement statement = connection.prepareStatement(SELECT_CLAIMS_BY_USER_ID)) {
            
            statement.setInt(1, userId);
            
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    claims.add(mapResultSetToClaim(rs));
                }
            }
            
            logger.info("Found {} claims for user ID: {}", claims.size(), userId);
            return claims;
            
        } catch (SQLException e) {
            logger.error("Error finding claims by user ID: {}", userId, e);
            throw new DatabaseException("Failed to find claims by user ID: " + userId, e);
        }
    }
    
    @Override
    public List<Claim> findByMatchId(Integer matchId) {
        logger.debug("Finding claims by match ID: {}", matchId);
        
        List<Claim> claims = new ArrayList<>();
        
        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement statement = connection.prepareStatement(SELECT_CLAIMS_BY_MATCH_ID)) {
            
            statement.setInt(1, matchId);
            
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    claims.add(mapResultSetToClaim(rs));
                }
            }
            
            logger.info("Found {} claims for match ID: {}", claims.size(), matchId);
            return claims;
            
        } catch (SQLException e) {
            logger.error("Error finding claims by match ID: {}", matchId, e);
            throw new DatabaseException("Failed to find claims by match ID: " + matchId, e);
        }
    }
    
    @Override
    public List<Claim> findByStatus(Claim.ClaimStatus status) {
        logger.debug("Finding claims by status: {}", status);
        
        List<Claim> claims = new ArrayList<>();
        
        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement statement = connection.prepareStatement(SELECT_CLAIMS_BY_STATUS)) {
            
            statement.setString(1, status.name());
            
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    claims.add(mapResultSetToClaim(rs));
                }
            }
            
            logger.info("Found {} claims with status: {}", claims.size(), status);
            return claims;
            
        } catch (SQLException e) {
            logger.error("Error finding claims by status: {}", status, e);
            throw new DatabaseException("Failed to find claims by status: " + status, e);
        }
    }
}
