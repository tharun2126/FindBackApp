package com.findback.dao;

import com.findback.model.Notification;

import java.util.List;
import java.util.Optional;

/**
 * Data Access Object interface for Notification entities.
 * 
 * Defines the database operations for notification management.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public interface NotificationDAO {
    
    /**
     * Save a new notification to the database.
     * 
     * @param notification the notification to save
     * @return the saved notification with generated ID
     */
    Notification save(Notification notification);
    
    /**
     * Update an existing notification in the database.
     * 
     * @param notification the notification to update
     * @return the updated notification
     */
    Notification update(Notification notification);
    
    /**
     * Delete a notification by ID.
     * 
     * @param notificationId the notification ID to delete
     * @return true if deleted, false otherwise
     */
    boolean delete(Integer notificationId);
    
    /**
     * Find a notification by ID.
     * 
     * @param notificationId the notification ID to search for
     * @return Optional containing the notification if found
     */
    Optional<Notification> findById(Integer notificationId);
    
    /**
     * Find all notifications by user ID.
     * 
     * @param userId the user ID to search for
     * @return list of notifications for the user
     */
    List<Notification> findByUserId(Integer userId);
    
    /**
     * Find all unread notifications by user ID.
     * 
     * @param userId the user ID to search for
     * @return list of unread notifications for the user
     */
    List<Notification> findUnread(Integer userId);
    
    /**
     * Mark a notification as read.
     * 
     * @param notificationId the notification ID to mark as read
     * @return true if marked as read, false otherwise
     */
    boolean markAsRead(Integer notificationId);
}
