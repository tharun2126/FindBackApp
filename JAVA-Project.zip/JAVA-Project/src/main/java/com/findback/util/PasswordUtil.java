package com.findback.util;

import org.mindrot.jbcrypt.BCrypt;

/**
 * Utility class for password hashing and verification using BCrypt.
 * 
 * This class provides secure password operations for authentication.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public class PasswordUtil {
    
    /**
     * Private constructor to prevent instantiation.
     */
    private PasswordUtil() {
        throw new AssertionError("PasswordUtil class should not be instantiated");
    }
    
    /**
     * Hash a plain text password using BCrypt.
     * 
     * @param plainPassword the plain text password to hash
     * @return the hashed password
     * @throws IllegalArgumentException if plainPassword is null or empty
     */
    public static String hashPassword(String plainPassword) {
        if (plainPassword == null || plainPassword.trim().isEmpty()) {
            throw new IllegalArgumentException("Password cannot be null or empty");
        }
        return BCrypt.hashpw(plainPassword, BCrypt.gensalt());
    }
    
    /**
     * Verify a plain text password against a hashed password.
     * 
     * @param plainPassword the plain text password to verify
     * @param hashedPassword the hashed password to compare against
     * @return true if the password matches, false otherwise
     * @throws IllegalArgumentException if any parameter is null or empty
     */
    public static boolean verifyPassword(String plainPassword, String hashedPassword) {
        if (plainPassword == null || plainPassword.trim().isEmpty()) {
            throw new IllegalArgumentException("Plain password cannot be null or empty");
        }
        if (hashedPassword == null || hashedPassword.trim().isEmpty()) {
            throw new IllegalArgumentException("Hashed password cannot be null or empty");
        }
        return BCrypt.checkpw(plainPassword, hashedPassword);
    }
}
