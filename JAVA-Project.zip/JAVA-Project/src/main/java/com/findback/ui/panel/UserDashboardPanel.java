package com.findback.ui.panel;

import com.findback.model.User;
import com.findback.ui.frame.MainFrame;
import com.findback.ui.util.UIUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.*;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.*;

/**
 * User dashboard panel showing structured, categorized navigation options.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public class UserDashboardPanel extends JPanel {
    
    private static final Logger logger = LoggerFactory.getLogger(UserDashboardPanel.class);
    
    private final MainFrame mainFrame;
    private User currentUser;
    
    private JLabel userLabel;
    private JLabel roleLabel;
    private JButton adminDashboardButton;
    
    /**
     * Constructor with dependency injection.
     * 
     * @param mainFrame the main frame for navigation
     */
    public UserDashboardPanel(MainFrame mainFrame) {
        this.mainFrame = mainFrame;
        
        initializeUI();
    }
    
    /**
     * Initialize the UI components.
     */
    private void initializeUI() {
        setLayout(new BorderLayout(0, 15));
        setBorder(new EmptyBorder(15, 25, 20, 25));
        
        // Header / Welcome panel
        JPanel headerPanel = createHeaderPanel();
        add(headerPanel, BorderLayout.NORTH);
        
        // Main grouped dashboard content
        JPanel contentPanel = createContentPanel();
        add(contentPanel, BorderLayout.CENTER);
        
        // Footer panel with logout
        JPanel footerPanel = createFooterPanel();
        add(footerPanel, BorderLayout.SOUTH);
        
        logger.debug("UserDashboardPanel initialized");
    }
    
    /**
     * Create the header panel with branding and user identity badge.
     */
    private JPanel createHeaderPanel() {
        JPanel panel = new JPanel(new BorderLayout(15, 10));
        panel.setOpaque(false);
        
        // App title branding
        JPanel brandPanel = new JPanel();
        brandPanel.setLayout(new BoxLayout(brandPanel, BoxLayout.Y_AXIS));
        brandPanel.setOpaque(false);
        
        JLabel titleLabel = new JLabel("FindBack - AI Lost & Found");
        titleLabel.setFont(UIUtils.FONT_TITLE);
        titleLabel.setForeground(UIUtils.COLOR_PRIMARY);
        
        JLabel subtitleLabel = new JLabel("AI-Powered Semantic & Image Matching Dashboard");
        subtitleLabel.setFont(UIUtils.FONT_SUBTITLE);
        subtitleLabel.setForeground(UIUtils.COLOR_TEXT_MUTED);
        
        brandPanel.add(titleLabel);
        brandPanel.add(Box.createVerticalStrut(4));
        brandPanel.add(subtitleLabel);
        
        // User profile card on right
        JPanel userCard = new JPanel();
        userCard.setLayout(new BoxLayout(userCard, BoxLayout.Y_AXIS));
        userCard.setBackground(UIUtils.COLOR_CARD_BG);
        userCard.setBorder(new CompoundBorder(
                new LineBorder(UIUtils.COLOR_CARD_BORDER, 1, true),
                new EmptyBorder(10, 16, 10, 16)
        ));
        
        userLabel = new JLabel("User: Not logged in");
        userLabel.setFont(UIUtils.FONT_LABEL);
        userLabel.setForeground(UIUtils.COLOR_TEXT_MAIN);
        
        roleLabel = new JLabel("Role: -");
        roleLabel.setFont(UIUtils.FONT_SMALL);
        roleLabel.setForeground(UIUtils.COLOR_TEXT_MUTED);
        
        userCard.add(userLabel);
        userCard.add(Box.createVerticalStrut(3));
        userCard.add(roleLabel);
        
        panel.add(brandPanel, BorderLayout.WEST);
        panel.add(userCard, BorderLayout.EAST);
        
        return panel;
    }
    
    /**
     * Create grouped 2-column dashboard layout.
     */
    private JPanel createContentPanel() {
        JPanel gridPanel = new JPanel(new GridLayout(1, 2, 20, 0));
        gridPanel.setOpaque(false);
        
        // Column 1: Item Management Section
        JPanel itemMgmtCard = createSectionCard("Item Management");
        JPanel itemButtons = new JPanel(new GridLayout(4, 1, 0, 12));
        itemButtons.setOpaque(false);
        
        JButton reportLostButton = UIUtils.createPrimaryButton("Report Lost Item", new Dimension(220, 38));
        reportLostButton.addActionListener(e -> handleReportLostItem());
        
        JButton reportFoundButton = UIUtils.createPrimaryButton("Report Found Item", new Dimension(220, 38));
        reportFoundButton.addActionListener(e -> handleReportFoundItem());
        
        JButton myLostItemsButton = UIUtils.createSecondaryButton("My Lost Items", new Dimension(220, 38));
        myLostItemsButton.addActionListener(e -> handleMyLostItems());
        
        JButton myFoundItemsButton = UIUtils.createSecondaryButton("My Found Items", new Dimension(220, 38));
        myFoundItemsButton.addActionListener(e -> handleMyFoundItems());
        
        itemButtons.add(reportLostButton);
        itemButtons.add(reportFoundButton);
        itemButtons.add(myLostItemsButton);
        itemButtons.add(myFoundItemsButton);
        itemMgmtCard.add(itemButtons, BorderLayout.CENTER);
        
        // Column 2: AI Matching & Claims Section
        JPanel matchingCard = createSectionCard("AI Matching & Verification");
        JPanel matchingButtons = new JPanel(new GridLayout(4, 1, 0, 12));
        matchingButtons.setOpaque(false);
        
        JButton matchingResultsButton = UIUtils.createPrimaryButton("AI Matching Results", new Dimension(220, 38));
        matchingResultsButton.addActionListener(e -> handleMatchingResults());
        
        JButton myClaimsButton = UIUtils.createSecondaryButton("My Claims", new Dimension(220, 38));
        myClaimsButton.addActionListener(e -> handleMyClaims());
        
        JButton notificationsButton = UIUtils.createSecondaryButton("Notifications", new Dimension(220, 38));
        notificationsButton.addActionListener(e -> handleNotifications());
        
        adminDashboardButton = UIUtils.createPrimaryButton("Admin Dashboard", new Dimension(220, 38));
        adminDashboardButton.addActionListener(e -> handleAdminDashboard());
        adminDashboardButton.setVisible(false); // Hidden by default
        
        matchingButtons.add(matchingResultsButton);
        matchingButtons.add(myClaimsButton);
        matchingButtons.add(notificationsButton);
        matchingButtons.add(adminDashboardButton);
        matchingCard.add(matchingButtons, BorderLayout.CENTER);
        
        gridPanel.add(itemMgmtCard);
        gridPanel.add(matchingCard);
        
        return gridPanel;
    }
    
    /**
     * Helper to create a section card with a styled title.
     */
    private JPanel createSectionCard(String sectionTitle) {
        JPanel card = new JPanel(new BorderLayout(0, 15));
        card.setBackground(Color.WHITE);
        card.setBorder(new CompoundBorder(
                new LineBorder(UIUtils.COLOR_CARD_BORDER, 1, true),
                new EmptyBorder(16, 20, 20, 20)
        ));
        
        JLabel headerLabel = new JLabel(sectionTitle);
        headerLabel.setFont(UIUtils.FONT_SECTION_HEADER);
        headerLabel.setForeground(UIUtils.COLOR_PRIMARY);
        headerLabel.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, UIUtils.COLOR_TABLE_GRID));
        
        card.add(headerLabel, BorderLayout.NORTH);
        return card;
    }
    
    /**
     * Create footer panel with logout option.
     */
    private JPanel createFooterPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
        panel.setOpaque(false);
        
        JButton logoutButton = UIUtils.createSecondaryButton("Logout", new Dimension(120, 32));
        logoutButton.addActionListener(e -> handleLogout());
        
        panel.add(logoutButton);
        return panel;
    }
    
    /**
     * Set the current logged-in user and update profile badge.
     * 
     * @param user the logged-in user
     */
    public void setCurrentUser(User user) {
        this.currentUser = user;
        
        if (user != null) {
            userLabel.setText("User: " + user.getFullName());
            roleLabel.setText("Role: " + user.getRole());
            if (user.isAdmin()) {
                roleLabel.setForeground(UIUtils.COLOR_SUCCESS);
            } else {
                roleLabel.setForeground(UIUtils.COLOR_TEXT_MUTED);
            }
            adminDashboardButton.setVisible(user.isAdmin());
        } else {
            userLabel.setText("User: Not logged in");
            roleLabel.setText("Role: -");
            roleLabel.setForeground(UIUtils.COLOR_TEXT_MUTED);
            adminDashboardButton.setVisible(false);
        }
        
        logger.debug("Current user set: {}", user != null ? user.getUsername() : "null");
    }
    
    private void handleReportLostItem() {
        logger.debug("Navigate to Report Lost Item panel");
        mainFrame.showReportLostItem();
    }
    
    private void handleReportFoundItem() {
        logger.debug("Navigate to Report Found Item panel");
        mainFrame.showReportFoundItem();
    }
    
    private void handleMyLostItems() {
        logger.debug("Navigate to My Lost Items panel");
        mainFrame.showMyLostItems();
    }
    
    private void handleMyFoundItems() {
        logger.debug("Navigate to My Found Items panel");
        mainFrame.showMyFoundItems();
    }
    
    private void handleMatchingResults() {
        logger.debug("Navigate to AI Matching Results panel");
        mainFrame.showMatchingResults();
    }
    
    private void handleMyClaims() {
        logger.debug("Navigate to My Claims panel");
        mainFrame.showMyClaims();
    }
    
    private void handleNotifications() {
        logger.debug("Navigate to Notifications panel");
        mainFrame.showNotifications();
    }
    
    private void handleAdminDashboard() {
        logger.debug("Navigate to Admin Dashboard panel");
        mainFrame.showAdminDashboard();
    }
    
    private void handleLogout() {
        logger.info("User requested logout");
        
        if (UIUtils.showConfirmDialog(this, 
                "Are you sure you want to logout?", 
                "Confirm Logout")) {
            mainFrame.logout();
            mainFrame.showLogin();
            logger.info("User logged out successfully");
        }
    }
}
