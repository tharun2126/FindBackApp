package com.findback.ui.panel;

import com.findback.model.FoundItem;
import com.findback.model.LostItem;
import com.findback.model.Match;
import com.findback.model.Notification;
import com.findback.model.User;
import com.findback.service.FoundItemService;
import com.findback.service.MatchService;
import com.findback.service.NotificationService;
import com.findback.ui.frame.MainFrame;
import com.findback.ui.util.UIUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

/**
 * Panel for reporting a found item.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public class ReportFoundItemPanel extends JPanel {
    
    private static final Logger logger = LoggerFactory.getLogger(ReportFoundItemPanel.class);
    
    private final MainFrame mainFrame;
    private final FoundItemService foundItemService;
    private final MatchService matchService;
    private final NotificationService notificationService;
    
    private JTextField categoryField;
    private JTextField brandField;
    private JTextField colourField;
    private JTextArea descriptionArea;
    private JTextField locationField;
    private JTextField dateField;
    private JTextField imagePathField;
    private JButton chooseImageButton;
    private JButton submitButton;
    private JButton cancelButton;
    
    private String selectedImagePath;
    
    /**
     * Constructor with dependency injection.
     * 
     * @param mainFrame the main frame for navigation
     * @param foundItemService the FoundItemService to use
     * @param matchService the MatchService to use
     * @param notificationService the NotificationService to use
     */
    public ReportFoundItemPanel(MainFrame mainFrame, FoundItemService foundItemService, 
                              MatchService matchService, NotificationService notificationService) {
        this.mainFrame = mainFrame;
        this.foundItemService = foundItemService;
        this.matchService = matchService;
        this.notificationService = notificationService;
        
        initializeUI();
    }
    
    /**
     * Initialize the UI components.
     */
    private void initializeUI() {
        setLayout(new BorderLayout());
        
        // Create title panel
        JPanel titlePanel = createTitlePanel();
        add(titlePanel, BorderLayout.NORTH);
        
        // Create form panel
        JPanel formPanel = createFormPanel();
        add(formPanel, BorderLayout.CENTER);
        
        logger.debug("ReportFoundItemPanel initialized");
    }
    
    /**
     * Create the title panel.
     */
    private JPanel createTitlePanel() {
        return UIUtils.createTitlePanel("FindBack - AI Lost & Found", "Report a Found Item");
    }
    
    /**
     * Create the form panel with input fields and buttons.
     */
    private JPanel createFormPanel() {
        JPanel wrapper = new JPanel(new GridBagLayout());
        wrapper.setOpaque(false);
        
        JPanel card = new JPanel(new GridBagLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UIUtils.COLOR_CARD_BORDER, 1, true),
                BorderFactory.createEmptyBorder(20, 35, 20, 35)
        ));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 10, 6, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Category
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0;
        JLabel catLabel = new JLabel("Category*:");
        catLabel.setFont(UIUtils.FONT_LABEL);
        card.add(catLabel, gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        categoryField = new JTextField(20);
        categoryField.setFont(UIUtils.FONT_REGULAR);
        categoryField.setPreferredSize(new Dimension(260, 28));
        card.add(categoryField, gbc);
        
        // Brand
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weightx = 0;
        JLabel brandLabel = new JLabel("Brand:");
        brandLabel.setFont(UIUtils.FONT_LABEL);
        card.add(brandLabel, gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        brandField = new JTextField(20);
        brandField.setFont(UIUtils.FONT_REGULAR);
        brandField.setPreferredSize(new Dimension(260, 28));
        card.add(brandField, gbc);
        
        // Colour
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.weightx = 0;
        JLabel colLabel = new JLabel("Colour:");
        colLabel.setFont(UIUtils.FONT_LABEL);
        card.add(colLabel, gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        colourField = new JTextField(20);
        colourField.setFont(UIUtils.FONT_REGULAR);
        colourField.setPreferredSize(new Dimension(260, 28));
        card.add(colourField, gbc);
        
        // Description
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.weightx = 0;
        JLabel descLabel = new JLabel("Description*:");
        descLabel.setFont(UIUtils.FONT_LABEL);
        card.add(descLabel, gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        descriptionArea = new JTextArea(3, 20);
        descriptionArea.setFont(UIUtils.FONT_REGULAR);
        descriptionArea.setLineWrap(true);
        descriptionArea.setWrapStyleWord(true);
        JScrollPane descScrollPane = new JScrollPane(descriptionArea);
        descScrollPane.setPreferredSize(new Dimension(260, 60));
        card.add(descScrollPane, gbc);
        
        // Location
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.weightx = 0;
        JLabel locLabel = new JLabel("Location Found*:");
        locLabel.setFont(UIUtils.FONT_LABEL);
        card.add(locLabel, gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        locationField = new JTextField(20);
        locationField.setFont(UIUtils.FONT_REGULAR);
        locationField.setPreferredSize(new Dimension(260, 28));
        card.add(locationField, gbc);
        
        // Date Found
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.weightx = 0;
        JLabel dateLabel = new JLabel("Date Found*:");
        dateLabel.setFont(UIUtils.FONT_LABEL);
        card.add(dateLabel, gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        dateField = new JTextField(20);
        dateField.setFont(UIUtils.FONT_REGULAR);
        dateField.setPreferredSize(new Dimension(260, 28));
        dateField.setText(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")));
        card.add(dateField, gbc);
        
        // Image Path
        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.weightx = 0;
        JLabel imgLabel = new JLabel("Image (Optional):");
        imgLabel.setFont(UIUtils.FONT_LABEL);
        card.add(imgLabel, gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        JPanel imagePanel = new JPanel(new BorderLayout(8, 0));
        imagePanel.setOpaque(false);
        imagePathField = new JTextField(15);
        imagePathField.setFont(UIUtils.FONT_REGULAR);
        imagePathField.setEditable(false);
        chooseImageButton = UIUtils.createSecondaryButton("Choose Image", new Dimension(120, 28));
        chooseImageButton.addActionListener(e -> handleChooseImage());
        
        imagePanel.add(imagePathField, BorderLayout.CENTER);
        imagePanel.add(chooseImageButton, BorderLayout.EAST);
        card.add(imagePanel, gbc);
        
        // Button panel
        gbc.gridx = 0;
        gbc.gridy = 7;
        gbc.gridwidth = 2;
        gbc.weightx = 0;
        gbc.insets = new Insets(16, 10, 5, 10);
        gbc.fill = GridBagConstraints.CENTER;
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 14, 0));
        buttonPanel.setOpaque(false);
        
        submitButton = UIUtils.createPrimaryButton("Submit Found Item", new Dimension(160, 34));
        submitButton.addActionListener(e -> handleSubmit());
        
        cancelButton = UIUtils.createSecondaryButton("Cancel", new Dimension(110, 34));
        cancelButton.addActionListener(e -> handleCancel());
        
        buttonPanel.add(submitButton);
        buttonPanel.add(cancelButton);
        
        card.add(buttonPanel, gbc);
        wrapper.add(card);
        
        JScrollPane scrollPane = new JScrollPane(wrapper);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(12);
        
        JPanel container = new JPanel(new BorderLayout());
        container.add(scrollPane, BorderLayout.CENTER);
        return container;
    }
    
    /**
     * Handle choose image button click.
     */
    private void handleChooseImage() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileFilter(new FileNameExtensionFilter(
                "Image files", "jpg", "jpeg", "png"));
        
        int result = fileChooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            
            // Validate that file exists and is an image
            if (selectedFile.exists() && selectedFile.isFile()) {
                String fileName = selectedFile.getName().toLowerCase();
                if (fileName.endsWith(".jpg") || fileName.endsWith(".jpeg") || fileName.endsWith(".png")) {
                    selectedImagePath = selectedFile.getAbsolutePath();
                    imagePathField.setText(selectedFile.getName());
                    logger.debug("Image selected: {}", selectedImagePath);
                } else {
                    UIUtils.showErrorDialog(this, 
                            "Please select a valid image file (JPG, JPEG, or PNG)", 
                            "Invalid Image");
                }
            } else {
                UIUtils.showErrorDialog(this, 
                        "Selected file does not exist or is not a valid file", 
                        "Invalid File");
            }
        }
    }
    
    /**
     * Handle submit button click.
     */
    private void handleSubmit() {
        String category = categoryField.getText().trim();
        String brand = brandField.getText().trim();
        String colour = colourField.getText().trim();
        String description = descriptionArea.getText().trim();
        String location = locationField.getText().trim();
        String dateStr = dateField.getText().trim();
        
        // Validate required fields
        if (UIUtils.isNullOrEmpty(category)) {
            UIUtils.showErrorDialog(this, "Please enter the category", "Validation Error");
            return;
        }
        
        if (UIUtils.isNullOrEmpty(description)) {
            UIUtils.showErrorDialog(this, "Please enter a description", "Validation Error");
            return;
        }
        
        if (description.length() < 10) {
            UIUtils.showErrorDialog(this, "Description must be at least 10 characters long", "Validation Error");
            return;
        }
        
        if (UIUtils.isNullOrEmpty(location)) {
            UIUtils.showErrorDialog(this, "Please enter the location where the item was found", "Validation Error");
            return;
        }
        
        if (UIUtils.isNullOrEmpty(dateStr)) {
            UIUtils.showErrorDialog(this, "Please enter the date when the item was found", "Validation Error");
            return;
        }
        
        // Parse date
        LocalDateTime dateFound;
        try {
            dateFound = LocalDateTime.parse(dateStr, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
        } catch (Exception e) {
            UIUtils.showErrorDialog(this, 
                    "Invalid date format. Please use format: yyyy-MM-dd HH:mm", 
                    "Validation Error");
            return;
        }
        
        // Get current user
        User currentUser = mainFrame.getCurrentUser();
        if (currentUser == null) {
            UIUtils.showErrorDialog(this, "You must be logged in to report a found item", "Authentication Error");
            mainFrame.showLogin();
            return;
        }
        
        // Create found item object
        FoundItem foundItem = new FoundItem();
        foundItem.setUserId(currentUser.getUserId());
        foundItem.setCategory(UIUtils.isNullOrEmpty(category) ? null : category);
        foundItem.setBrand(UIUtils.isNullOrEmpty(brand) ? null : brand);
        foundItem.setColour(UIUtils.isNullOrEmpty(colour) ? null : colour);
        foundItem.setDescription(description);
        foundItem.setLocationFound(location);
        foundItem.setDateFound(dateFound);
        foundItem.setImagePath(UIUtils.isNullOrEmpty(selectedImagePath) ? null : selectedImagePath);
        foundItem.setStatus(FoundItem.ItemStatus.ACTIVE);
        
        // Submit in background thread
        SwingWorker<FoundItem, Void> worker = new SwingWorker<>() {
            @Override
            protected FoundItem doInBackground() throws Exception {
                logger.info("Submitting found item for user: {}", currentUser.getUsername());
                return foundItemService.createFoundItem(foundItem);
            }
            
            @Override
            protected void done() {
                try {
                    FoundItem createdItem = get();
                    logger.info("Found item created successfully: {}", createdItem.getFoundItemId());
                    
                    // Trigger AI matching in background
                    triggerAIMatching(createdItem);
                    
                    UIUtils.showInfoDialog(ReportFoundItemPanel.this, 
                            "Found item reported successfully!\n\nItem ID: " + createdItem.getFoundItemId() + 
                            "\n\nAI matching is being processed. You will be notified if high-confidence matches are found.", 
                            "Success");
                    
                    // Clear form and return to dashboard
                    clearForm();
                    mainFrame.showDashboard();
                    
                } catch (Exception e) {
                    UIUtils.showErrorDialog(ReportFoundItemPanel.this, 
                            "Failed to report found item. Please try again.", 
                            "Error");
                    logger.error("Error creating found item", e);
                }
            }
        };
        
        worker.execute();
    }
    
    /**
     * Trigger AI matching for the newly created found item.
     * This runs in a separate background thread to keep UI responsive.
     */
    private void triggerAIMatching(FoundItem foundItem) {
        SwingWorker<Void, Void> matchingWorker = new SwingWorker<>() {
            @Override
            protected Void doInBackground() throws Exception {
                logger.info("Triggering AI matching for found item ID: {}", foundItem.getFoundItemId());
                
                // Trigger matching using MatchService
                int matchesCreated = matchService.triggerMatchingForFoundItem(foundItem.getFoundItemId());
                logger.info("AI matching complete. {} matches created for found item {}", 
                          matchesCreated, foundItem.getFoundItemId());
                
                // If matches were created, check for high-confidence matches and create notifications
                if (matchesCreated > 0) {
                    List<Match> matches = matchService.getMatchesByFoundItem(foundItem.getFoundItemId());
                    createHighConfidenceNotifications(matches, foundItem);
                }
                
                return null;
            }
            
            @Override
            protected void done() {
                try {
                    get();
                    logger.debug("AI matching background task completed");
                } catch (Exception e) {
                    logger.error("Error during AI matching", e);
                }
            }
        };
        
        matchingWorker.execute();
    }
    
    /**
     * Create notifications for high-confidence matches.
     */
    private void createHighConfidenceNotifications(List<Match> matches, FoundItem foundItem) {
        if (matches == null || matches.isEmpty()) {
            return;
        }
        
        // Notification threshold is 80% (0.80)
        double notificationThreshold = 0.80;
        
        for (Match match : matches) {
            if (match.getOverallConfidenceScore() != null && 
                match.getOverallConfidenceScore().doubleValue() >= notificationThreshold) {
                
                try {
                    double confidencePercent = match.getOverallConfidenceScore().multiply(
                        new java.math.BigDecimal("100")).doubleValue();
                    
                    // Notify the owner of the lost item
                    Integer lostItemUserId = null;
                    if (mainFrame.getLostItemService() != null && match.getLostItemId() != null) {
                        Optional<LostItem> lostItemOpt = mainFrame.getLostItemService().findLostItemById(match.getLostItemId());
                        if (lostItemOpt.isPresent()) {
                            lostItemUserId = lostItemOpt.get().getUserId();
                        }
                    }
                    
                    if (lostItemUserId != null) {
                        String lostOwnerMessage = String.format(
                            "AI found a possible match for your lost item. Match confidence: %.1f%%. " +
                            "Please review and verify ownership.", confidencePercent);
                        
                        notificationService.createNotification(
                            lostItemUserId,
                            "Possible Match Found",
                            lostOwnerMessage,
                            Notification.NotificationType.MATCH_FOUND,
                            match.getMatchId()
                        );
                        logger.info("Created notification for lost item owner {} on match: {}", lostItemUserId, match.getMatchId());
                    }
                    
                    // Also notify finder if different from lost item owner
                    User currentUser = mainFrame.getCurrentUser();
                    if (currentUser != null && (lostItemUserId == null || !currentUser.getUserId().equals(lostItemUserId))) {
                        String finderMessage = String.format(
                            "AI found a possible match for your reported found item. Match confidence: %.1f%%.", confidencePercent);
                        
                        notificationService.createNotification(
                            currentUser.getUserId(),
                            "Possible Match Found",
                            finderMessage,
                            Notification.NotificationType.MATCH_FOUND,
                            match.getMatchId()
                        );
                        logger.info("Created notification for finder {} on match: {}", currentUser.getUserId(), match.getMatchId());
                    }
                } catch (Exception e) {
                    logger.error("Error creating notification for match: {}", match.getMatchId(), e);
                }
            }
        }
    }
    
    /**
     * Handle cancel button click.
     */
    private void handleCancel() {
        logger.debug("Cancel clicked - return to dashboard");
        clearForm();
        mainFrame.showDashboard();
    }
    
    /**
     * Clear the form fields.
     */
    public void clearForm() {
        categoryField.setText("");
        brandField.setText("");
        colourField.setText("");
        descriptionArea.setText("");
        locationField.setText("");
        dateField.setText(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")));
        imagePathField.setText("");
        selectedImagePath = null;
    }
}
