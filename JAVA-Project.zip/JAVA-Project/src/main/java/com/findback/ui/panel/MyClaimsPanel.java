package com.findback.ui.panel;

import com.findback.model.Claim;
import com.findback.model.User;
import com.findback.service.ClaimService;
import com.findback.service.MatchService;
import com.findback.ui.frame.MainFrame;
import com.findback.ui.util.UIUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * Panel for displaying the logged-in user's submitted claims.
 * 
 * Shows claim ID, match ID, status, submission date, and admin verification details.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public class MyClaimsPanel extends JPanel {
    
    private static final Logger logger = LoggerFactory.getLogger(MyClaimsPanel.class);
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
    
    private final MainFrame mainFrame;
    private final ClaimService claimService;
    private final MatchService matchService;
    
    private JTable claimsTable;
    private DefaultTableModel tableModel;
    private JButton refreshButton;
    private JButton viewDetailsButton;
    private JButton backButton;
    private JLabel loadingLabel;
    
    private List<Claim> currentClaims = new ArrayList<>();
    
    /**
     * Constructor with dependency injection.
     * 
     * @param mainFrame the main frame for navigation
     * @param claimService the ClaimService to use
     * @param matchService the MatchService to use
     */
    public MyClaimsPanel(MainFrame mainFrame, ClaimService claimService, MatchService matchService) {
        this.mainFrame = mainFrame;
        this.claimService = claimService;
        this.matchService = matchService;
        
        initializeUI();
        if (mainFrame.getCurrentUser() != null) {
            loadClaims();
        }
    }
    
    /**
     * Constructor without MatchService for backward compatibility.
     * 
     * @param mainFrame the main frame for navigation
     * @param claimService the ClaimService to use
     */
    public MyClaimsPanel(MainFrame mainFrame, ClaimService claimService) {
        this(mainFrame, claimService, null);
    }
    
    /**
     * Initialize the UI components.
     */
    private void initializeUI() {
        setLayout(new BorderLayout());
        
        // Create title panel
        JPanel titlePanel = createTitlePanel();
        add(titlePanel, BorderLayout.NORTH);
        
        // Create content panel
        JPanel contentPanel = createContentPanel();
        add(contentPanel, BorderLayout.CENTER);
        
        // Create button panel
        JPanel buttonPanel = createButtonPanel();
        add(buttonPanel, BorderLayout.SOUTH);
        
        logger.debug("MyClaimsPanel initialized");
    }
    
    /**
     * Create the title panel.
     */
    private JPanel createTitlePanel() {
        return UIUtils.createTitlePanel(
                "My Claims",
                "View status and administrative review of your submitted claims"
        );
    }
    
    /**
     * Create the content panel with claims table.
     */
    private JPanel createContentPanel() {
        JPanel panel = new JPanel(new BorderLayout(0, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 24, 10, 24));
        panel.setOpaque(false);
        
        // Create table model
        String[] columnNames = {"Claim ID", "Match ID", "Status", "Date Submitted", "Verified Date", "Admin Notes"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        // Create table
        claimsTable = new JTable(tableModel);
        claimsTable.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        claimsTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        // Format table using UIUtils
        UIUtils.formatTable(claimsTable);
        UIUtils.centerAlignColumns(claimsTable, 0, 1, 3, 4);
        claimsTable.getColumnModel().getColumn(2).setCellRenderer(UIUtils.createStatusCellRenderer());
        
        // Column widths
        claimsTable.getColumnModel().getColumn(0).setPreferredWidth(70);
        claimsTable.getColumnModel().getColumn(1).setPreferredWidth(70);
        claimsTable.getColumnModel().getColumn(2).setPreferredWidth(110);
        claimsTable.getColumnModel().getColumn(3).setPreferredWidth(140);
        claimsTable.getColumnModel().getColumn(4).setPreferredWidth(140);
        claimsTable.getColumnModel().getColumn(5).setPreferredWidth(220);
        
        // Listen to selection changes to toggle View Details button
        claimsTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                boolean hasSelection = claimsTable.getSelectedRow() >= 0;
                viewDetailsButton.setEnabled(hasSelection);
            }
        });
        
        // Create scroll pane
        JScrollPane scrollPane = new JScrollPane(claimsTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(UIUtils.COLOR_BORDER, 1));
        
        // Create loading label
        loadingLabel = new JLabel("Loading claims...", SwingConstants.CENTER);
        loadingLabel.setFont(UIUtils.FONT_LABEL);
        loadingLabel.setForeground(UIUtils.COLOR_TEXT_SECONDARY);
        loadingLabel.setBorder(BorderFactory.createEmptyBorder(6, 0, 6, 0));
        
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(loadingLabel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    /**
     * Create the button panel.
     */
    private JPanel createButtonPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 14, 14));
        panel.setOpaque(false);
        
        refreshButton = UIUtils.createSecondaryButton("Refresh", e -> loadClaims());
        refreshButton.setPreferredSize(new Dimension(120, 36));
        
        viewDetailsButton = UIUtils.createPrimaryButton("View Details", e -> handleViewDetails());
        viewDetailsButton.setPreferredSize(new Dimension(130, 36));
        viewDetailsButton.setEnabled(false);
        
        backButton = UIUtils.createSecondaryButton("Back to Dashboard", e -> handleBack());
        backButton.setPreferredSize(new Dimension(170, 36));
        
        panel.add(refreshButton);
        panel.add(viewDetailsButton);
        panel.add(backButton);
        
        return panel;
    }
    
    /**
     * Load claims for the current logged-in user.
     */
    public void loadClaims() {
        User currentUser = mainFrame.getCurrentUser();
        if (currentUser == null) {
            UIUtils.showErrorDialog(this, "You must be logged in to view your claims", "Authentication Error");
            mainFrame.showLogin();
            return;
        }
        
        loadingLabel.setText("Loading claims...");
        tableModel.setRowCount(0);
        claimsTable.setEnabled(false);
        refreshButton.setEnabled(false);
        viewDetailsButton.setEnabled(false);
        
        SwingWorker<List<Claim>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<Claim> doInBackground() throws Exception {
                logger.info("Loading claims for user: {}", currentUser.getUsername());
                return claimService.getClaimsByUser(currentUser.getUserId());
            }
            
            @Override
            protected void done() {
                try {
                    currentClaims = get();
                    tableModel.setRowCount(0);
                    
                    if (currentClaims.isEmpty()) {
                        loadingLabel.setText("No claims found. Claims can be submitted from AI Matching Results.");
                    } else {
                        loadingLabel.setText("");
                        
                        for (Claim claim : currentClaims) {
                            String submittedDateStr = claim.getCreatedAt() != null ? 
                                    claim.getCreatedAt().format(DATE_FORMATTER) : "-";
                            String verifiedDateStr = claim.getVerifiedAt() != null ? 
                                    claim.getVerifiedAt().format(DATE_FORMATTER) : "-";
                            String notes = claim.getVerificationNotes() != null && !claim.getVerificationNotes().isBlank() ? 
                                    claim.getVerificationNotes() : "-";
                            
                            Object[] row = {
                                claim.getClaimId(),
                                claim.getMatchId(),
                                claim.getClaimStatus() != null ? claim.getClaimStatus().name() : "-",
                                submittedDateStr,
                                verifiedDateStr,
                                notes
                            };
                            tableModel.addRow(row);
                        }
                        
                        logger.info("Loaded {} claims for user: {}", currentClaims.size(), currentUser.getUsername());
                    }
                } catch (Exception e) {
                    loadingLabel.setText("Error loading claims. Please try again.");
                    UIUtils.showErrorDialog(MyClaimsPanel.this, 
                            "Failed to load claims. Please try again.", 
                            "Error");
                    logger.error("Error loading claims for user: {}", currentUser.getUsername(), e);
                } finally {
                    claimsTable.setEnabled(true);
                    refreshButton.setEnabled(true);
                }
            }
        };
        
        worker.execute();
    }
    
    /**
     * Handle View Details button click.
     */
    private void handleViewDetails() {
        int selectedRow = claimsTable.getSelectedRow();
        if (selectedRow < 0 || selectedRow >= currentClaims.size()) {
            UIUtils.showErrorDialog(this, "Please select a claim to view details", "Selection Error");
            return;
        }
        
        Claim claim = currentClaims.get(selectedRow);
        
        StringBuilder details = new StringBuilder();
        details.append("Claim Information:\n");
        details.append("==================\n");
        details.append(String.format("Claim ID: %d\n", claim.getClaimId()));
        details.append(String.format("Match ID: %d\n", claim.getMatchId()));
        details.append(String.format("User ID: %d\n", claim.getUserId()));
        details.append(String.format("Status: %s\n", claim.getClaimStatus()));
        details.append(String.format("Submitted At: %s\n", 
                claim.getCreatedAt() != null ? claim.getCreatedAt().format(DATE_FORMATTER) : "-"));
        
        details.append("\nAdmin Verification Information:\n");
        details.append("===============================\n");
        if (claim.getAdminId() != null) {
            details.append(String.format("Admin Reviewer ID: %d\n", claim.getAdminId()));
        } else {
            details.append("Admin Reviewer: Pending review\n");
        }
        
        if (claim.getVerifiedAt() != null) {
            details.append(String.format("Verified/Processed Date: %s\n", 
                    claim.getVerifiedAt().format(DATE_FORMATTER)));
        } else {
            details.append("Verified Date: Not yet verified\n");
        }
        
        details.append(String.format("Verification / Admin Notes: %s\n", 
                claim.getVerificationNotes() != null && !claim.getVerificationNotes().isBlank() ? 
                        claim.getVerificationNotes() : "None"));
        
        JTextArea textArea = new JTextArea(details.toString());
        textArea.setEditable(false);
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(500, 300));
        
        JOptionPane.showMessageDialog(this, scrollPane, "Claim Details - Claim #" + claim.getClaimId(), 
                JOptionPane.INFORMATION_MESSAGE);
    }
    
    /**
     * Handle back button click.
     */
    private void handleBack() {
        logger.debug("Back to dashboard");
        mainFrame.showDashboard();
    }
}
