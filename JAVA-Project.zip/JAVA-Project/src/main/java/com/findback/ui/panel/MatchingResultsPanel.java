package com.findback.ui.panel;

import com.findback.model.FoundItem;
import com.findback.model.LostItem;
import com.findback.model.Match;
import com.findback.model.User;
import com.findback.service.FoundItemService;
import com.findback.service.LostItemService;
import com.findback.service.MatchService;
import com.findback.ui.frame.MainFrame;
import com.findback.ui.util.UIUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Panel for displaying AI matching results.
 * 
 * Supports viewing matches for both the user's reported lost items (with claiming capability)
 * and the user's reported found items (informational metrics, strictly preserving claimant privacy).
 * 
 * @author FindBack Team
 * @version 1.1.0
 */
public class MatchingResultsPanel extends JPanel {
    
    private static final Logger logger = LoggerFactory.getLogger(MatchingResultsPanel.class);
    
    public static final String MODE_LOST_ITEMS = "My Lost Items";
    public static final String MODE_FOUND_ITEMS = "My Found Items";
    
    private static final String[] LOST_COLUMN_NAMES = {
        "Match ID", "Found Item ID", "Semantic %", "Image %", "Attribute %", "Overall %", "Status"
    };
    
    private static final String[] FOUND_COLUMN_NAMES = {
        "Match ID", "Lost Item ID", "Semantic %", "Image %", "Attribute %", "Overall %", "Status"
    };
    
    private final MainFrame mainFrame;
    private final LostItemService lostItemService;
    private final FoundItemService foundItemService;
    private final MatchService matchService;
    
    private JComboBox<String> modeComboBox;
    private JLabel selectLabel;
    private JComboBox<Object> itemComboBox;
    private JTable matchesTable;
    private DefaultTableModel tableModel;
    private JButton viewMatchesButton;
    private JButton claimButton;
    private JButton backButton;
    private JLabel loadingLabel;
    
    private List<LostItem> userLostItems = new ArrayList<>();
    private List<FoundItem> userFoundItems = new ArrayList<>();
    
    /**
     * Primary constructor with all service dependencies.
     */
    public MatchingResultsPanel(MainFrame mainFrame, LostItemService lostItemService, 
                                FoundItemService foundItemService, MatchService matchService) {
        this.mainFrame = mainFrame;
        this.lostItemService = lostItemService;
        this.foundItemService = foundItemService;
        this.matchService = matchService;
        
        initializeUI();
        if (mainFrame != null && mainFrame.getCurrentUser() != null) {
            loadItems();
        }
    }
    
    /**
     * Backward-compatible constructor.
     */
    public MatchingResultsPanel(MainFrame mainFrame, LostItemService lostItemService, MatchService matchService) {
        this(mainFrame, lostItemService, mainFrame != null ? mainFrame.getFoundItemService() : null, matchService);
    }
    
    /**
     * Initialize the UI components.
     */
    private void initializeUI() {
        setLayout(new BorderLayout());
        
        // Create title panel
        JPanel titlePanel = createTitlePanel();
        add(titlePanel, BorderLayout.NORTH);
        
        // Create content panel
        JPanel contentPanel = createContentPanel();
        add(contentPanel, BorderLayout.CENTER);
        
        // Create button panel
        JPanel buttonPanel = createButtonPanel();
        add(buttonPanel, BorderLayout.SOUTH);
        
        logger.debug("MatchingResultsPanel initialized");
    }
    
    /**
     * Create the title panel.
     */
    private JPanel createTitlePanel() {
        return UIUtils.createTitlePanel("FindBack - AI Lost & Found", "AI Matching Results & Confidence Scores");
    }
    
    /**
     * Create the content panel.
     */
    private JPanel createContentPanel() {
        JPanel panel = new JPanel(new BorderLayout(0, 12));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        
        // Create selection panel
        JPanel selectionPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 10));
        selectionPanel.setBackground(UIUtils.COLOR_CARD_BG);
        selectionPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UIUtils.COLOR_CARD_BORDER, 1, true),
                BorderFactory.createEmptyBorder(6, 12, 6, 12)
        ));
        
        // Mode Selector (My Lost Items vs My Found Items)
        JLabel modeLabel = new JLabel("View Matches For:");
        modeLabel.setFont(UIUtils.FONT_LABEL);
        selectionPanel.add(modeLabel);
        
        modeComboBox = new JComboBox<>(new String[]{MODE_LOST_ITEMS, MODE_FOUND_ITEMS});
        modeComboBox.setFont(UIUtils.FONT_REGULAR);
        modeComboBox.setPreferredSize(new Dimension(145, 30));
        modeComboBox.addActionListener(e -> handleModeChanged());
        selectionPanel.add(modeComboBox);
        
        // Item Selector Label & Dropdown
        selectLabel = new JLabel("Select Lost Item:");
        selectLabel.setFont(UIUtils.FONT_LABEL);
        selectionPanel.add(selectLabel);
        
        itemComboBox = new JComboBox<>();
        itemComboBox.setFont(UIUtils.FONT_REGULAR);
        itemComboBox.setPreferredSize(new Dimension(300, 30));
        itemComboBox.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (value instanceof LostItem item) {
                    if (item.getLostItemId() != null) {
                        setText(String.format("Item #%d: %s - %s", 
                            item.getLostItemId(), 
                            item.getCategory() != null ? item.getCategory() : "Item", 
                            item.getDescription() != null ? item.getDescription() : ""));
                    } else {
                        setText("-- Select a lost item --");
                    }
                } else if (value instanceof FoundItem item) {
                    if (item.getFoundItemId() != null) {
                        setText(String.format("Found #%d: %s - %s", 
                            item.getFoundItemId(), 
                            item.getCategory() != null ? item.getCategory() : "Item", 
                            item.getDescription() != null ? item.getDescription() : ""));
                    } else {
                        setText("-- Select a found item --");
                    }
                }
                return this;
            }
        });
        selectionPanel.add(itemComboBox);
        
        viewMatchesButton = UIUtils.createPrimaryButton("View Matches", new Dimension(125, 30));
        viewMatchesButton.addActionListener(e -> loadMatches());
        selectionPanel.add(viewMatchesButton);
        
        // Create table model
        tableModel = new DefaultTableModel(LOST_COLUMN_NAMES, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        // Create table
        matchesTable = new JTable(tableModel);
        formatTableColumns();
        
        matchesTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && matchesTable.getSelectedRow() >= 0 && isLostItemsMode()) {
                claimButton.setEnabled(true);
            } else {
                claimButton.setEnabled(false);
            }
        });
        
        // Create scroll pane
        JScrollPane scrollPane = new JScrollPane(matchesTable);
        scrollPane.setPreferredSize(new Dimension(800, 320));
        
        // Create loading label
        loadingLabel = new JLabel("Select an item to view AI matches", SwingConstants.CENTER);
        loadingLabel.setFont(UIUtils.FONT_REGULAR);
        loadingLabel.setForeground(UIUtils.COLOR_TEXT_MUTED);
        
        // Add components to panel
        panel.add(selectionPanel, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(loadingLabel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    /**
     * Create the button panel.
     */
    private JPanel createButtonPanel() {
        JPanel panel = new JPanel();
        panel.setBorder(BorderFactory.createEmptyBorder(10, 0, 20, 0));
        panel.setLayout(new FlowLayout(FlowLayout.CENTER, 14, 0));
        
        claimButton = UIUtils.createPrimaryButton("Claim Selected Match", new Dimension(190, 34));
        claimButton.setEnabled(false);
        claimButton.addActionListener(e -> handleClaim());
        
        backButton = UIUtils.createSecondaryButton("Back to Dashboard", new Dimension(160, 34));
        backButton.addActionListener(e -> handleBack());
        
        panel.add(claimButton);
        panel.add(backButton);
        
        return panel;
    }
    
    /**
     * Format table columns and renderers.
     */
    private void formatTableColumns() {
        UIUtils.formatTable(matchesTable);
        UIUtils.centerAlignColumns(matchesTable, 0, 1, 2, 3, 4, 5);
        if (matchesTable.getColumnCount() > 6) {
            matchesTable.getColumnModel().getColumn(6).setCellRenderer(UIUtils.createStatusCellRenderer());
        }
    }
    
    /**
     * Check if current mode is Lost Items.
     */
    private boolean isLostItemsMode() {
        return MODE_LOST_ITEMS.equals(modeComboBox.getSelectedItem());
    }
    
    /**
     * Handle mode change between My Lost Items and My Found Items.
     */
    private void handleModeChanged() {
        updateItemComboBox();
    }
    
    /**
     * Load items for the current user (both lost and found).
     */
    public void loadItems() {
        User currentUser = mainFrame.getCurrentUser();
        if (currentUser == null) {
            UIUtils.showErrorDialog(this, "You must be logged in to view matches", "Authentication Error");
            mainFrame.showLogin();
            return;
        }
        
        loadingLabel.setText("Loading items...");
        tableModel.setRowCount(0);
        claimButton.setEnabled(false);
        
        SwingWorker<ItemBundle, Void> worker = new SwingWorker<>() {
            @Override
            protected ItemBundle doInBackground() throws Exception {
                logger.info("Loading lost and found items for user: {}", currentUser.getUsername());
                List<LostItem> lostItems = lostItemService != null ? 
                        lostItemService.getLostItemsByUser(currentUser.getUserId()) : Collections.emptyList();
                List<FoundItem> foundItems = foundItemService != null ? 
                        foundItemService.getFoundItemsByUser(currentUser.getUserId()) : Collections.emptyList();
                return new ItemBundle(lostItems, foundItems);
            }
            
            @Override
            protected void done() {
                try {
                    ItemBundle bundle = get();
                    userLostItems = bundle.lostItems;
                    userFoundItems = bundle.foundItems;
                    
                    // Smart default selection:
                    // If user has NO lost items, but HAS found items (e.g. Kumar who only reported found items)
                    if (userLostItems.isEmpty() && !userFoundItems.isEmpty()) {
                        modeComboBox.setSelectedItem(MODE_FOUND_ITEMS);
                    } else {
                        modeComboBox.setSelectedItem(MODE_LOST_ITEMS);
                    }
                    
                    updateItemComboBox();
                    
                } catch (Exception e) {
                    loadingLabel.setText("Error loading items. Please try again.");
                    UIUtils.showErrorDialog(MatchingResultsPanel.this, 
                            "Failed to load items. Please try again.", 
                            "Error");
                    logger.error("Error loading items for user: {}", currentUser.getUsername(), e);
                }
            }
        };
        
        worker.execute();
    }
    
    /**
     * Backward-compatible method for existing callers.
     */
    public void loadLostItems() {
        loadItems();
    }
    
    /**
     * Update the item dropdown and table schema based on the active mode.
     */
    private void updateItemComboBox() {
        boolean lostMode = isLostItemsMode();
        selectLabel.setText(lostMode ? "Select Lost Item:" : "Select Found Item:");
        
        // Update table column headers
        tableModel.setDataVector(new Object[0][0], lostMode ? LOST_COLUMN_NAMES : FOUND_COLUMN_NAMES);
        formatTableColumns();
        
        // Claiming is ONLY available for the owner of the lost item
        claimButton.setVisible(lostMode);
        claimButton.setEnabled(false);
        
        itemComboBox.removeAllItems();
        
        if (lostMode) {
            if (userLostItems.isEmpty()) {
                itemComboBox.addItem(new LostItem()); // Empty placeholder
                if (userFoundItems.isEmpty()) {
                    loadingLabel.setText("No lost items found. Report a lost item first.");
                } else {
                    loadingLabel.setText("You have no reported lost items. Switch to 'My Found Items' to view matches for your found items.");
                }
            } else {
                for (LostItem item : userLostItems) {
                    itemComboBox.addItem(item);
                }
                loadingLabel.setText("Select a lost item and click 'View Matches'");
                logger.info("Populated {} lost items in dropdown", userLostItems.size());
            }
        } else {
            if (userFoundItems.isEmpty()) {
                itemComboBox.addItem(new FoundItem()); // Empty placeholder
                if (userLostItems.isEmpty()) {
                    loadingLabel.setText("No found items reported. Report a found item first.");
                } else {
                    loadingLabel.setText("You have no reported found items. Switch to 'My Lost Items' to view matches for your lost items.");
                }
            } else {
                for (FoundItem item : userFoundItems) {
                    itemComboBox.addItem(item);
                }
                loadingLabel.setText("Select a found item and click 'View Matches' to inspect potential matches");
                logger.info("Populated {} found items in dropdown", userFoundItems.size());
            }
        }
    }
    
    /**
     * Load matches for the selected item.
     */
    private void loadMatches() {
        boolean lostMode = isLostItemsMode();
        Object selectedObj = itemComboBox.getSelectedItem();
        
        if (selectedObj == null) {
            UIUtils.showErrorDialog(this, "Please select an item", "Selection Error");
            return;
        }
        
        final Integer itemId;
        if (lostMode) {
            if (!(selectedObj instanceof LostItem lostItem) || lostItem.getLostItemId() == null) {
                UIUtils.showErrorDialog(this, "Please select a valid lost item", "Selection Error");
                return;
            }
            itemId = lostItem.getLostItemId();
        } else {
            if (!(selectedObj instanceof FoundItem foundItem) || foundItem.getFoundItemId() == null) {
                UIUtils.showErrorDialog(this, "Please select a valid found item", "Selection Error");
                return;
            }
            itemId = foundItem.getFoundItemId();
        }
        
        // Show loading state
        loadingLabel.setText("Loading matches...");
        tableModel.setRowCount(0);
        matchesTable.setEnabled(false);
        viewMatchesButton.setEnabled(false);
        claimButton.setEnabled(false);
        
        // Load in background thread
        SwingWorker<List<Match>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<Match> doInBackground() throws Exception {
                if (lostMode) {
                    logger.info("Loading matches for lost item ID: {}", itemId);
                    return matchService.getMatchesByLostItem(itemId);
                } else {
                    logger.info("Loading matches for found item ID: {}", itemId);
                    return matchService.getMatchesByFoundItem(itemId);
                }
            }
            
            @Override
            protected void done() {
                try {
                    List<Match> matches = get();
                    tableModel.setRowCount(0);
                    
                    if (matches.isEmpty()) {
                        loadingLabel.setText(lostMode ? 
                                "No matches found for this lost item." : 
                                "No matches found for this found item.");
                    } else {
                        loadingLabel.setText(lostMode ? 
                                "Select a match and click 'Claim Selected Match' to verify ownership." : 
                                "Showing matches for this found item (informational view).");
                        
                        // Sort by overall confidence (highest first)
                        matches.sort((m1, m2) -> {
                            BigDecimal s1 = m1.getOverallConfidenceScore() != null ? m1.getOverallConfidenceScore() : BigDecimal.ZERO;
                            BigDecimal s2 = m2.getOverallConfidenceScore() != null ? m2.getOverallConfidenceScore() : BigDecimal.ZERO;
                            return s2.compareTo(s1);
                        });
                        
                        // Add matches to table
                        for (Match match : matches) {
                            Integer relatedId = lostMode ? match.getFoundItemId() : match.getLostItemId();
                            Object[] row = {
                                match.getMatchId(),
                                relatedId,
                                formatPercentage(match.getSemanticSimilarityScore()),
                                formatPercentage(match.getImageSimilarityScore()),
                                formatPercentage(match.getAttributeSimilarityScore()),
                                formatPercentage(match.getOverallConfidenceScore()),
                                match.getMatchStatus() != null ? match.getMatchStatus() : "-"
                            };
                            tableModel.addRow(row);
                        }
                        
                        logger.info("Loaded {} matches for {} item ID: {}", matches.size(), lostMode ? "lost" : "found", itemId);
                    }
                    
                } catch (Exception e) {
                    loadingLabel.setText("Error loading matches. Please try again.");
                    UIUtils.showErrorDialog(MatchingResultsPanel.this, 
                            "Failed to load matches. Please try again.", 
                            "Error");
                    logger.error("Error loading matches for item ID: {}", itemId, e);
                } finally {
                    matchesTable.setEnabled(true);
                    viewMatchesButton.setEnabled(true);
                }
            }
        };
        
        worker.execute();
    }
    
    /**
     * Format BigDecimal as percentage string.
     */
    private String formatPercentage(BigDecimal value) {
        if (value == null) {
            return "-";
        }
        return String.format("%.1f%%", value.multiply(new BigDecimal("100")).doubleValue());
    }
    
    /**
     * Handle back button click.
     */
    private void handleBack() {
        logger.debug("Back to dashboard");
        mainFrame.showDashboard();
    }
    
    /**
     * Handle claim button click (strictly restricted to lost items mode).
     */
    private void handleClaim() {
        if (!isLostItemsMode()) {
            UIUtils.showErrorDialog(this, "Claims can only be filed by the owner of the lost item.", "Claim Error");
            return;
        }
        
        int selectedRow = matchesTable.getSelectedRow();
        if (selectedRow < 0) {
            UIUtils.showErrorDialog(this, "Please select a match to claim", "Selection Error");
            return;
        }
        
        Integer matchId = (Integer) tableModel.getValueAt(selectedRow, 0);
        logger.debug("Navigating to claim panel for match ID: {}", matchId);
        
        mainFrame.showClaimPanel(matchId);
    }
    
    /**
     * Internal container for loading both item categories asynchronously.
     */
    private static class ItemBundle {
        final List<LostItem> lostItems;
        final List<FoundItem> foundItems;
        
        ItemBundle(List<LostItem> lostItems, List<FoundItem> foundItems) {
            this.lostItems = lostItems != null ? lostItems : Collections.emptyList();
            this.foundItems = foundItems != null ? foundItems : Collections.emptyList();
        }
    }
}
