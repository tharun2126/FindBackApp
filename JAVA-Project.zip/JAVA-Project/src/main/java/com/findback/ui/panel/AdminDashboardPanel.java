package com.findback.ui.panel;

import com.findback.dao.FoundItemDAO;
import com.findback.dao.LostItemDAO;
import com.findback.dao.impl.FoundItemDAOImpl;
import com.findback.dao.impl.LostItemDAOImpl;
import com.findback.model.Claim;
import com.findback.model.FoundItem;
import com.findback.model.LostItem;
import com.findback.model.Match;
import com.findback.model.User;
import com.findback.service.ClaimService;
import com.findback.service.MatchService;
import com.findback.service.NotificationService;
import com.findback.ui.frame.MainFrame;
import com.findback.ui.util.UIUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;
import java.util.Optional;

/**
 * Admin dashboard panel for reviewing and managing claims.
 * 
 * Admins can view pending claims, review verification details,
 * and approve or reject claims with admin notes.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public class AdminDashboardPanel extends JPanel {
    
    private static final Logger logger = LoggerFactory.getLogger(AdminDashboardPanel.class);
    
    private final MainFrame mainFrame;
    private final ClaimService claimService;
    private final MatchService matchService;
    private final NotificationService notificationService;
    private final LostItemDAO lostItemDAO;
    private final FoundItemDAO foundItemDAO;
    
    private JTable claimsTable;
    private DefaultTableModel tableModel;
    private JButton refreshButton;
    private JButton viewDetailsButton;
    private JButton approveButton;
    private JButton rejectButton;
    private JButton backButton;
    private JLabel loadingLabel;
    private JLabel statsLabel;
    
    private Claim selectedClaim;
    
    /**
     * Constructor with dependency injection.
     * 
     * @param mainFrame the main frame for navigation
     * @param claimService the ClaimService to use
     * @param matchService the MatchService to use
     * @param notificationService the NotificationService to use
     */
    public AdminDashboardPanel(MainFrame mainFrame, ClaimService claimService, 
                               MatchService matchService, NotificationService notificationService) {
        this.mainFrame = mainFrame;
        this.claimService = claimService;
        this.matchService = matchService;
        this.notificationService = notificationService;
        this.lostItemDAO = new LostItemDAOImpl();
        this.foundItemDAO = new FoundItemDAOImpl();
        
        initializeUI();
    }
    
    /**
     * Initialize the UI components.
     */
    private void initializeUI() {
        setLayout(new BorderLayout());
        
        // Create title panel
        JPanel titlePanel = createTitlePanel();
        add(titlePanel, BorderLayout.NORTH);
        
        // Create content panel
        JPanel contentPanel = createContentPanel();
        add(contentPanel, BorderLayout.CENTER);
        
        // Create button panel
        JPanel buttonPanel = createButtonPanel();
        add(buttonPanel, BorderLayout.SOUTH);
        
        logger.debug("AdminDashboardPanel initialized");
    }
    
    /**
     * Create the title panel.
     */
    private JPanel createTitlePanel() {
        JPanel titlePanel = UIUtils.createTitlePanel(
                "Admin Dashboard",
                "Review submitted claims, verify ownership, and process approvals"
        );
        
        statsLabel = new JLabel("Pending Claims: Loading...", SwingConstants.CENTER);
        statsLabel.setFont(UIUtils.FONT_LABEL);
        statsLabel.setForeground(UIUtils.COLOR_PRIMARY);
        statsLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        titlePanel.add(Box.createVerticalStrut(4));
        titlePanel.add(statsLabel);
        
        return titlePanel;
    }
    
    /**
     * Create the content panel.
     */
    private JPanel createContentPanel() {
        JPanel panel = new JPanel(new BorderLayout(0, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 24, 10, 24));
        panel.setOpaque(false);
        
        // Create table model
        String[] columnNames = {"Claim ID", "Match ID", "User ID", "Status", "Submitted", "Notes Preview"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        // Create table
        claimsTable = new JTable(tableModel);
        claimsTable.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        claimsTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        claimsTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && claimsTable.getSelectedRow() >= 0) {
                handleClaimSelection();
            }
        });
        
        // Format table using UIUtils
        UIUtils.formatTable(claimsTable);
        UIUtils.centerAlignColumns(claimsTable, 0, 1, 2, 4);
        claimsTable.getColumnModel().getColumn(3).setCellRenderer(UIUtils.createStatusCellRenderer());
        
        // Column widths
        claimsTable.getColumnModel().getColumn(0).setPreferredWidth(70);
        claimsTable.getColumnModel().getColumn(1).setPreferredWidth(70);
        claimsTable.getColumnModel().getColumn(2).setPreferredWidth(70);
        claimsTable.getColumnModel().getColumn(3).setPreferredWidth(110);
        claimsTable.getColumnModel().getColumn(4).setPreferredWidth(110);
        claimsTable.getColumnModel().getColumn(5).setPreferredWidth(220);
        
        // Create scroll pane
        JScrollPane scrollPane = new JScrollPane(claimsTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(UIUtils.COLOR_BORDER, 1));
        
        // Create loading label
        loadingLabel = new JLabel("Loading pending claims...", SwingConstants.CENTER);
        loadingLabel.setFont(UIUtils.FONT_LABEL);
        loadingLabel.setForeground(UIUtils.COLOR_TEXT_SECONDARY);
        loadingLabel.setBorder(BorderFactory.createEmptyBorder(6, 0, 6, 0));
        
        // Add components to panel
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(loadingLabel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    /**
     * Create the button panel.
     */
    private JPanel createButtonPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 14));
        panel.setOpaque(false);
        
        refreshButton = UIUtils.createSecondaryButton("Refresh", e -> loadPendingClaims());
        refreshButton.setPreferredSize(new Dimension(110, 36));
        
        viewDetailsButton = UIUtils.createSecondaryButton("View Details", e -> handleViewDetails());
        viewDetailsButton.setPreferredSize(new Dimension(120, 36));
        viewDetailsButton.setEnabled(false);
        
        approveButton = UIUtils.createSuccessButton("Approve", e -> handleApprove());
        approveButton.setPreferredSize(new Dimension(120, 36));
        approveButton.setEnabled(false);
        
        rejectButton = UIUtils.createDangerButton("Reject", e -> handleReject());
        rejectButton.setPreferredSize(new Dimension(120, 36));
        rejectButton.setEnabled(false);
        
        backButton = UIUtils.createSecondaryButton("Back to Dashboard", e -> handleBack());
        backButton.setPreferredSize(new Dimension(160, 36));
        
        panel.add(refreshButton);
        panel.add(viewDetailsButton);
        panel.add(approveButton);
        panel.add(rejectButton);
        panel.add(backButton);
        
        return panel;
    }
    
    /**
     * Load pending claims for admin review.
     */
    public void loadPendingClaims() {
        User currentUser = mainFrame.getCurrentUser();
        if (currentUser == null) {
            UIUtils.showErrorDialog(this, "You must be logged in to access the admin dashboard", "Authentication Error");
            mainFrame.showLogin();
            return;
        }
        
        if (!currentUser.isAdmin()) {
            UIUtils.showErrorDialog(this, "You don't have permission to access the admin dashboard", "Authorization Error");
            mainFrame.showDashboard();
            return;
        }
        
        loadingLabel.setText("Loading pending claims...");
        tableModel.setRowCount(0);
        claimsTable.setEnabled(false);
        disableActionButtons();
        
        SwingWorker<List<Claim>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<Claim> doInBackground() throws Exception {
                logger.info("Loading pending claims for admin: {}", currentUser.getUsername());
                
                // Get pending and under review claims
                List<Claim> pendingClaims = claimService.getClaimsByStatus(Claim.ClaimStatus.PENDING);
                List<Claim> underReviewClaims = claimService.getClaimsByStatus(Claim.ClaimStatus.UNDER_REVIEW);
                
                // Combine both lists
                pendingClaims.addAll(underReviewClaims);
                
                return pendingClaims;
            }
            
            @Override
            protected void done() {
                try {
                    List<Claim> claims = get();
                    
                    // Clear table
                    tableModel.setRowCount(0);
                    
                    if (claims.isEmpty()) {
                        loadingLabel.setText("No pending claims to review.");
                        statsLabel.setText("Pending Claims: 0");
                    } else {
                        loadingLabel.setText("");
                        statsLabel.setText(String.format("Pending Claims: %d", claims.size()));
                        
                        // Add claims to table
                        for (Claim claim : claims) {
                            String notesPreview = claim.getVerificationNotes() != null 
                                    ? (claim.getVerificationNotes().length() > 30 
                                            ? claim.getVerificationNotes().substring(0, 30) + "..." 
                                            : claim.getVerificationNotes())
                                    : "";
                            
                            Object[] row = {
                                claim.getClaimId(),
                                claim.getMatchId(),
                                claim.getUserId(),
                                claim.getClaimStatus(),
                                claim.getCreatedAt() != null ? claim.getCreatedAt().toLocalDate() : "-",
                                notesPreview
                            };
                            tableModel.addRow(row);
                        }
                        
                        logger.info("Loaded {} pending claims for admin: {}", claims.size(), currentUser.getUsername());
                    }
                    
                } catch (Exception e) {
                    loadingLabel.setText("Error loading claims. Please try again.");
                    UIUtils.showErrorDialog(AdminDashboardPanel.this, 
                            "Failed to load pending claims. Please try again.", 
                            "Error");
                    logger.error("Error loading pending claims for admin: {}", currentUser.getUsername(), e);
                } finally {
                    claimsTable.setEnabled(true);
                }
            }
        };
        
        worker.execute();
    }
    
    /**
     * Handle claim selection in table.
     */
    private void handleClaimSelection() {
        int selectedRow = claimsTable.getSelectedRow();
        if (selectedRow >= 0) {
            Integer claimId = (Integer) tableModel.getValueAt(selectedRow, 0);
            
            SwingWorker<Optional<Claim>, Void> worker = new SwingWorker<>() {
                @Override
                protected Optional<Claim> doInBackground() throws Exception {
                    return claimService.findClaimById(claimId);
                }
                
                @Override
                protected void done() {
                    try {
                        Optional<Claim> claimOptional = get();
                        if (claimOptional.isPresent()) {
                            selectedClaim = claimOptional.get();
                            enableActionButtons();
                        } else {
                            selectedClaim = null;
                            disableActionButtons();
                        }
                    } catch (Exception e) {
                        logger.error("Error loading claim details for ID: {}", claimId, e);
                        selectedClaim = null;
                        disableActionButtons();
                    }
                }
            };
            
            worker.execute();
        } else {
            selectedClaim = null;
            disableActionButtons();
        }
    }
    
    /**
     * Handle view details button click.
     */
    private void handleViewDetails() {
        if (selectedClaim == null) {
            UIUtils.showErrorDialog(this, "No claim selected", "Selection Error");
            return;
        }
        
        SwingWorker<String, Void> worker = new SwingWorker<>() {
            @Override
            protected String doInBackground() throws Exception {
                StringBuilder details = new StringBuilder();
                
                details.append("Claim Details:\n");
                details.append("==============\n");
                details.append(String.format("Claim ID: %d\n", selectedClaim.getClaimId()));
                details.append(String.format("Match ID: %d\n", selectedClaim.getMatchId()));
                details.append(String.format("User ID: %d\n", selectedClaim.getUserId()));
                details.append(String.format("Status: %s\n", selectedClaim.getClaimStatus()));
                details.append(String.format("Submitted: %s\n", selectedClaim.getCreatedAt()));
                
                // Get match information
                Optional<Match> matchOptional = matchService.findMatchById(selectedClaim.getMatchId());
                if (matchOptional.isPresent()) {
                    Match match = matchOptional.get();
                    details.append("\nMatch Information:\n");
                    details.append("==================\n");
                    details.append(String.format("Lost Item ID: %d\n", match.getLostItemId()));
                    details.append(String.format("Found Item ID: %d\n", match.getFoundItemId()));
                    details.append(String.format("Overall Confidence: %.1f%%\n", match.getConfidencePercentage()));
                    
                    // Get lost item details
                    Optional<LostItem> lostItemOptional = lostItemDAO.findById(match.getLostItemId());
                    if (lostItemOptional.isPresent()) {
                        LostItem lostItem = lostItemOptional.get();
                        details.append("\nLost Item Details:\n");
                        details.append("==================\n");
                        details.append(String.format("Category: %s\n", lostItem.getCategory()));
                        details.append(String.format("Brand: %s\n", lostItem.getBrand()));
                        details.append(String.format("Colour: %s\n", lostItem.getColour()));
                        details.append(String.format("Description: %s\n", lostItem.getDescription()));
                        details.append(String.format("Location Lost: %s\n", lostItem.getLocationLost()));
                    }
                    
                    // Get found item details
                    Optional<FoundItem> foundItemOptional = foundItemDAO.findById(match.getFoundItemId());
                    if (foundItemOptional.isPresent()) {
                        FoundItem foundItem = foundItemOptional.get();
                        details.append("\nFound Item Details:\n");
                        details.append("===================\n");
                        details.append(String.format("Category: %s\n", foundItem.getCategory()));
                        details.append(String.format("Brand: %s\n", foundItem.getBrand()));
                        details.append(String.format("Colour: %s\n", foundItem.getColour()));
                        details.append(String.format("Description: %s\n", foundItem.getDescription()));
                        details.append(String.format("Location Found: %s\n", foundItem.getLocationFound()));
                    }
                }
                
                details.append("\nOwnership Verification Details:\n");
                details.append("=============================\n");
                details.append(selectedClaim.getVerificationNotes() != null ? selectedClaim.getVerificationNotes() : "No verification notes provided");
                
                if (selectedClaim.getAdminId() != null) {
                    details.append(String.format("\n\nAdmin ID: %d\n", selectedClaim.getAdminId()));
                    if (selectedClaim.getVerifiedAt() != null) {
                        details.append(String.format("Verified At: %s\n", selectedClaim.getVerifiedAt()));
                    }
                }
                
                return details.toString();
            }
            
            @Override
            protected void done() {
                try {
                    String details = get();
                    
                    JTextArea textArea = new JTextArea(details);
                    textArea.setEditable(false);
                    textArea.setFont(new Font("Consolas", Font.PLAIN, 12));
                    textArea.setBorder(BorderFactory.createEmptyBorder(10, 12, 10, 12));
                    JScrollPane scrollPane = new JScrollPane(textArea);
                    scrollPane.setBorder(BorderFactory.createLineBorder(UIUtils.COLOR_BORDER, 1));
                    scrollPane.setPreferredSize(new Dimension(620, 420));
                    
                    JOptionPane.showMessageDialog(AdminDashboardPanel.this, scrollPane, 
                            "Claim Details - Claim #" + selectedClaim.getClaimId(), JOptionPane.INFORMATION_MESSAGE);
                    
                } catch (Exception e) {
                    UIUtils.showErrorDialog(AdminDashboardPanel.this, 
                            "Failed to load claim details. Please try again.", 
                            "Error");
                    logger.error("Error loading claim details for claim ID: {}", selectedClaim.getClaimId(), e);
                }
            }
        };
        
        worker.execute();
    }
    
    /**
     * Handle approve button click.
     */
    private void handleApprove() {
        if (selectedClaim == null) {
            UIUtils.showErrorDialog(this, "No claim selected", "Selection Error");
            return;
        }
        
        User currentUser = mainFrame.getCurrentUser();
        if (currentUser == null || !currentUser.isAdmin()) {
            UIUtils.showErrorDialog(this, "You don't have permission to approve claims", "Authorization Error");
            return;
        }
        
        if (!UIUtils.showConfirmDialog(this, 
                "Are you sure you want to approve this claim? This will verify the user's ownership of the item.", 
                "Confirm Approval")) {
            return;
        }
        
        String adminNotes = JOptionPane.showInputDialog(this, 
                "Enter admin notes (optional):", "Admin Notes", JOptionPane.QUESTION_MESSAGE);
        
        loadingLabel.setText("Processing approval...");
        disableActionButtons();
        
        SwingWorker<Claim, Void> worker = new SwingWorker<>() {
            @Override
            protected Claim doInBackground() throws Exception {
                logger.info("Admin {} approving claim {}", currentUser.getUserId(), selectedClaim.getClaimId());
                
                return claimService.updateClaimStatus(
                        selectedClaim.getClaimId(),
                        Claim.ClaimStatus.VERIFIED,
                        currentUser.getUserId(),
                        adminNotes
                );
            }
            
            @Override
            protected void done() {
                try {
                    Claim updatedClaim = get();
                    
                    // Send notification to claimant
                    notificationService.createNotification(
                            selectedClaim.getUserId(),
                            "Claim Approved",
                            "Your claim for match #" + selectedClaim.getMatchId() + " has been approved. Ownership verified.",
                            com.findback.model.Notification.NotificationType.CLAIM_STATUS,
                            selectedClaim.getMatchId()
                    );
                    
                    UIUtils.showInfoDialog(AdminDashboardPanel.this, 
                            "Claim has been approved successfully!", 
                            "Approval Successful");
                    
                    logger.info("Claim {} approved successfully by admin {}", updatedClaim.getClaimId(), currentUser.getUserId());
                    
                    // Refresh the claims table
                    loadPendingClaims();
                    
                } catch (Exception e) {
                    loadingLabel.setText("Error processing approval");
                    enableActionButtons();
                    
                    UIUtils.showErrorDialog(AdminDashboardPanel.this, 
                            "Failed to approve claim. Please try again.", 
                            "Error");
                    logger.error("Error approving claim {}", selectedClaim.getClaimId(), e);
                }
            }
        };
        
        worker.execute();
    }
    
    /**
     * Handle reject button click.
     */
    private void handleReject() {
        if (selectedClaim == null) {
            UIUtils.showErrorDialog(this, "No claim selected", "Selection Error");
            return;
        }
        
        User currentUser = mainFrame.getCurrentUser();
        if (currentUser == null || !currentUser.isAdmin()) {
            UIUtils.showErrorDialog(this, "You don't have permission to reject claims", "Authorization Error");
            return;
        }
        
        if (!UIUtils.showConfirmDialog(this, 
                "Are you sure you want to reject this claim? This will deny the user's ownership claim.", 
                "Confirm Rejection")) {
            return;
        }
        
        String adminNotes = JOptionPane.showInputDialog(this, 
                "Enter rejection reason (required):", "Rejection Reason", JOptionPane.QUESTION_MESSAGE);
        
        if (UIUtils.isNullOrEmpty(adminNotes)) {
            UIUtils.showErrorDialog(this, "Rejection reason is required", "Validation Error");
            return;
        }
        
        loadingLabel.setText("Processing rejection...");
        disableActionButtons();
        
        SwingWorker<Claim, Void> worker = new SwingWorker<>() {
            @Override
            protected Claim doInBackground() throws Exception {
                logger.info("Admin {} rejecting claim {}", currentUser.getUserId(), selectedClaim.getClaimId());
                
                return claimService.updateClaimStatus(
                        selectedClaim.getClaimId(),
                        Claim.ClaimStatus.REJECTED,
                        currentUser.getUserId(),
                        adminNotes
                );
            }
            
            @Override
            protected void done() {
                try {
                    Claim updatedClaim = get();
                    
                    // Send notification to claimant
                    notificationService.createNotification(
                            selectedClaim.getUserId(),
                            "Claim Rejected",
                            "Your claim for match #" + selectedClaim.getMatchId() + " has been rejected. Reason: " + adminNotes,
                            com.findback.model.Notification.NotificationType.CLAIM_STATUS,
                            selectedClaim.getMatchId()
                    );
                    
                    UIUtils.showInfoDialog(AdminDashboardPanel.this, 
                            "Claim has been rejected successfully.", 
                            "Rejection Successful");
                    
                    logger.info("Claim {} rejected successfully by admin {}", updatedClaim.getClaimId(), currentUser.getUserId());
                    
                    // Refresh the claims table
                    loadPendingClaims();
                    
                } catch (Exception e) {
                    loadingLabel.setText("Error processing rejection");
                    enableActionButtons();
                    
                    UIUtils.showErrorDialog(AdminDashboardPanel.this, 
                            "Failed to reject claim. Please try again.", 
                            "Error");
                    logger.error("Error rejecting claim {}", selectedClaim.getClaimId(), e);
                }
            }
        };
        
        worker.execute();
    }
    
    /**
     * Handle back button click.
     */
    private void handleBack() {
        logger.debug("Back to dashboard");
        mainFrame.showDashboard();
    }
    
    /**
     * Enable action buttons.
     */
    private void enableActionButtons() {
        viewDetailsButton.setEnabled(true);
        approveButton.setEnabled(true);
        rejectButton.setEnabled(true);
    }
    
    /**
     * Disable action buttons.
     */
    private void disableActionButtons() {
        viewDetailsButton.setEnabled(false);
        approveButton.setEnabled(false);
        rejectButton.setEnabled(false);
    }
}