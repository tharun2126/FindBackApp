package com.findback.ui.util;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.plaf.basic.BasicButtonUI;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * Utility class for common UI operations and styling design system.
 * 
 * Provides unified design tokens, typography, button factories,
 * dialog helpers, table formatting, and status renderers.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public class UIUtils {
    
    // --- Typography Tokens ---
    public static final Font FONT_TITLE = new Font("Segoe UI", Font.BOLD, 22);
    public static final Font FONT_SUBTITLE = new Font("Segoe UI", Font.PLAIN, 14);
    public static final Font FONT_SECTION_HEADER = new Font("Segoe UI", Font.BOLD, 15);
    public static final Font FONT_LABEL = new Font("Segoe UI", Font.BOLD, 12);
    public static final Font FONT_REGULAR = new Font("Segoe UI", Font.PLAIN, 13);
    public static final Font FONT_BOLD = new Font("Segoe UI", Font.BOLD, 13);
    public static final Font FONT_BUTTON = new Font("Segoe UI", Font.BOLD, 13);
    public static final Font FONT_SMALL = new Font("Segoe UI", Font.PLAIN, 11);
    public static final Font FONT_MONO = new Font("Consolas", Font.PLAIN, 12);
    
    // --- Color Tokens ---
    public static final Color COLOR_PRIMARY = new Color(0, 102, 204);       // Brand blue
    public static final Color COLOR_PRIMARY_DARK = new Color(0, 76, 153);
    public static final Color COLOR_SUCCESS = new Color(40, 140, 40);       // Verified/Approved green
    public static final Color COLOR_DANGER = new Color(185, 45, 45);        // Rejected/Cancel red
    public static final Color COLOR_WARNING = new Color(200, 110, 0);       // Pending amber/orange
    public static final Color COLOR_INFO = new Color(30, 130, 210);         // Under Review / active blue
    public static final Color COLOR_BACKGROUND = new Color(245, 247, 250);   // Main window background
    public static final Color COLOR_CARD_BG = new Color(248, 250, 252);     // Very soft cool white
    public static final Color COLOR_CARD_BORDER = new Color(218, 224, 233);
    public static final Color COLOR_BORDER = new Color(218, 224, 233);
    public static final Color COLOR_TEXT_MAIN = new Color(33, 37, 41);
    public static final Color COLOR_TEXT_PRIMARY = COLOR_TEXT_MAIN;
    public static final Color COLOR_TEXT_MUTED = new Color(108, 117, 125);
    public static final Color COLOR_TEXT_SECONDARY = COLOR_TEXT_MUTED;
    public static final Color COLOR_TABLE_GRID = new Color(230, 235, 240);
    public static final Color COLOR_HEADER_BG = new Color(240, 243, 248);

    // --- Button Design Tokens (Strictly Black Bold Text for Maximum Readability) ---
    public static final Color BTN_TEXT_COLOR = Color.BLACK;

    // Normal Primary Buttons (Neutral White by default, Subtle Light Blue on Hover)
    public static final Color BTN_PRIMARY_BG = Color.WHITE;
    public static final Color BTN_PRIMARY_HOVER_BG = new Color(228, 240, 254);
    public static final Color BTN_PRIMARY_PRESSED_BG = new Color(212, 230, 250);
    public static final Color BTN_PRIMARY_BORDER = new Color(175, 195, 222);

    // Normal Secondary Buttons (Clean Very Light Gray by default, Subtle Light Blue on Hover)
    public static final Color BTN_SECONDARY_BG = new Color(250, 251, 253);
    public static final Color BTN_SECONDARY_HOVER_BG = new Color(234, 242, 252);
    public static final Color BTN_SECONDARY_PRESSED_BG = new Color(218, 232, 248);
    public static final Color BTN_SECONDARY_BORDER = new Color(205, 214, 225);

    // Admin Action Buttons: Approve (Permanent Light Green)
    public static final Color BTN_APPROVE_BG = new Color(205, 245, 215);
    public static final Color BTN_APPROVE_HOVER_BG = new Color(180, 235, 195);
    public static final Color BTN_APPROVE_PRESSED_BG = new Color(155, 220, 175);
    public static final Color BTN_APPROVE_BORDER = new Color(75, 170, 95);

    // Admin Action Buttons: Reject (Permanent Light Red)
    public static final Color BTN_REJECT_BG = new Color(255, 215, 215);
    public static final Color BTN_REJECT_HOVER_BG = new Color(255, 190, 190);
    public static final Color BTN_REJECT_PRESSED_BG = new Color(250, 165, 165);
    public static final Color BTN_REJECT_BORDER = new Color(225, 100, 100);

    /**
     * Private constructor to prevent instantiation.
     */
    private UIUtils() {
        throw new AssertionError("UIUtils class should not be instantiated");
    }
    
    /**
     * Style a button with BasicButtonUI, explicit background/hover/click colors,
     * crisp borders, focus ring, and guaranteed BLACK BOLD text.
     */
    private static JButton styleButton(JButton btn, Color bg, Color hoverBg, Color pressedBg, 
                                        Color borderColor, Color hoverBorderColor, Dimension size) {
        btn.setUI(new BasicButtonUI());
        btn.setFont(FONT_BUTTON);
        btn.setForeground(BTN_TEXT_COLOR);
        btn.setBackground(bg);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setContentAreaFilled(true);
        btn.setOpaque(true);
        
        Border defaultBorder = new CompoundBorder(
                new LineBorder(borderColor, 1, true),
                new EmptyBorder(6, 14, 6, 14)
        );
        Border hoverBorder = new CompoundBorder(
                new LineBorder(hoverBorderColor, 1, true),
                new EmptyBorder(6, 14, 6, 14)
        );
        Border focusBorder = new CompoundBorder(
                new LineBorder(new Color(40, 120, 220), 2, true),
                new EmptyBorder(5, 13, 5, 13)
        );
        btn.setBorder(defaultBorder);
        
        if (size != null) {
            btn.setPreferredSize(size);
        }
        
        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                if (btn.isEnabled()) {
                    btn.setBackground(hoverBg);
                    btn.setBorder(hoverBorder);
                    btn.setForeground(BTN_TEXT_COLOR);
                }
            }
            @Override
            public void mouseExited(MouseEvent e) {
                if (btn.isEnabled()) {
                    btn.setBackground(bg);
                    btn.setBorder(defaultBorder);
                    btn.setForeground(BTN_TEXT_COLOR);
                }
            }
            @Override
            public void mousePressed(MouseEvent e) {
                if (btn.isEnabled()) {
                    btn.setBackground(pressedBg);
                    btn.setForeground(BTN_TEXT_COLOR);
                }
            }
            @Override
            public void mouseReleased(MouseEvent e) {
                if (btn.isEnabled()) {
                    boolean inside = btn.contains(e.getPoint());
                    btn.setBackground(inside ? hoverBg : bg);
                    btn.setBorder(inside ? hoverBorder : defaultBorder);
                    btn.setForeground(BTN_TEXT_COLOR);
                }
            }
        });
        
        btn.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                btn.setBorder(focusBorder);
                btn.setForeground(BTN_TEXT_COLOR);
            }
            @Override
            public void focusLost(FocusEvent e) {
                btn.setBorder(defaultBorder);
                btn.setForeground(BTN_TEXT_COLOR);
            }
        });
        
        return btn;
    }
    
    /**
     * Create a styled card panel with rounded/soft border and white background.
     */
    public static JPanel createCardPanel() {
        JPanel card = new JPanel();
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COLOR_CARD_BORDER, 1),
            BorderFactory.createEmptyBorder(20, 24, 20, 24)
        ));
        return card;
    }
    
    /**
     * Create a standard styled header panel with title and subtitle.
     * 
     * @param title the main title
     * @param subtitle the subtitle
     * @return JPanel with standard branding layout
     */
    public static JPanel createTitlePanel(String title, String subtitle) {
        JPanel panel = new JPanel();
        panel.setBorder(BorderFactory.createEmptyBorder(25, 0, 15, 0));
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        
        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(FONT_TITLE);
        titleLabel.setForeground(COLOR_PRIMARY);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JLabel subtitleLabel = new JLabel(subtitle);
        subtitleLabel.setFont(FONT_SUBTITLE);
        subtitleLabel.setForeground(COLOR_TEXT_MUTED);
        subtitleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        panel.add(titleLabel);
        panel.add(Box.createVerticalStrut(6));
        panel.add(subtitleLabel);
        panel.add(Box.createVerticalStrut(10));
        
        return panel;
    }
    
    /**
     * Create a styled Primary action button with BLACK BOLD text, neutral white default bg, and light blue hover.
     */
    public static JButton createPrimaryButton(String text, Dimension size) {
        JButton btn = new JButton(text);
        return styleButton(btn, BTN_PRIMARY_BG, BTN_PRIMARY_HOVER_BG, BTN_PRIMARY_PRESSED_BG, 
                           BTN_PRIMARY_BORDER, new Color(100, 160, 230), size);
    }
    
    /**
     * Create a styled Primary action button with an action listener.
     */
    public static JButton createPrimaryButton(String text, java.awt.event.ActionListener listener) {
        JButton btn = createPrimaryButton(text, (Dimension) null);
        if (listener != null) {
            btn.addActionListener(listener);
        }
        return btn;
    }
    
    /**
     * Create a styled Success action button (Approve) with BLACK BOLD text and green background.
     */
    public static JButton createSuccessButton(String text, Dimension size) {
        JButton btn = new JButton(text);
        return styleButton(btn, BTN_APPROVE_BG, BTN_APPROVE_HOVER_BG, BTN_APPROVE_PRESSED_BG, 
                           BTN_APPROVE_BORDER, new Color(45, 145, 65), size);
    }
    
    /**
     * Create a styled Success action button with an action listener.
     */
    public static JButton createSuccessButton(String text, java.awt.event.ActionListener listener) {
        JButton btn = createSuccessButton(text, (Dimension) null);
        if (listener != null) {
            btn.addActionListener(listener);
        }
        return btn;
    }
    
    /**
     * Create a styled Danger action button (Reject) with BLACK BOLD text and red background.
     */
    public static JButton createDangerButton(String text, Dimension size) {
        JButton btn = new JButton(text);
        return styleButton(btn, BTN_REJECT_BG, BTN_REJECT_HOVER_BG, BTN_REJECT_PRESSED_BG, 
                           BTN_REJECT_BORDER, new Color(200, 60, 60), size);
    }
    
    /**
     * Create a styled Danger action button with an action listener.
     */
    public static JButton createDangerButton(String text, java.awt.event.ActionListener listener) {
        JButton btn = createDangerButton(text, (Dimension) null);
        if (listener != null) {
            btn.addActionListener(listener);
        }
        return btn;
    }
    
    /**
     * Create a styled Secondary button with BLACK BOLD text, clean neutral gray bg, and light blue hover.
     */
    public static JButton createSecondaryButton(String text, Dimension size) {
        JButton btn = new JButton(text);
        return styleButton(btn, BTN_SECONDARY_BG, BTN_SECONDARY_HOVER_BG, BTN_SECONDARY_PRESSED_BG, 
                           BTN_SECONDARY_BORDER, new Color(110, 165, 230), size);
    }
    
    /**
     * Create a styled Secondary button with an action listener.
     */
    public static JButton createSecondaryButton(String text, java.awt.event.ActionListener listener) {
        JButton btn = createSecondaryButton(text, (Dimension) null);
        if (listener != null) {
            btn.addActionListener(listener);
        }
        return btn;
    }
    
    /**
     * Format a JTable with modern row height, gridlines, fonts, and header styling.
     * 
     * @param table the table to format
     */
    public static void formatTable(JTable table) {
        table.setRowHeight(26);
        table.setFont(FONT_REGULAR);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setShowGrid(true);
        table.setGridColor(COLOR_TABLE_GRID);
        table.setIntercellSpacing(new Dimension(1, 1));
        
        JTableHeader header = table.getTableHeader();
        if (header != null) {
            header.setFont(FONT_LABEL);
            header.setReorderingAllowed(false);
            header.setBackground(COLOR_HEADER_BG);
            header.setForeground(COLOR_TEXT_MAIN);
            header.setPreferredSize(new Dimension(header.getWidth(), 30));
        }
    }
    
    /**
     * Center align specific columns in a JTable.
     * 
     * @param table the table
     * @param columnIndices indices to center align
     */
    public static void centerAlignColumns(JTable table, int... columnIndices) {
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
        for (int colIndex : columnIndices) {
            if (colIndex < table.getColumnCount()) {
                table.getColumnModel().getColumn(colIndex).setCellRenderer(centerRenderer);
            }
        }
    }
    
    /**
     * Create a custom badge-style cell renderer for Status columns.
     * Color-codes VERIFIED, PENDING, UNDER_REVIEW, REJECTED, ACTIVE, MATCHED, etc.
     * 
     * @return TableCellRenderer for status columns
     */
    public static DefaultTableCellRenderer createStatusCellRenderer() {
        return new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, 
                    boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                setHorizontalAlignment(SwingConstants.CENTER);
                
                if (value != null) {
                    String status = value.toString().trim().toUpperCase();
                    if (!isSelected) {
                        switch (status) {
                            case "VERIFIED":
                            case "CONFIRMED":
                            case "RETURNED":
                                setForeground(COLOR_SUCCESS);
                                setFont(FONT_LABEL);
                                break;
                            case "REJECTED":
                            case "CLOSED":
                                setForeground(COLOR_DANGER);
                                setFont(FONT_LABEL);
                                break;
                            case "UNDER_REVIEW":
                            case "MATCHED":
                                setForeground(COLOR_INFO);
                                setFont(FONT_LABEL);
                                break;
                            case "PENDING":
                            case "ACTIVE":
                            default:
                                setForeground(COLOR_WARNING);
                                setFont(FONT_LABEL);
                                break;
                        }
                    }
                }
                return c;
            }
        };
    }
    
    /**
     * Show an information message dialog.
     * 
     * @param parent the parent component
     * @param message the message to display
     * @param title the dialog title
     */
    public static void showInfoDialog(Component parent, String message, String title) {
        JOptionPane.showMessageDialog(parent, message, title, JOptionPane.INFORMATION_MESSAGE);
    }
    
    /**
     * Show an error message dialog.
     * 
     * @param parent the parent component
     * @param message the error message to display
     * @param title the dialog title
     */
    public static void showErrorDialog(Component parent, String message, String title) {
        JOptionPane.showMessageDialog(parent, message, title, JOptionPane.ERROR_MESSAGE);
    }
    
    /**
     * Show a warning message dialog.
     * 
     * @param parent the parent component
     * @param message the warning message to display
     * @param title the dialog title
     */
    public static void showWarningDialog(Component parent, String message, String title) {
        JOptionPane.showMessageDialog(parent, message, title, JOptionPane.WARNING_MESSAGE);
    }
    
    /**
     * Show a confirmation dialog.
     * 
     * @param parent the parent component
     * @param message the message to display
     * @param title the dialog title
     * @return true if user confirms, false otherwise
     */
    public static boolean showConfirmDialog(Component parent, String message, String title) {
        int result = JOptionPane.showConfirmDialog(parent, message, title, JOptionPane.YES_NO_OPTION);
        return result == JOptionPane.YES_OPTION;
    }
    
    /**
     * Check if a string is null or empty.
     * 
     * @param value the string to check
     * @return true if null or empty, false otherwise
     */
    public static boolean isNullOrEmpty(String value) {
        return value == null || value.trim().isEmpty();
    }
    
    /**
     * Validate email format (basic validation).
     * 
     * @param email the email to validate
     * @return true if valid format, false otherwise
     */
    public static boolean isValidEmail(String email) {
        if (isNullOrEmpty(email)) {
            return false;
        }
        int atIndex = email.indexOf('@');
        int dotIndex = email.lastIndexOf('.');
        return atIndex > 0 && dotIndex > atIndex + 1 && dotIndex < email.length() - 1;
    }
}

