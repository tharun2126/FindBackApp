package com.findback.ui.panel;

import com.findback.model.Claim;
import com.findback.model.Match;
import com.findback.model.User;
import com.findback.service.ClaimService;
import com.findback.service.MatchService;
import com.findback.service.NotificationService;
import com.findback.ui.frame.MainFrame;
import com.findback.ui.util.UIUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.*;
import java.awt.*;
import java.util.Optional;

/**
 * Panel for users to submit claims on matched items.
 * 
 * Users can claim items that match their lost items and provide
 * private ownership verification details for admin review.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public class ClaimPanel extends JPanel {
    
    private static final Logger logger = LoggerFactory.getLogger(ClaimPanel.class);
    
    private final MainFrame mainFrame;
    private final ClaimService claimService;
    private final MatchService matchService;
    private final NotificationService notificationService;
    
    private Integer matchId;
    private JTextArea verificationNotesArea;
    private JButton submitClaimButton;
    private JButton backButton;
    private JLabel matchInfoLabel;
    private JLabel loadingLabel;
    
    /**
     * Constructor with dependency injection.
     * 
     * @param mainFrame the main frame for navigation
     * @param claimService the ClaimService to use
     * @param matchService the MatchService to use
     * @param notificationService the NotificationService to use
     */
    public ClaimPanel(MainFrame mainFrame, ClaimService claimService, 
                     MatchService matchService, NotificationService notificationService) {
        this.mainFrame = mainFrame;
        this.claimService = claimService;
        this.matchService = matchService;
        this.notificationService = notificationService;
        
        initializeUI();
    }
    
    /**
     * Initialize the UI components.
     */
    private void initializeUI() {
        setLayout(new BorderLayout());
        
        // Create title panel
        JPanel titlePanel = createTitlePanel();
        add(titlePanel, BorderLayout.NORTH);
        
        // Create content panel
        JPanel contentPanel = createContentPanel();
        add(contentPanel, BorderLayout.CENTER);
        
        // Create button panel
        JPanel buttonPanel = createButtonPanel();
        add(buttonPanel, BorderLayout.SOUTH);
        
        logger.debug("ClaimPanel initialized");
    }
    
    /**
     * Create the title panel.
     */
    private JPanel createTitlePanel() {
        return UIUtils.createTitlePanel(
                "Claim Matched Item",
                "Provide private ownership verification details for administrative review"
        );
    }
    
    /**
     * Create the content panel.
     */
    private JPanel createContentPanel() {
        JPanel wrapper = new JPanel(new GridBagLayout());
        wrapper.setOpaque(false);
        
        JPanel card = UIUtils.createCardPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setPreferredSize(new Dimension(650, 400));
        
        // Match info banner
        JPanel infoPanel = new JPanel(new BorderLayout());
        infoPanel.setBackground(UIUtils.COLOR_CARD_BG);
        infoPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UIUtils.COLOR_CARD_BORDER, 1),
                BorderFactory.createEmptyBorder(12, 16, 12, 16)
        ));
        infoPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
        infoPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        matchInfoLabel = new JLabel("Match Information: Loading...");
        matchInfoLabel.setFont(UIUtils.FONT_BOLD);
        matchInfoLabel.setForeground(UIUtils.COLOR_PRIMARY);
        infoPanel.add(matchInfoLabel, BorderLayout.CENTER);
        
        // Verification notes label
        JLabel notesLabel = new JLabel("Ownership Verification Details:");
        notesLabel.setFont(UIUtils.FONT_LABEL);
        notesLabel.setForeground(UIUtils.COLOR_TEXT_PRIMARY);
        notesLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        // Help text
        JLabel helpLabel = new JLabel("<html><i>Please provide private details proving ownership (e.g. serial numbers, purchase receipts, specific markings, custom engravings). This information is confidential and visible only to administrators.</i></html>");
        helpLabel.setFont(UIUtils.FONT_SMALL);
        helpLabel.setForeground(UIUtils.COLOR_TEXT_SECONDARY);
        helpLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        // Text area
        verificationNotesArea = new JTextArea(8, 40);
        verificationNotesArea.setLineWrap(true);
        verificationNotesArea.setWrapStyleWord(true);
        verificationNotesArea.setFont(UIUtils.FONT_REGULAR);
        verificationNotesArea.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        
        JScrollPane scrollPane = new JScrollPane(verificationNotesArea);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setBorder(BorderFactory.createLineBorder(UIUtils.COLOR_BORDER, 1));
        scrollPane.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        // Loading / Status label
        loadingLabel = new JLabel(" ", SwingConstants.CENTER);
        loadingLabel.setFont(UIUtils.FONT_LABEL);
        loadingLabel.setForeground(UIUtils.COLOR_PRIMARY);
        loadingLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        card.add(infoPanel);
        card.add(Box.createVerticalStrut(16));
        card.add(notesLabel);
        card.add(Box.createVerticalStrut(6));
        card.add(helpLabel);
        card.add(Box.createVerticalStrut(10));
        card.add(scrollPane);
        card.add(Box.createVerticalStrut(12));
        card.add(loadingLabel);
        
        wrapper.add(card);
        return wrapper;
    }
    
    /**
     * Create the button panel.
     */
    private JPanel createButtonPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 16, 16));
        panel.setOpaque(false);
        
        submitClaimButton = UIUtils.createPrimaryButton("Submit Claim", e -> handleSubmitClaim());
        submitClaimButton.setPreferredSize(new Dimension(170, 38));
        
        backButton = UIUtils.createSecondaryButton("Back to Matching", e -> handleBack());
        backButton.setPreferredSize(new Dimension(170, 38));
        
        panel.add(submitClaimButton);
        panel.add(backButton);
        
        return panel;
    }
    
    /**
     * Set the match ID to claim and load match information.
     * 
     * @param matchId the match ID to claim
     */
    public void setMatchId(Integer matchId) {
        this.matchId = matchId;
        loadMatchInformation();
    }
    
    /**
     * Load match information for display.
     */
    private void loadMatchInformation() {
        if (matchId == null) {
            matchInfoLabel.setText("No match selected");
            return;
        }
        
        loadingLabel.setText("Loading match information...");
        submitClaimButton.setEnabled(false);
        
        SwingWorker<Optional<Match>, Void> worker = new SwingWorker<>() {
            @Override
            protected Optional<Match> doInBackground() throws Exception {
                logger.debug("Loading match information for match ID: {}", matchId);
                return matchService.findMatchById(matchId);
            }
            
            @Override
            protected void done() {
                try {
                    Optional<Match> matchOptional = get();
                    
                    if (matchOptional.isPresent()) {
                        Match match = matchOptional.get();
                        matchInfoLabel.setText(String.format("Match ID: %d | Lost Item ID: %d | Found Item ID: %d | Confidence: %.1f%%",
                                match.getMatchId(), match.getLostItemId(), match.getFoundItemId(),
                                match.getConfidencePercentage()));
                        loadingLabel.setText("");
                        submitClaimButton.setEnabled(true);
                        
                        logger.info("Loaded match information for match ID: {}", matchId);
                    } else {
                        matchInfoLabel.setText("Match not found");
                        loadingLabel.setText("Error: Match not found");
                        submitClaimButton.setEnabled(false);
                        
                        logger.warn("Match not found with ID: {}", matchId);
                    }
                    
                } catch (Exception e) {
                    matchInfoLabel.setText("Error loading match information");
                    loadingLabel.setText("Error loading match information");
                    submitClaimButton.setEnabled(false);
                    
                    UIUtils.showErrorDialog(ClaimPanel.this, 
                            "Failed to load match information. Please try again.", 
                            "Error");
                    logger.error("Error loading match information for match ID: {}", matchId, e);
                }
            }
        };
        
        worker.execute();
    }
    
    /**
     * Handle submit claim button click.
     */
    private void handleSubmitClaim() {
        User currentUser = mainFrame.getCurrentUser();
        if (currentUser == null) {
            UIUtils.showErrorDialog(this, "You must be logged in to submit a claim", "Authentication Error");
            mainFrame.showLogin();
            return;
        }
        
        if (matchId == null) {
            UIUtils.showErrorDialog(this, "No match selected", "Selection Error");
            return;
        }
        
        String verificationNotes = verificationNotesArea.getText().trim();
        if (UIUtils.isNullOrEmpty(verificationNotes)) {
            UIUtils.showErrorDialog(this, "Please provide ownership verification details", "Validation Error");
            return;
        }
        
        // Validate that the match belongs to the current user's lost item
        SwingWorker<Boolean, Void> validationWorker = new SwingWorker<>() {
            @Override
            protected Boolean doInBackground() throws Exception {
                Optional<Match> matchOptional = matchService.findMatchById(matchId);
                if (matchOptional.isEmpty()) {
                    return false;
                }
                
                // Here we would need to check if the lost item belongs to the current user
                // For now, we'll proceed with the claim submission
                return true;
            }
            
            @Override
            protected void done() {
                try {
                    Boolean isValid = get();
                    if (!isValid) {
                        UIUtils.showErrorDialog(ClaimPanel.this, 
                                "Invalid match or you don't have permission to claim this item", 
                                "Authorization Error");
                        return;
                    }
                    
                    // Proceed with claim submission
                    submitClaim(currentUser.getUserId(), verificationNotes);
                    
                } catch (Exception e) {
                    UIUtils.showErrorDialog(ClaimPanel.this, 
                            "Error validating claim. Please try again.", 
                            "Error");
                    logger.error("Error validating claim for match ID: {}", matchId, e);
                }
            }
        };
        
        validationWorker.execute();
    }
    
    /**
     * Submit the claim to the service layer.
     */
    private void submitClaim(Integer userId, String verificationNotes) {
        loadingLabel.setText("Submitting claim...");
        submitClaimButton.setEnabled(false);
        
        SwingWorker<Claim, Void> worker = new SwingWorker<>() {
            @Override
            protected Claim doInBackground() throws Exception {
                logger.info("Submitting claim for match ID: {} by user ID: {}", matchId, userId);
                
                Claim claim = new Claim(matchId, userId);
                claim.setVerificationNotes(verificationNotes);
                
                return claimService.createClaim(claim);
            }
            
            @Override
            protected void done() {
                try {
                    Claim submittedClaim = get();
                    
                    // Send notification to the claimant
                    notificationService.createNotification(
                            userId,
                            "Claim Submitted",
                            "Your claim for match #" + matchId + " has been submitted and is pending review.",
                            com.findback.model.Notification.NotificationType.CLAIM_STATUS,
                            matchId
                    );
                    
                    UIUtils.showInfoDialog(ClaimPanel.this, 
                            "Your claim has been submitted successfully! You will be notified when it's reviewed.",
                            "Claim Submitted");
                    
                    logger.info("Claim submitted successfully with ID: {}", submittedClaim.getClaimId());
                    
                    // Navigate back to matching results
                    mainFrame.showMatchingResults();
                    
                } catch (Exception e) {
                    loadingLabel.setText("Error submitting claim");
                    submitClaimButton.setEnabled(true);
                    
                    UIUtils.showErrorDialog(ClaimPanel.this, 
                            "Failed to submit claim. Please try again.", 
                            "Error");
                    logger.error("Error submitting claim for match ID: {}", matchId, e);
                }
            }
        };
        
        worker.execute();
    }
    
    /**
     * Handle back button click.
     */
    private void handleBack() {
        logger.debug("Back to matching results");
        mainFrame.showMatchingResults();
    }
    
    /**
     * Clear the form for new claim submission.
     */
    public void clearForm() {
        this.matchId = null;
        verificationNotesArea.setText("");
        matchInfoLabel.setText("Match Information: Loading...");
        loadingLabel.setText("");
        submitClaimButton.setEnabled(false);
    }
}