package com.findback.ui.panel;

import com.findback.exception.AuthenticationException;
import com.findback.model.User;
import com.findback.service.UserService;
import com.findback.ui.frame.MainFrame;
import com.findback.ui.util.UIUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.*;
import java.awt.*;

/**
 * Registration panel for new user registration.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public class RegistrationPanel extends JPanel {
    
    private static final Logger logger = LoggerFactory.getLogger(RegistrationPanel.class);
    
    private final UserService userService;
    private final MainFrame mainFrame;
    
    private JTextField fullNameField;
    private JTextField usernameField;
    private JTextField emailField;
    private JTextField phoneField;
    private JPasswordField passwordField;
    private JPasswordField confirmPasswordField;
    private JButton registerButton;
    private JButton backButton;
    
    /**
     * Constructor with dependency injection.
     * 
     * @param userService the UserService to use
     * @param mainFrame the main frame for navigation
     */
    public RegistrationPanel(UserService userService, MainFrame mainFrame) {
        this.userService = userService;
        this.mainFrame = mainFrame;
        
        initializeUI();
    }
    
    /**
     * Initialize the UI components.
     */
    private void initializeUI() {
        setLayout(new BorderLayout());
        
        // Create title panel
        JPanel titlePanel = createTitlePanel();
        add(titlePanel, BorderLayout.NORTH);
        
        // Create form panel
        JPanel formPanel = createFormPanel();
        add(formPanel, BorderLayout.CENTER);
        
        logger.debug("RegistrationPanel initialized");
    }
    
    /**
     * Create the title panel.
     */
    private JPanel createTitlePanel() {
        return UIUtils.createTitlePanel("FindBack - AI Lost & Found", "Create a new account");
    }
    
    /**
     * Create the form panel with input fields and buttons.
     */
    private JPanel createFormPanel() {
        JPanel wrapper = new JPanel(new GridBagLayout());
        wrapper.setOpaque(false);
        
        JPanel card = new JPanel(new GridBagLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UIUtils.COLOR_CARD_BORDER, 1, true),
                BorderFactory.createEmptyBorder(20, 35, 20, 35)
        ));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 10, 6, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Full Name
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0;
        JLabel nameLabel = new JLabel("Full Name*:");
        nameLabel.setFont(UIUtils.FONT_LABEL);
        card.add(nameLabel, gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        fullNameField = new JTextField(18);
        fullNameField.setFont(UIUtils.FONT_REGULAR);
        fullNameField.setPreferredSize(new Dimension(220, 28));
        card.add(fullNameField, gbc);
        
        // Username
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weightx = 0;
        JLabel uLabel = new JLabel("Username*:");
        uLabel.setFont(UIUtils.FONT_LABEL);
        card.add(uLabel, gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        usernameField = new JTextField(18);
        usernameField.setFont(UIUtils.FONT_REGULAR);
        usernameField.setPreferredSize(new Dimension(220, 28));
        card.add(usernameField, gbc);
        
        // Email
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.weightx = 0;
        JLabel eLabel = new JLabel("Email*:");
        eLabel.setFont(UIUtils.FONT_LABEL);
        card.add(eLabel, gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        emailField = new JTextField(18);
        emailField.setFont(UIUtils.FONT_REGULAR);
        emailField.setPreferredSize(new Dimension(220, 28));
        card.add(emailField, gbc);
        
        // Phone (optional)
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.weightx = 0;
        JLabel pLabel = new JLabel("Phone (Optional):");
        pLabel.setFont(UIUtils.FONT_LABEL);
        card.add(pLabel, gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        phoneField = new JTextField(18);
        phoneField.setFont(UIUtils.FONT_REGULAR);
        phoneField.setPreferredSize(new Dimension(220, 28));
        card.add(phoneField, gbc);
        
        // Password
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.weightx = 0;
        JLabel pwLabel = new JLabel("Password*:");
        pwLabel.setFont(UIUtils.FONT_LABEL);
        card.add(pwLabel, gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        passwordField = new JPasswordField(18);
        passwordField.setFont(UIUtils.FONT_REGULAR);
        passwordField.setPreferredSize(new Dimension(220, 28));
        card.add(passwordField, gbc);
        
        // Confirm Password
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.weightx = 0;
        JLabel cpwLabel = new JLabel("Confirm Password*:");
        cpwLabel.setFont(UIUtils.FONT_LABEL);
        card.add(cpwLabel, gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        confirmPasswordField = new JPasswordField(18);
        confirmPasswordField.setFont(UIUtils.FONT_REGULAR);
        confirmPasswordField.setPreferredSize(new Dimension(220, 28));
        card.add(confirmPasswordField, gbc);
        
        // Button panel
        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 2;
        gbc.weightx = 0;
        gbc.insets = new Insets(16, 10, 5, 10);
        gbc.fill = GridBagConstraints.CENTER;
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 0));
        buttonPanel.setOpaque(false);
        
        registerButton = UIUtils.createPrimaryButton("Register", new Dimension(120, 34));
        registerButton.addActionListener(e -> handleRegister());
        
        backButton = UIUtils.createSecondaryButton("Back to Login", new Dimension(120, 34));
        backButton.addActionListener(e -> handleBack());
        
        buttonPanel.add(registerButton);
        buttonPanel.add(backButton);
        
        card.add(buttonPanel, gbc);
        wrapper.add(card);
        
        return wrapper;
    }
    
    /**
     * Handle register button click.
     */
    private void handleRegister() {
        String fullName = fullNameField.getText().trim();
        String username = usernameField.getText().trim();
        String email = emailField.getText().trim();
        String phone = phoneField.getText().trim();
        String password = new String(passwordField.getPassword());
        String confirmPassword = new String(confirmPasswordField.getPassword());
        
        // Validate required fields
        if (UIUtils.isNullOrEmpty(fullName)) {
            UIUtils.showErrorDialog(this, "Please enter your full name", "Registration Error");
            return;
        }
        
        if (UIUtils.isNullOrEmpty(username)) {
            UIUtils.showErrorDialog(this, "Please enter a username", "Registration Error");
            return;
        }
        
        if (UIUtils.isNullOrEmpty(email)) {
            UIUtils.showErrorDialog(this, "Please enter your email", "Registration Error");
            return;
        }
        
        if (!UIUtils.isValidEmail(email)) {
            UIUtils.showErrorDialog(this, "Please enter a valid email address", "Registration Error");
            return;
        }
        
        if (UIUtils.isNullOrEmpty(password)) {
            UIUtils.showErrorDialog(this, "Please enter a password", "Registration Error");
            return;
        }
        
        if (password.length() < 6) {
            UIUtils.showErrorDialog(this, "Password must be at least 6 characters long", "Registration Error");
            return;
        }
        
        if (!password.equals(confirmPassword)) {
            UIUtils.showErrorDialog(this, "Passwords do not match", "Registration Error");
            return;
        }
        
        // Perform registration in background thread
        SwingWorker<User, Void> worker = new SwingWorker<>() {
            @Override
            protected User doInBackground() throws Exception {
                logger.info("Attempting registration for user: {}", username);
                
                // Create user object
                User user = new User();
                user.setUsername(username);
                user.setEmail(email);
                user.setFullName(fullName);
                user.setPhone(UIUtils.isNullOrEmpty(phone) ? null : phone);
                user.setRole(User.UserRole.USER); // Default role is USER
                
                return userService.registerUser(user, password);
            }
            
            @Override
            protected void done() {
                try {
                    User user = get();
                    // Registration successful
                    UIUtils.showInfoDialog(RegistrationPanel.this, 
                            "Registration successful!\n\nYou can now log in with your username and password.", 
                            "Registration Success");
                    logger.info("User registered successfully: {}", username);
                    
                    // Clear form and navigate to login
                    clearForm();
                    mainFrame.showCard(MainFrame.LOGIN_CARD);
                    
                } catch (IllegalStateException e) {
                    // Username or email already exists
                    UIUtils.showErrorDialog(RegistrationPanel.this, 
                            e.getMessage(), "Registration Failed");
                    logger.warn("Registration failed for user: {} - {}", username, e.getMessage());
                } catch (Exception e) {
                    // Other errors
                    UIUtils.showErrorDialog(RegistrationPanel.this, 
                            "An error occurred during registration. Please try again.", "Registration Error");
                    logger.error("Error during registration for user: {}", username, e);
                }
            }
        };
        
        worker.execute();
    }
    
    /**
     * Handle back button click.
     */
    private void handleBack() {
        logger.debug("Navigate to login panel");
        clearForm();
        mainFrame.showCard(MainFrame.LOGIN_CARD);
    }
    
    /**
     * Clear the form fields.
     */
    public void clearForm() {
        fullNameField.setText("");
        usernameField.setText("");
        emailField.setText("");
        phoneField.setText("");
        passwordField.setText("");
        confirmPasswordField.setText("");
    }
}
