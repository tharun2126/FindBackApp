package com.findback.ui.frame;

import com.findback.ai.MatchingEngine;
import com.findback.ai.AttributeSimilarityService;
import com.findback.ai.ImageSimilarityService;
import com.findback.ai.SemanticSimilarityService;
import com.findback.ai.impl.AttributeSimilarityServiceImpl;
import com.findback.ai.impl.ImageSimilarityServiceImpl;
import com.findback.ai.impl.MatchingEngineImpl;
import com.findback.ai.impl.SemanticSimilarityServiceImpl;
import com.findback.dao.ClaimDAO;
import com.findback.dao.FoundItemDAO;
import com.findback.dao.LostItemDAO;
import com.findback.dao.MatchDAO;
import com.findback.dao.NotificationDAO;
import com.findback.dao.impl.ClaimDAOImpl;
import com.findback.dao.impl.FoundItemDAOImpl;
import com.findback.dao.impl.LostItemDAOImpl;
import com.findback.dao.impl.MatchDAOImpl;
import com.findback.dao.impl.NotificationDAOImpl;
import com.findback.model.User;
import com.findback.service.ClaimService;
import com.findback.service.FoundItemService;
import com.findback.service.LostItemService;
import com.findback.service.MatchService;
import com.findback.service.NotificationService;
import com.findback.service.UserService;
import com.findback.service.impl.ClaimServiceImpl;
import com.findback.service.impl.FoundItemServiceImpl;
import com.findback.service.impl.LostItemServiceImpl;
import com.findback.service.impl.MatchServiceImpl;
import com.findback.service.impl.NotificationServiceImpl;
import com.findback.ui.panel.AdminDashboardPanel;
import com.findback.ui.panel.ClaimPanel;
import com.findback.ui.panel.LoginPanel;
import com.findback.ui.panel.MatchingResultsPanel;
import com.findback.ui.panel.MyClaimsPanel;
import com.findback.ui.panel.MyFoundItemsPanel;
import com.findback.ui.panel.MyLostItemsPanel;
import com.findback.ui.panel.NotificationPanel;
import com.findback.ui.panel.RegistrationPanel;
import com.findback.ui.panel.ReportFoundItemPanel;
import com.findback.ui.panel.ReportLostItemPanel;
import com.findback.ui.panel.UserDashboardPanel;
import com.findback.ui.util.UIUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.*;
import java.awt.*;

/**
 * Main application frame for FindBack.
 * 
 * This is the primary window that hosts all UI panels using CardLayout
 * for navigation between different screens.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public class MainFrame extends JFrame {
    
    private static final Logger logger = LoggerFactory.getLogger(MainFrame.class);
    
    // Card names for navigation
    public static final String LOGIN_CARD = "LOGIN";
    public static final String REGISTER_CARD = "REGISTER";
    public static final String DASHBOARD_CARD = "DASHBOARD";
    public static final String REPORT_LOST_CARD = "REPORT_LOST";
    public static final String REPORT_FOUND_CARD = "REPORT_FOUND";
    public static final String MY_LOST_ITEMS_CARD = "MY_LOST_ITEMS";
    public static final String MY_FOUND_ITEMS_CARD = "MY_FOUND_ITEMS";
    public static final String MATCHING_RESULTS_CARD = "MATCHING_RESULTS";
    public static final String NOTIFICATIONS_CARD = "NOTIFICATIONS";
    public static final String CLAIM_CARD = "CLAIM";
    public static final String MY_CLAIMS_CARD = "MY_CLAIMS";
    public static final String ADMIN_DASHBOARD_CARD = "ADMIN_DASHBOARD";
    
    private final CardLayout cardLayout;
    private final JPanel cardPanel;
    private final UserService userService;
    private final LostItemService lostItemService;
    private final FoundItemService foundItemService;
    private final MatchService matchService;
    private final NotificationService notificationService;
    private final ClaimService claimService;
    
    private User currentUser;
    private UserDashboardPanel dashboardPanel;
    private MyLostItemsPanel myLostItemsPanel;
    private MyFoundItemsPanel myFoundItemsPanel;
    private MatchingResultsPanel matchingResultsPanel;
    private NotificationPanel notificationPanel;
    private ClaimPanel claimPanel;
    private MyClaimsPanel myClaimsPanel;
    private AdminDashboardPanel adminDashboardPanel;
    
    /**
     * Constructor with dependency injection.
     * 
     * @param userService the UserService to use
     * @param lostItemService the LostItemService to use
     * @param foundItemService the FoundItemService to use
     */
    public MainFrame(UserService userService, LostItemService lostItemService, FoundItemService foundItemService) {
        this.userService = userService;
        this.lostItemService = lostItemService;
        this.foundItemService = foundItemService;
        
        // Initialize AI services
        SemanticSimilarityService semanticService = new SemanticSimilarityServiceImpl();
        ImageSimilarityService imageService = new ImageSimilarityServiceImpl();
        AttributeSimilarityService attributeService = new AttributeSimilarityServiceImpl();
        
        // Initialize additional services with AI matching support
        LostItemDAO lostItemDAO = new LostItemDAOImpl();
        FoundItemDAO foundItemDAO = new FoundItemDAOImpl();
        MatchDAO matchDAO = new MatchDAOImpl();
        NotificationDAO notificationDAO = new NotificationDAOImpl();
        ClaimDAO claimDAO = new ClaimDAOImpl();
        
        MatchingEngine matchingEngine = new MatchingEngineImpl(semanticService, imageService, attributeService);
        this.matchService = new MatchServiceImpl(matchDAO, lostItemDAO, foundItemDAO, matchingEngine);
        this.notificationService = new NotificationServiceImpl(notificationDAO);
        this.claimService = new ClaimServiceImpl(claimDAO, matchDAO);
        
        // Set up frame
        setTitle("FindBack - AI Lost & Found");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(980, 680);
        setMinimumSize(new Dimension(860, 580));
        setLocationRelativeTo(null); // Center on screen
        
        // Initialize card layout
        cardLayout = new CardLayout();
        cardPanel = new JPanel(cardLayout);
        cardPanel.setBackground(UIUtils.COLOR_BACKGROUND);
        getContentPane().setBackground(UIUtils.COLOR_BACKGROUND);
        
        // Add panels
        initializePanels();
        
        // Add card panel to frame
        add(cardPanel, BorderLayout.CENTER);
        
        logger.info("MainFrame initialized");
    }
    
    /**
     * Initialize all panels and add them to the card layout.
     */
    private void initializePanels() {
        // Create login panel
        LoginPanel loginPanel = new LoginPanel(userService, this);
        cardPanel.add(loginPanel, LOGIN_CARD);
        
        // Create registration panel
        RegistrationPanel registrationPanel = new RegistrationPanel(userService, this);
        cardPanel.add(registrationPanel, REGISTER_CARD);
        
        // Create dashboard panel
        dashboardPanel = new UserDashboardPanel(this);
        cardPanel.add(dashboardPanel, DASHBOARD_CARD);
        
        // Create report lost item panel
        ReportLostItemPanel reportLostPanel = new ReportLostItemPanel(this, lostItemService);
        cardPanel.add(reportLostPanel, REPORT_LOST_CARD);
        
        // Create report found item panel
        ReportFoundItemPanel reportFoundPanel = new ReportFoundItemPanel(this, foundItemService, matchService, notificationService);
        cardPanel.add(reportFoundPanel, REPORT_FOUND_CARD);
        
        // Create my lost items panel
        myLostItemsPanel = new MyLostItemsPanel(this, lostItemService);
        cardPanel.add(myLostItemsPanel, MY_LOST_ITEMS_CARD);
        
        // Create my found items panel
        myFoundItemsPanel = new MyFoundItemsPanel(this, foundItemService);
        cardPanel.add(myFoundItemsPanel, MY_FOUND_ITEMS_CARD);
        
        // Create matching results panel
        matchingResultsPanel = new MatchingResultsPanel(this, lostItemService, foundItemService, matchService);
        cardPanel.add(matchingResultsPanel, MATCHING_RESULTS_CARD);
        
        // Create notification panel
        notificationPanel = new NotificationPanel(this, notificationService);
        cardPanel.add(notificationPanel, NOTIFICATIONS_CARD);
        
        // Create claim panel
        claimPanel = new ClaimPanel(this, claimService, matchService, notificationService);
        cardPanel.add(claimPanel, CLAIM_CARD);
        
        // Create my claims panel
        myClaimsPanel = new MyClaimsPanel(this, claimService, matchService);
        cardPanel.add(myClaimsPanel, MY_CLAIMS_CARD);
        
        // Create admin dashboard panel
        adminDashboardPanel = new AdminDashboardPanel(this, claimService, matchService, notificationService);
        cardPanel.add(adminDashboardPanel, ADMIN_DASHBOARD_CARD);
        
        logger.info("Panels initialized: {} cards", cardPanel.getComponentCount());
    }
    
    /**
     * Show a specific card/panel.
     * 
     * @param cardName the name of the card to show
     */
    public void showCard(String cardName) {
        logger.debug("Showing card: {}", cardName);
        cardLayout.show(cardPanel, cardName);
    }
    
    /**
     * Show login panel.
     */
    public void showLogin() {
        logger.debug("Showing login panel");
        showCard(LOGIN_CARD);
    }
    
    /**
     * Show registration panel.
     */
    public void showRegister() {
        logger.debug("Showing registration panel");
        showCard(REGISTER_CARD);
    }
    
    /**
     * Show dashboard panel with user information.
     * 
     * @param user the logged-in user
     */
    public void showDashboard(User user) {
        logger.debug("Showing dashboard panel for user: {}", user.getUsername());
        this.currentUser = user;
        dashboardPanel.setCurrentUser(user);
        showCard(DASHBOARD_CARD);
    }
    
    /**
     * Show dashboard panel (uses current user).
     */
    public void showDashboard() {
        if (currentUser != null) {
            showDashboard(currentUser);
        } else {
            logger.warn("Attempted to show dashboard without current user, showing login instead");
            showLogin();
        }
    }
    
    /**
     * Show report lost item panel.
     */
    public void showReportLostItem() {
        logger.debug("Showing report lost item panel");
        if (currentUser != null) {
            showCard(REPORT_LOST_CARD);
        } else {
            logger.warn("User not logged in, showing login instead");
            showLogin();
        }
    }
    
    /**
     * Show report found item panel.
     */
    public void showReportFoundItem() {
        logger.debug("Showing report found item panel");
        if (currentUser != null) {
            showCard(REPORT_FOUND_CARD);
        } else {
            logger.warn("User not logged in, showing login instead");
            showLogin();
        }
    }
    
    /**
     * Show my lost items panel.
     */
    public void showMyLostItems() {
        logger.debug("Showing my lost items panel");
        if (currentUser != null) {
            if (myLostItemsPanel != null) {
                myLostItemsPanel.loadLostItems();
            }
            showCard(MY_LOST_ITEMS_CARD);
        } else {
            logger.warn("User not logged in, showing login instead");
            showLogin();
        }
    }
    
    /**
     * Show my found items panel.
     */
    public void showMyFoundItems() {
        logger.debug("Showing my found items panel");
        if (currentUser != null) {
            if (myFoundItemsPanel != null) {
                myFoundItemsPanel.loadFoundItems();
            }
            showCard(MY_FOUND_ITEMS_CARD);
        } else {
            logger.warn("User not logged in, showing login instead");
            showLogin();
        }
    }
    
    /**
     * Show matching results panel.
     */
    public void showMatchingResults() {
        logger.debug("Showing matching results panel");
        if (currentUser != null) {
            if (matchingResultsPanel != null) {
                matchingResultsPanel.loadItems();
            }
            showCard(MATCHING_RESULTS_CARD);
        } else {
            logger.warn("User not logged in, showing login instead");
            showLogin();
        }
    }
    
    /**
     * Show notifications panel.
     */
    public void showNotifications() {
        logger.debug("Showing notifications panel");
        if (currentUser != null) {
            if (notificationPanel != null) {
                notificationPanel.loadNotifications();
            }
            showCard(NOTIFICATIONS_CARD);
        } else {
            logger.warn("User not logged in, showing login instead");
            showLogin();
        }
    }
    
    /**
     * Show claim panel for a specific match.
     * 
     * @param matchId the match ID to claim
     */
    public void showClaimPanel(Integer matchId) {
        logger.debug("Showing claim panel for match ID: {}", matchId);
        if (currentUser != null) {
            if (claimPanel != null) {
                claimPanel.setMatchId(matchId);
            }
            showCard(CLAIM_CARD);
        } else {
            logger.warn("User not logged in, showing login instead");
            showLogin();
        }
    }
    
    /**
     * Show my claims panel.
     */
    public void showMyClaims() {
        logger.debug("Showing my claims panel");
        if (currentUser != null) {
            if (myClaimsPanel != null) {
                myClaimsPanel.loadClaims();
            }
            showCard(MY_CLAIMS_CARD);
        } else {
            logger.warn("User not logged in, showing login instead");
            showLogin();
        }
    }
    
    /**
     * Show admin dashboard panel.
     */
    public void showAdminDashboard() {
        logger.debug("Showing admin dashboard panel");
        if (currentUser != null) {
            if (!currentUser.isAdmin()) {
                logger.warn("User {} is not an admin, showing dashboard instead", currentUser.getUsername());
                showDashboard();
                return;
            }
            if (adminDashboardPanel != null) {
                adminDashboardPanel.loadPendingClaims();
            }
            showCard(ADMIN_DASHBOARD_CARD);
        } else {
            logger.warn("User not logged in, showing login instead");
            showLogin();
        }
    }
    
    /**
     * Logout the current user and return to login.
     */
    public void logout() {
        logger.info("Logging out user: {}", currentUser != null ? currentUser.getUsername() : "null");
        this.currentUser = null;
        dashboardPanel.setCurrentUser(null);
    }
    
    /**
     * Get the card panel.
     * 
     * @return the card panel
     */
    public JPanel getCardPanel() {
        return cardPanel;
    }
    
    /**
     * Get the card layout.
     * 
     * @return the card layout
     */
    public CardLayout getCardLayout() {
        return cardLayout;
    }
    
    /**
     * Get the user service.
     * 
     * @return the user service
     */
    public UserService getUserService() {
        return userService;
    }
    
    /**
     * Get the lost item service.
     * 
     * @return the lost item service
     */
    public LostItemService getLostItemService() {
        return lostItemService;
    }
    
    /**
     * Get the found item service.
     * 
     * @return the found item service
     */
    public FoundItemService getFoundItemService() {
        return foundItemService;
    }
    
    /**
     * Get the claim service.
     * 
     * @return the claim service
     */
    public ClaimService getClaimService() {
        return claimService;
    }
    
    /**
     * Get the my claims panel.
     * 
     * @return the my claims panel
     */
    public MyClaimsPanel getMyClaimsPanel() {
        return myClaimsPanel;
    }
    
    /**
     * Get the match service.
     * 
     * @return the match service
     */
    public MatchService getMatchService() {
        return matchService;
    }
    
    /**
     * Get the notification service.
     * 
     * @return the notification service
     */
    public NotificationService getNotificationService() {
        return notificationService;
    }
    
    /**
     * Get the current logged-in user.
     * 
     * @return the current user, or null if not logged in
     */
    public User getCurrentUser() {
        return currentUser;
    }
}
