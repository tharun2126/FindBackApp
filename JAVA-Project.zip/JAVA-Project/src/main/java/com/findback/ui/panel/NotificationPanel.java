package com.findback.ui.panel;

import com.findback.model.Notification;
import com.findback.model.User;
import com.findback.service.NotificationService;
import com.findback.ui.frame.MainFrame;
import com.findback.ui.util.UIUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Panel for displaying user notifications.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public class NotificationPanel extends JPanel {
    
    private static final Logger logger = LoggerFactory.getLogger(NotificationPanel.class);
    
    private final MainFrame mainFrame;
    private final NotificationService notificationService;
    
    private JTable notificationsTable;
    private DefaultTableModel tableModel;
    private JButton refreshButton;
    private JButton markAsReadButton;
    private JButton markAllAsReadButton;
    private JButton backButton;
    private JLabel loadingLabel;
    
    /**
     * Constructor with dependency injection.
     * 
     * @param mainFrame the main frame for navigation
     * @param notificationService the NotificationService to use
     */
    public NotificationPanel(MainFrame mainFrame, NotificationService notificationService) {
        this.mainFrame = mainFrame;
        this.notificationService = notificationService;
        
        initializeUI();
        if (mainFrame.getCurrentUser() != null) {
            loadNotifications();
        }
    }
    
    /**
     * Initialize the UI components.
     */
    private void initializeUI() {
        setLayout(new BorderLayout());
        
        // Create title panel
        JPanel titlePanel = createTitlePanel();
        add(titlePanel, BorderLayout.NORTH);
        
        // Create content panel
        JPanel contentPanel = createContentPanel();
        add(contentPanel, BorderLayout.CENTER);
        
        // Create button panel
        JPanel buttonPanel = createButtonPanel();
        add(buttonPanel, BorderLayout.SOUTH);
        
        logger.debug("NotificationPanel initialized");
    }
    
    /**
     * Create the title panel.
     */
    private JPanel createTitlePanel() {
        return UIUtils.createTitlePanel(
                "Notifications",
                "System notifications and match status updates"
        );
    }
    
    /**
     * Create the content panel with table.
     */
    private JPanel createContentPanel() {
        JPanel panel = new JPanel(new BorderLayout(0, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 24, 10, 24));
        panel.setOpaque(false);
        
        // Create table model
        String[] columnNames = {"ID", "Title", "Message", "Type", "Read", "Date"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        // Create table
        notificationsTable = new JTable(tableModel);
        notificationsTable.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        notificationsTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        // Format table using UIUtils
        UIUtils.formatTable(notificationsTable);
        UIUtils.centerAlignColumns(notificationsTable, 0, 3, 4, 5);
        
        // Set column widths
        notificationsTable.getColumnModel().getColumn(0).setPreferredWidth(50);
        notificationsTable.getColumnModel().getColumn(1).setPreferredWidth(160);
        notificationsTable.getColumnModel().getColumn(2).setPreferredWidth(300);
        notificationsTable.getColumnModel().getColumn(3).setPreferredWidth(110);
        notificationsTable.getColumnModel().getColumn(4).setPreferredWidth(60);
        notificationsTable.getColumnModel().getColumn(5).setPreferredWidth(130);
        
        // Custom renderer for unread notifications highlighting
        notificationsTable.setDefaultRenderer(Object.class, new javax.swing.table.DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, 
                    boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                
                // Alignment based on column
                if (column == 0 || column == 3 || column == 4 || column == 5) {
                    setHorizontalAlignment(SwingConstants.CENTER);
                } else {
                    setHorizontalAlignment(SwingConstants.LEFT);
                }
                
                // Check if notification is unread
                Object readVal = tableModel.getValueAt(row, 4);
                boolean isRead = Boolean.TRUE.equals(readVal);
                if (!isRead) {
                    c.setFont(UIUtils.FONT_BOLD);
                    if (!isSelected) {
                        c.setBackground(new Color(240, 245, 255)); // Soft blue-tint highlight for unread
                        c.setForeground(UIUtils.COLOR_PRIMARY);
                    }
                } else {
                    c.setFont(UIUtils.FONT_REGULAR);
                    if (!isSelected) {
                        c.setBackground(Color.WHITE);
                        c.setForeground(UIUtils.COLOR_TEXT_PRIMARY);
                    }
                }
                
                return c;
            }
        });
        
        // Create scroll pane
        JScrollPane scrollPane = new JScrollPane(notificationsTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(UIUtils.COLOR_BORDER, 1));
        
        // Create loading label
        loadingLabel = new JLabel("Loading...", SwingConstants.CENTER);
        loadingLabel.setFont(UIUtils.FONT_LABEL);
        loadingLabel.setForeground(UIUtils.COLOR_TEXT_SECONDARY);
        loadingLabel.setBorder(BorderFactory.createEmptyBorder(6, 0, 6, 0));
        
        // Add components to panel
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(loadingLabel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    /**
     * Create the button panel.
     */
    private JPanel createButtonPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 14, 14));
        panel.setOpaque(false);
        
        refreshButton = UIUtils.createSecondaryButton("Refresh", e -> loadNotifications());
        refreshButton.setPreferredSize(new Dimension(120, 36));
        
        markAsReadButton = UIUtils.createSecondaryButton("Mark as Read", e -> handleMarkAsRead());
        markAsReadButton.setPreferredSize(new Dimension(130, 36));
        
        markAllAsReadButton = UIUtils.createPrimaryButton("Mark All as Read", e -> handleMarkAllAsRead());
        markAllAsReadButton.setPreferredSize(new Dimension(160, 36));
        
        backButton = UIUtils.createSecondaryButton("Back to Dashboard", e -> handleBack());
        backButton.setPreferredSize(new Dimension(170, 36));
        
        panel.add(refreshButton);
        panel.add(markAsReadButton);
        panel.add(markAllAsReadButton);
        panel.add(backButton);
        
        return panel;
    }
    
    /**
     * Load notifications for the current user.
     */
    public void loadNotifications() {
        User currentUser = mainFrame.getCurrentUser();
        if (currentUser == null) {
            UIUtils.showErrorDialog(this, "You must be logged in to view notifications", "Authentication Error");
            mainFrame.showLogin();
            return;
        }
        
        // Show loading state
        loadingLabel.setText("Loading...");
        tableModel.setRowCount(0);
        notificationsTable.setEnabled(false);
        refreshButton.setEnabled(false);
        markAsReadButton.setEnabled(false);
        markAllAsReadButton.setEnabled(false);
        
        // Load in background thread
        SwingWorker<List<Notification>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<Notification> doInBackground() throws Exception {
                logger.info("Loading notifications for user: {}", currentUser.getUsername());
                return notificationService.getNotificationsByUser(currentUser.getUserId());
            }
            
            @Override
            protected void done() {
                try {
                    List<Notification> notifications = get();
                    
                    // Clear table
                    tableModel.setRowCount(0);
                    
                    if (notifications.isEmpty()) {
                        loadingLabel.setText("No notifications.");
                    } else {
                        loadingLabel.setText("");
                        
                        // Add notifications to table
                        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
                        for (Notification notification : notifications) {
                            Object[] row = {
                                notification.getNotificationId(),
                                notification.getTitle() != null ? notification.getTitle() : "-",
                                notification.getMessage() != null ? notification.getMessage() : "-",
                                notification.getNotificationType() != null ? notification.getNotificationType() : "-",
                                notification.isRead(),
                                notification.getCreatedAt() != null ? notification.getCreatedAt().format(formatter) : "-"
                            };
                            tableModel.addRow(row);
                        }
                        
                        logger.info("Loaded {} notifications for user: {}", notifications.size(), currentUser.getUsername());
                    }
                    
                } catch (Exception e) {
                    loadingLabel.setText("Error loading notifications. Please try again.");
                    UIUtils.showErrorDialog(NotificationPanel.this, 
                            "Failed to load notifications. Please try again.", 
                            "Error");
                    logger.error("Error loading notifications for user: {}", currentUser.getUsername(), e);
                } finally {
                    notificationsTable.setEnabled(true);
                    refreshButton.setEnabled(true);
                    markAsReadButton.setEnabled(true);
                    markAllAsReadButton.setEnabled(true);
                }
            }
        };
        
        worker.execute();
    }
    
    /**
     * Handle mark as read button click.
     */
    private void handleMarkAsRead() {
        int selectedRow = notificationsTable.getSelectedRow();
        if (selectedRow == -1) {
            UIUtils.showErrorDialog(this, "Please select a notification", "Selection Error");
            return;
        }
        
        Integer notificationId = (Integer) tableModel.getValueAt(selectedRow, 0);
        
        // Mark as read in background thread
        SwingWorker<Boolean, Void> worker = new SwingWorker<>() {
            @Override
            protected Boolean doInBackground() throws Exception {
                logger.info("Marking notification as read: {}", notificationId);
                return notificationService.markAsRead(notificationId);
            }
            
            @Override
            protected void done() {
                try {
                    Boolean result = get();
                    if (result) {
                        // Reload notifications
                        loadNotifications();
                    } else {
                        UIUtils.showErrorDialog(NotificationPanel.this, 
                                "Failed to mark notification as read", 
                                "Error");
                    }
                } catch (Exception e) {
                    UIUtils.showErrorDialog(NotificationPanel.this, 
                            "Failed to mark notification as read", 
                            "Error");
                    logger.error("Error marking notification as read: {}", notificationId, e);
                }
            }
        };
        
        worker.execute();
    }
    
    /**
     * Handle mark all as read button click.
     */
    private void handleMarkAllAsRead() {
        User currentUser = mainFrame.getCurrentUser();
        if (currentUser == null) {
            return;
        }
        
        // Mark all as read in background thread
        SwingWorker<Integer, Void> worker = new SwingWorker<>() {
            @Override
            protected Integer doInBackground() throws Exception {
                logger.info("Marking all notifications as read for user: {}", currentUser.getUsername());
                return notificationService.markAllAsRead(currentUser.getUserId());
            }
            
            @Override
            protected void done() {
                try {
                    Integer count = get();
                    UIUtils.showInfoDialog(NotificationPanel.this, 
                            String.format("Marked %d notifications as read", count), 
                            "Success");
                    // Reload notifications
                    loadNotifications();
                } catch (Exception e) {
                    UIUtils.showErrorDialog(NotificationPanel.this, 
                            "Failed to mark all notifications as read", 
                            "Error");
                    logger.error("Error marking all notifications as read for user: {}", currentUser.getUsername(), e);
                }
            }
        };
        
        worker.execute();
    }
    
    /**
     * Handle back button click.
     */
    private void handleBack() {
        logger.debug("Back to dashboard");
        mainFrame.showDashboard();
    }
}
