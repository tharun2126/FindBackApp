package com.findback.ui.panel;

import com.findback.exception.AuthenticationException;
import com.findback.model.User;
import com.findback.service.UserService;
import com.findback.ui.frame.MainFrame;
import com.findback.ui.util.UIUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.*;
import java.awt.*;

/**
 * Login panel for user authentication.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public class LoginPanel extends JPanel {
    
    private static final Logger logger = LoggerFactory.getLogger(LoginPanel.class);
    
    private final UserService userService;
    private final MainFrame mainFrame;
    
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton registerButton;
    
    /**
     * Constructor with dependency injection.
     * 
     * @param userService the UserService to use
     * @param mainFrame the main frame for navigation
     */
    public LoginPanel(UserService userService, MainFrame mainFrame) {
        this.userService = userService;
        this.mainFrame = mainFrame;
        
        initializeUI();
    }
    
    /**
     * Initialize the UI components.
     */
    private void initializeUI() {
        setLayout(new BorderLayout());
        
        // Create title panel
        JPanel titlePanel = createTitlePanel();
        add(titlePanel, BorderLayout.NORTH);
        
        // Create form panel
        JPanel formPanel = createFormPanel();
        add(formPanel, BorderLayout.CENTER);
        
        logger.debug("LoginPanel initialized");
    }
    
    /**
     * Create the title panel.
     */
    private JPanel createTitlePanel() {
        return UIUtils.createTitlePanel("FindBack - AI Lost & Found", "Sign in to your account");
    }
    
    /**
     * Create the form panel with input fields and buttons.
     */
    private JPanel createFormPanel() {
        JPanel wrapper = new JPanel(new GridBagLayout());
        wrapper.setOpaque(false);
        
        JPanel card = new JPanel(new GridBagLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UIUtils.COLOR_CARD_BORDER, 1, true),
                BorderFactory.createEmptyBorder(25, 35, 25, 35)
        ));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 10, 8, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Username label and field
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0;
        JLabel uLabel = new JLabel("Username:");
        uLabel.setFont(UIUtils.FONT_LABEL);
        card.add(uLabel, gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        usernameField = new JTextField(18);
        usernameField.setFont(UIUtils.FONT_REGULAR);
        usernameField.setPreferredSize(new Dimension(220, 30));
        card.add(usernameField, gbc);
        
        // Password label and field
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weightx = 0;
        JLabel pLabel = new JLabel("Password:");
        pLabel.setFont(UIUtils.FONT_LABEL);
        card.add(pLabel, gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        passwordField = new JPasswordField(18);
        passwordField.setFont(UIUtils.FONT_REGULAR);
        passwordField.setPreferredSize(new Dimension(220, 30));
        passwordField.addActionListener(e -> handleLogin()); // Press Enter to login
        card.add(passwordField, gbc);
        
        // Button panel
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.weightx = 0;
        gbc.insets = new Insets(16, 10, 5, 10);
        gbc.fill = GridBagConstraints.CENTER;
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 0));
        buttonPanel.setOpaque(false);
        
        loginButton = UIUtils.createPrimaryButton("Login", new Dimension(110, 34));
        loginButton.addActionListener(e -> handleLogin());
        
        registerButton = UIUtils.createSecondaryButton("Register", new Dimension(110, 34));
        registerButton.addActionListener(e -> handleRegister());
        
        buttonPanel.add(loginButton);
        buttonPanel.add(registerButton);
        
        card.add(buttonPanel, gbc);
        wrapper.add(card);
        
        return wrapper;
    }
    
    /**
     * Handle login button click.
     */
    private void handleLogin() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());
        
        // Validate input
        if (UIUtils.isNullOrEmpty(username)) {
            UIUtils.showErrorDialog(this, "Please enter your username", "Login Error");
            return;
        }
        
        if (UIUtils.isNullOrEmpty(password)) {
            UIUtils.showErrorDialog(this, "Please enter your password", "Login Error");
            return;
        }
        
        // Perform authentication in background thread
        SwingWorker<User, Void> worker = new SwingWorker<>() {
            @Override
            protected User doInBackground() throws Exception {
                logger.info("Attempting login for user: {}", username);
                return userService.authenticateUser(username, password);
            }
            
            @Override
            protected void done() {
                try {
                    User user = get();
                    // Login successful - navigate to dashboard
                    mainFrame.showDashboard(user);
                    logger.info("User logged in successfully: {} ({})", username, user.getRole());
                    
                } catch (AuthenticationException e) {
                    // Authentication failed
                    UIUtils.showErrorDialog(LoginPanel.this, 
                            "Invalid username or password", "Login Failed");
                    logger.warn("Authentication failed for user: {}", username);
                } catch (Exception e) {
                    // Other errors
                    UIUtils.showErrorDialog(LoginPanel.this, 
                            "An error occurred during login. Please try again.", "Login Error");
                    logger.error("Error during login for user: {}", username, e);
                }
            }
        };
        
        worker.execute();
    }
    
    /**
     * Handle register button click.
     */
    private void handleRegister() {
        logger.debug("Navigate to registration panel");
        mainFrame.showCard(MainFrame.REGISTER_CARD);
    }
    
    /**
     * Clear the form fields.
     */
    public void clearForm() {
        usernameField.setText("");
        passwordField.setText("");
    }
}
