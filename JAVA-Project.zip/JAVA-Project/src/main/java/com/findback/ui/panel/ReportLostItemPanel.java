package com.findback.ui.panel;

import com.findback.model.FoundItem;
import com.findback.model.LostItem;
import com.findback.model.Match;
import com.findback.model.Notification;
import com.findback.model.User;
import com.findback.service.LostItemService;
import com.findback.service.MatchService;
import com.findback.service.NotificationService;
import com.findback.ui.frame.MainFrame;
import com.findback.ui.util.UIUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.io.File;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

/**
 * Panel for reporting a lost item.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public class ReportLostItemPanel extends JPanel {
    
    private static final Logger logger = LoggerFactory.getLogger(ReportLostItemPanel.class);
    
    private final MainFrame mainFrame;
    private final LostItemService lostItemService;
    
    private JTextField categoryField;
    private JTextField brandField;
    private JTextField colourField;
    private JTextArea descriptionArea;
    private JTextField locationField;
    private JTextField dateField;
    private JTextField imagePathField;
    private JButton chooseImageButton;
    private JButton submitButton;
    private JButton cancelButton;
    
    private String selectedImagePath;
    
    /**
     * Constructor with dependency injection.
     * 
     * @param mainFrame the main frame for navigation
     * @param lostItemService the LostItemService to use
     */
    public ReportLostItemPanel(MainFrame mainFrame, LostItemService lostItemService) {
        this.mainFrame = mainFrame;
        this.lostItemService = lostItemService;
        
        initializeUI();
    }
    
    /**
     * Initialize the UI components.
     */
    private void initializeUI() {
        setLayout(new BorderLayout());
        
        // Create title panel
        JPanel titlePanel = createTitlePanel();
        add(titlePanel, BorderLayout.NORTH);
        
        // Create form panel
        JPanel formPanel = createFormPanel();
        add(formPanel, BorderLayout.CENTER);
        
        logger.debug("ReportLostItemPanel initialized");
    }
    
    /**
     * Create the title panel.
     */
    private JPanel createTitlePanel() {
        return UIUtils.createTitlePanel("FindBack - AI Lost & Found", "Report a Lost Item");
    }
    
    /**
     * Create the form panel with input fields and buttons.
     */
    private JPanel createFormPanel() {
        JPanel wrapper = new JPanel(new GridBagLayout());
        wrapper.setOpaque(false);
        
        JPanel card = new JPanel(new GridBagLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UIUtils.COLOR_CARD_BORDER, 1, true),
                BorderFactory.createEmptyBorder(20, 35, 20, 35)
        ));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 10, 6, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Category
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0;
        JLabel catLabel = new JLabel("Category*:");
        catLabel.setFont(UIUtils.FONT_LABEL);
        card.add(catLabel, gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        categoryField = new JTextField(20);
        categoryField.setFont(UIUtils.FONT_REGULAR);
        categoryField.setPreferredSize(new Dimension(260, 28));
        card.add(categoryField, gbc);
        
        // Brand
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weightx = 0;
        JLabel brandLabel = new JLabel("Brand:");
        brandLabel.setFont(UIUtils.FONT_LABEL);
        card.add(brandLabel, gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        brandField = new JTextField(20);
        brandField.setFont(UIUtils.FONT_REGULAR);
        brandField.setPreferredSize(new Dimension(260, 28));
        card.add(brandField, gbc);
        
        // Colour
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.weightx = 0;
        JLabel colLabel = new JLabel("Colour:");
        colLabel.setFont(UIUtils.FONT_LABEL);
        card.add(colLabel, gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        colourField = new JTextField(20);
        colourField.setFont(UIUtils.FONT_REGULAR);
        colourField.setPreferredSize(new Dimension(260, 28));
        card.add(colourField, gbc);
        
        // Description
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.weightx = 0;
        JLabel descLabel = new JLabel("Description*:");
        descLabel.setFont(UIUtils.FONT_LABEL);
        card.add(descLabel, gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        descriptionArea = new JTextArea(3, 20);
        descriptionArea.setFont(UIUtils.FONT_REGULAR);
        descriptionArea.setLineWrap(true);
        descriptionArea.setWrapStyleWord(true);
        JScrollPane descScrollPane = new JScrollPane(descriptionArea);
        descScrollPane.setPreferredSize(new Dimension(260, 60));
        card.add(descScrollPane, gbc);
        
        // Location
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.weightx = 0;
        JLabel locLabel = new JLabel("Location Lost*:");
        locLabel.setFont(UIUtils.FONT_LABEL);
        card.add(locLabel, gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        locationField = new JTextField(20);
        locationField.setFont(UIUtils.FONT_REGULAR);
        locationField.setPreferredSize(new Dimension(260, 28));
        card.add(locationField, gbc);
        
        // Date Lost
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.weightx = 0;
        JLabel dateLabel = new JLabel("Date Lost*:");
        dateLabel.setFont(UIUtils.FONT_LABEL);
        card.add(dateLabel, gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        dateField = new JTextField(20);
        dateField.setFont(UIUtils.FONT_REGULAR);
        dateField.setPreferredSize(new Dimension(260, 28));
        dateField.setText(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")));
        card.add(dateField, gbc);
        
        // Image Path
        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.weightx = 0;
        JLabel imgLabel = new JLabel("Image (Optional):");
        imgLabel.setFont(UIUtils.FONT_LABEL);
        card.add(imgLabel, gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        JPanel imagePanel = new JPanel(new BorderLayout(8, 0));
        imagePanel.setOpaque(false);
        imagePathField = new JTextField(15);
        imagePathField.setFont(UIUtils.FONT_REGULAR);
        imagePathField.setEditable(false);
        chooseImageButton = UIUtils.createSecondaryButton("Choose Image", new Dimension(120, 28));
        chooseImageButton.addActionListener(e -> handleChooseImage());
        
        imagePanel.add(imagePathField, BorderLayout.CENTER);
        imagePanel.add(chooseImageButton, BorderLayout.EAST);
        card.add(imagePanel, gbc);
        
        // Button panel
        gbc.gridx = 0;
        gbc.gridy = 7;
        gbc.gridwidth = 2;
        gbc.weightx = 0;
        gbc.insets = new Insets(16, 10, 5, 10);
        gbc.fill = GridBagConstraints.CENTER;
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 14, 0));
        buttonPanel.setOpaque(false);
        
        submitButton = UIUtils.createPrimaryButton("Submit Lost Item", new Dimension(160, 34));
        submitButton.addActionListener(e -> handleSubmit());
        
        cancelButton = UIUtils.createSecondaryButton("Cancel", new Dimension(110, 34));
        cancelButton.addActionListener(e -> handleCancel());
        
        buttonPanel.add(submitButton);
        buttonPanel.add(cancelButton);
        
        card.add(buttonPanel, gbc);
        wrapper.add(card);
        
        JScrollPane scrollPane = new JScrollPane(wrapper);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(12);
        
        JPanel container = new JPanel(new BorderLayout());
        container.add(scrollPane, BorderLayout.CENTER);
        return container;
    }
    
    /**
     * Handle choose image button click.
     */
    private void handleChooseImage() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileFilter(new FileNameExtensionFilter(
                "Image files", "jpg", "jpeg", "png"));
        
        int result = fileChooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            
            // Validate that file exists and is an image
            if (selectedFile.exists() && selectedFile.isFile()) {
                String fileName = selectedFile.getName().toLowerCase();
                if (fileName.endsWith(".jpg") || fileName.endsWith(".jpeg") || fileName.endsWith(".png")) {
                    selectedImagePath = selectedFile.getAbsolutePath();
                    imagePathField.setText(selectedFile.getName());
                    logger.debug("Image selected: {}", selectedImagePath);
                } else {
                    UIUtils.showErrorDialog(this, 
                            "Please select a valid image file (JPG, JPEG, or PNG)", 
                            "Invalid Image");
                }
            } else {
                UIUtils.showErrorDialog(this, 
                        "Selected file does not exist or is not a valid file", 
                        "Invalid File");
            }
        }
    }
    
    /**
     * Handle submit button click.
     */
    private void handleSubmit() {
        String category = categoryField.getText().trim();
        String brand = brandField.getText().trim();
        String colour = colourField.getText().trim();
        String description = descriptionArea.getText().trim();
        String location = locationField.getText().trim();
        String dateStr = dateField.getText().trim();
        
        // Validate required fields
        if (UIUtils.isNullOrEmpty(category)) {
            UIUtils.showErrorDialog(this, "Please enter the category", "Validation Error");
            return;
        }
        
        if (UIUtils.isNullOrEmpty(description)) {
            UIUtils.showErrorDialog(this, "Please enter a description", "Validation Error");
            return;
        }
        
        if (description.length() < 10) {
            UIUtils.showErrorDialog(this, "Description must be at least 10 characters long", "Validation Error");
            return;
        }
        
        if (UIUtils.isNullOrEmpty(location)) {
            UIUtils.showErrorDialog(this, "Please enter the location where the item was lost", "Validation Error");
            return;
        }
        
        if (UIUtils.isNullOrEmpty(dateStr)) {
            UIUtils.showErrorDialog(this, "Please enter the date when the item was lost", "Validation Error");
            return;
        }
        
        // Parse date
        LocalDateTime dateLost;
        try {
            dateLost = LocalDateTime.parse(dateStr, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
        } catch (Exception e) {
            UIUtils.showErrorDialog(this, 
                    "Invalid date format. Please use format: yyyy-MM-dd HH:mm", 
                    "Validation Error");
            return;
        }
        
        // Get current user
        User currentUser = mainFrame.getCurrentUser();
        if (currentUser == null) {
            UIUtils.showErrorDialog(this, "You must be logged in to report a lost item", "Authentication Error");
            mainFrame.showLogin();
            return;
        }
        
        // Create lost item object
        LostItem lostItem = new LostItem();
        lostItem.setUserId(currentUser.getUserId());
        lostItem.setCategory(UIUtils.isNullOrEmpty(category) ? null : category);
        lostItem.setBrand(UIUtils.isNullOrEmpty(brand) ? null : brand);
        lostItem.setColour(UIUtils.isNullOrEmpty(colour) ? null : colour);
        lostItem.setDescription(description);
        lostItem.setLocationLost(location);
        lostItem.setDateLost(dateLost);
        lostItem.setImagePath(UIUtils.isNullOrEmpty(selectedImagePath) ? null : selectedImagePath);
        lostItem.setStatus(LostItem.ItemStatus.ACTIVE);
        
        // Submit in background thread
        SwingWorker<LostItem, Void> worker = new SwingWorker<>() {
            @Override
            protected LostItem doInBackground() throws Exception {
                logger.info("Submitting lost item for user: {}", currentUser.getUsername());
                return lostItemService.createLostItem(lostItem);
            }
            
            @Override
            protected void done() {
                try {
                    LostItem createdItem = get();
                    logger.info("Lost item created successfully: {}", createdItem.getLostItemId());
                    
                    // Trigger AI matching in background
                    triggerAIMatching(createdItem);
                    
                    UIUtils.showInfoDialog(ReportLostItemPanel.this, 
                            "Lost item reported successfully!\n\nItem ID: " + createdItem.getLostItemId() + 
                            "\n\nAI matching is being processed. You will be notified if high-confidence matches are found.", 
                            "Success");
                    
                    // Clear form and return to dashboard
                    clearForm();
                    mainFrame.showDashboard();
                    
                } catch (Exception e) {
                    UIUtils.showErrorDialog(ReportLostItemPanel.this, 
                            "Failed to report lost item. Please try again.", 
                            "Error");
                    logger.error("Error creating lost item", e);
                }
            }
        };
        
        worker.execute();
    }
    
    /**
     * Trigger AI matching for the newly created lost item.
     * This runs in a separate background thread to keep UI responsive.
     */
    private void triggerAIMatching(LostItem lostItem) {
        SwingWorker<Void, Void> matchingWorker = new SwingWorker<>() {
            @Override
            protected Void doInBackground() throws Exception {
                logger.info("Triggering AI matching for lost item ID: {}", lostItem.getLostItemId());
                
                MatchService matchService = mainFrame.getMatchService();
                NotificationService notificationService = mainFrame.getNotificationService();
                
                if (matchService != null) {
                    int matchesCreated = matchService.triggerMatchingForLostItem(lostItem.getLostItemId());
                    logger.info("AI matching complete. {} matches created for lost item {}", 
                              matchesCreated, lostItem.getLostItemId());
                    
                    if (matchesCreated > 0 && notificationService != null) {
                        List<Match> matches = matchService.getMatchesByLostItem(lostItem.getLostItemId());
                        createHighConfidenceNotifications(matches, lostItem, notificationService);
                    }
                }
                return null;
            }
            
            @Override
            protected void done() {
                try {
                    get();
                    logger.debug("AI matching background task completed for lost item");
                } catch (Exception e) {
                    logger.error("Error during AI matching for lost item", e);
                }
            }
        };
        
        matchingWorker.execute();
    }
    
    /**
     * Create notifications for high-confidence matches.
     */
    private void createHighConfidenceNotifications(List<Match> matches, LostItem lostItem, NotificationService notificationService) {
        if (matches == null || matches.isEmpty()) {
            return;
        }
        
        double notificationThreshold = 0.80;
        
        for (Match match : matches) {
            if (match.getOverallConfidenceScore() != null && 
                match.getOverallConfidenceScore().doubleValue() >= notificationThreshold) {
                
                try {
                    double confidencePercent = match.getOverallConfidenceScore().multiply(
                        new BigDecimal("100")).doubleValue();
                    
                    // Notify the owner of the lost item
                    String lostOwnerMessage = String.format(
                        "AI found a possible match for your lost item. Match confidence: %.1f%%. " +
                        "Please review and verify ownership.", confidencePercent);
                    
                    notificationService.createNotification(
                        lostItem.getUserId(),
                        "Possible Match Found",
                        lostOwnerMessage,
                        Notification.NotificationType.MATCH_FOUND,
                        match.getMatchId()
                    );
                    logger.info("Created notification for lost item owner {} on match: {}", lostItem.getUserId(), match.getMatchId());
                    
                    // Also notify the finder of the matched found item
                    if (mainFrame.getFoundItemService() != null && match.getFoundItemId() != null) {
                        Optional<FoundItem> foundItemOpt = mainFrame.getFoundItemService().findFoundItemById(match.getFoundItemId());
                        if (foundItemOpt.isPresent()) {
                            Integer finderUserId = foundItemOpt.get().getUserId();
                            if (finderUserId != null && !finderUserId.equals(lostItem.getUserId())) {
                                String finderMessage = String.format(
                                    "AI found a possible match for an item you reported found. Match confidence: %.1f%%.",
                                    confidencePercent);
                                
                                notificationService.createNotification(
                                    finderUserId,
                                    "Possible Match for Found Item",
                                    finderMessage,
                                    Notification.NotificationType.MATCH_FOUND,
                                    match.getMatchId()
                                );
                                logger.info("Created notification for finder {} on match: {}", finderUserId, match.getMatchId());
                            }
                        }
                    }
                } catch (Exception e) {
                    logger.error("Error creating high confidence notification for match ID: {}", match.getMatchId(), e);
                }
            }
        }
    }
    
    /**
     * Handle cancel button click.
     */
    private void handleCancel() {
        logger.debug("Cancel clicked - return to dashboard");
        clearForm();
        mainFrame.showDashboard();
    }
    
    /**
     * Clear the form fields.
     */
    public void clearForm() {
        categoryField.setText("");
        brandField.setText("");
        colourField.setText("");
        descriptionArea.setText("");
        locationField.setText("");
        dateField.setText(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")));
        imagePathField.setText("");
        selectedImagePath = null;
    }
}
