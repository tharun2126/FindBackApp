package com.findback.ui.panel;

import com.findback.model.LostItem;
import com.findback.model.User;
import com.findback.service.LostItemService;
import com.findback.ui.frame.MainFrame;
import com.findback.ui.util.UIUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Panel for displaying user's lost items.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public class MyLostItemsPanel extends JPanel {
    
    private static final Logger logger = LoggerFactory.getLogger(MyLostItemsPanel.class);
    
    private final MainFrame mainFrame;
    private final LostItemService lostItemService;
    
    private JTable itemsTable;
    private DefaultTableModel tableModel;
    private JButton refreshButton;
    private JButton backButton;
    private JLabel loadingLabel;
    
    /**
     * Constructor with dependency injection.
     * 
     * @param mainFrame the main frame for navigation
     * @param lostItemService the LostItemService to use
     */
    public MyLostItemsPanel(MainFrame mainFrame, LostItemService lostItemService) {
        this.mainFrame = mainFrame;
        this.lostItemService = lostItemService;
        
        initializeUI();
        if (mainFrame.getCurrentUser() != null) {
            loadLostItems();
        }
    }
    
    /**
     * Initialize the UI components.
     */
    private void initializeUI() {
        setLayout(new BorderLayout());
        
        // Create title panel
        JPanel titlePanel = createTitlePanel();
        add(titlePanel, BorderLayout.NORTH);
        
        // Create content panel
        JPanel contentPanel = createContentPanel();
        add(contentPanel, BorderLayout.CENTER);
        
        // Create button panel
        JPanel buttonPanel = createButtonPanel();
        add(buttonPanel, BorderLayout.SOUTH);
        
        logger.debug("MyLostItemsPanel initialized");
    }
    
    /**
     * Create the title panel.
     */
    private JPanel createTitlePanel() {
        return UIUtils.createTitlePanel(
                "My Lost Items",
                "Track and manage your submitted lost item reports"
        );
    }
    
    /**
     * Create the content panel with table.
     */
    private JPanel createContentPanel() {
        JPanel panel = new JPanel(new BorderLayout(0, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 24, 10, 24));
        panel.setOpaque(false);
        
        // Create table model
        String[] columnNames = {"ID", "Category", "Brand", "Colour", "Location", "Date Lost", "Status"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        // Create table
        itemsTable = new JTable(tableModel);
        itemsTable.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        itemsTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        // Apply UIUtils table formatting
        UIUtils.formatTable(itemsTable);
        UIUtils.centerAlignColumns(itemsTable, 0, 5);
        itemsTable.getColumnModel().getColumn(6).setCellRenderer(UIUtils.createStatusCellRenderer());
        
        // Set column widths
        itemsTable.getColumnModel().getColumn(0).setPreferredWidth(50);
        itemsTable.getColumnModel().getColumn(1).setPreferredWidth(100);
        itemsTable.getColumnModel().getColumn(2).setPreferredWidth(100);
        itemsTable.getColumnModel().getColumn(3).setPreferredWidth(90);
        itemsTable.getColumnModel().getColumn(4).setPreferredWidth(150);
        itemsTable.getColumnModel().getColumn(5).setPreferredWidth(130);
        itemsTable.getColumnModel().getColumn(6).setPreferredWidth(100);
        
        // Create scroll pane
        JScrollPane scrollPane = new JScrollPane(itemsTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(UIUtils.COLOR_BORDER, 1));
        
        // Create loading label
        loadingLabel = new JLabel("Loading...", SwingConstants.CENTER);
        loadingLabel.setFont(UIUtils.FONT_LABEL);
        loadingLabel.setForeground(UIUtils.COLOR_TEXT_SECONDARY);
        loadingLabel.setBorder(BorderFactory.createEmptyBorder(6, 0, 6, 0));
        
        // Add components to panel
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(loadingLabel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    /**
     * Create the button panel.
     */
    private JPanel createButtonPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 14, 14));
        panel.setOpaque(false);
        
        refreshButton = UIUtils.createSecondaryButton("Refresh", e -> loadLostItems());
        refreshButton.setPreferredSize(new Dimension(120, 36));
        
        backButton = UIUtils.createSecondaryButton("Back to Dashboard", e -> handleBack());
        backButton.setPreferredSize(new Dimension(170, 36));
        
        panel.add(refreshButton);
        panel.add(backButton);
        
        return panel;
    }
    
    /**
     * Load lost items for the current user.
     */
    public void loadLostItems() {
        User currentUser = mainFrame.getCurrentUser();
        if (currentUser == null) {
            UIUtils.showErrorDialog(this, "You must be logged in to view your items", "Authentication Error");
            mainFrame.showLogin();
            return;
        }
        
        // Show loading state
        loadingLabel.setText("Loading...");
        tableModel.setRowCount(0);
        itemsTable.setEnabled(false);
        refreshButton.setEnabled(false);
        
        // Load in background thread
        SwingWorker<List<LostItem>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<LostItem> doInBackground() throws Exception {
                logger.info("Loading lost items for user: {}", currentUser.getUsername());
                return lostItemService.getLostItemsByUser(currentUser.getUserId());
            }
            
            @Override
            protected void done() {
                try {
                    List<LostItem> items = get();
                    
                    // Clear table
                    tableModel.setRowCount(0);
                    
                    if (items.isEmpty()) {
                        loadingLabel.setText("No lost items found. Click 'Report Lost Item' to report one.");
                    } else {
                        loadingLabel.setText("");
                        
                        // Add items to table
                        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
                        for (LostItem item : items) {
                            Object[] row = {
                                item.getLostItemId(),
                                item.getCategory() != null ? item.getCategory() : "-",
                                item.getBrand() != null ? item.getBrand() : "-",
                                item.getColour() != null ? item.getColour() : "-",
                                item.getLocationLost() != null ? item.getLocationLost() : "-",
                                item.getDateLost() != null ? item.getDateLost().format(formatter) : "-",
                                item.getStatus() != null ? item.getStatus() : "-"
                            };
                            tableModel.addRow(row);
                        }
                        
                        logger.info("Loaded {} lost items for user: {}", items.size(), currentUser.getUsername());
                    }
                    
                } catch (Exception e) {
                    loadingLabel.setText("Error loading items. Please try again.");
                    UIUtils.showErrorDialog(MyLostItemsPanel.this, 
                            "Failed to load lost items. Please try again.", 
                            "Error");
                    logger.error("Error loading lost items for user: {}", currentUser.getUsername(), e);
                } finally {
                    itemsTable.setEnabled(true);
                    refreshButton.setEnabled(true);
                }
            }
        };
        
        worker.execute();
    }
    
    /**
     * Handle back button click.
     */
    private void handleBack() {
        logger.debug("Back to dashboard");
        mainFrame.showDashboard();
    }
}
