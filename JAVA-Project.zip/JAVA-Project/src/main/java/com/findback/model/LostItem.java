package com.findback.model;

import java.time.LocalDateTime;

/**
 * LostItem model class representing a lost item reported by a user.
 * 
 * Lost items are reported by users and matched with found items
 * using AI-powered similarity analysis.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public class LostItem {
    
    private Integer lostItemId;
    private Integer userId;
    private String category;
    private String brand;
    private String colour;
    private String description;
    private String locationLost;
    private LocalDateTime dateLost;
    private String imagePath;
    private ItemStatus status;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    
    /**
     * Enum for item status.
     */
    public enum ItemStatus {
        ACTIVE,
        RESOLVED
    }
    
    /**
     * Default constructor.
     */
    public LostItem() {
        this.status = ItemStatus.ACTIVE;
    }
    
    /**
     * Constructor with required fields.
     * 
     * @param userId the user ID who reported the item
     * @param category the item category
     * @param description the item description
     * @param locationLost where the item was lost
     * @param dateLost when the item was lost
     */
    public LostItem(Integer userId, String category, String description, 
                   String locationLost, LocalDateTime dateLost) {
        this();
        this.userId = userId;
        this.category = category;
        this.description = description;
        this.locationLost = locationLost;
        this.dateLost = dateLost;
    }
    
    /**
     * Full constructor with all fields except ID and timestamps.
     */
    public LostItem(Integer userId, String category, String brand, String colour, 
                   String description, String locationLost, LocalDateTime dateLost, 
                   String imagePath, ItemStatus status) {
        this.userId = userId;
        this.category = category;
        this.brand = brand;
        this.colour = colour;
        this.description = description;
        this.locationLost = locationLost;
        this.dateLost = dateLost;
        this.imagePath = imagePath;
        this.status = status;
    }
    
    /**
     * Full constructor with all fields.
     */
    public LostItem(Integer lostItemId, Integer userId, String category, String brand, 
                   String colour, String description, String locationLost, 
                   LocalDateTime dateLost, String imagePath, ItemStatus status, 
                   LocalDateTime createdAt, LocalDateTime updatedAt) {
        this.lostItemId = lostItemId;
        this.userId = userId;
        this.category = category;
        this.brand = brand;
        this.colour = colour;
        this.description = description;
        this.locationLost = locationLost;
        this.dateLost = dateLost;
        this.imagePath = imagePath;
        this.status = status;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }
    
    // Getters and Setters
    
    public Integer getLostItemId() {
        return lostItemId;
    }
    
    public void setLostItemId(Integer lostItemId) {
        this.lostItemId = lostItemId;
    }
    
    public Integer getUserId() {
        return userId;
    }
    
    public void setUserId(Integer userId) {
        this.userId = userId;
    }
    
    public String getCategory() {
        return category;
    }
    
    public void setCategory(String category) {
        this.category = category;
    }
    
    public String getBrand() {
        return brand;
    }
    
    public void setBrand(String brand) {
        this.brand = brand;
    }
    
    public String getColour() {
        return colour;
    }
    
    public void setColour(String colour) {
        this.colour = colour;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public String getLocationLost() {
        return locationLost;
    }
    
    public void setLocationLost(String locationLost) {
        this.locationLost = locationLost;
    }
    
    public LocalDateTime getDateLost() {
        return dateLost;
    }
    
    public void setDateLost(LocalDateTime dateLost) {
        this.dateLost = dateLost;
    }
    
    public String getImagePath() {
        return imagePath;
    }
    
    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }
    
    public ItemStatus getStatus() {
        return status;
    }
    
    public void setStatus(ItemStatus status) {
        this.status = status;
    }
    
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
    
    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }
    
    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
    
    /**
     * Check if item is active.
     * 
     * @return true if item is active, false otherwise
     */
    public boolean isActive() {
        return status == ItemStatus.ACTIVE;
    }
    
    @Override
    public String toString() {
        return "LostItem{" +
                "lostItemId=" + lostItemId +
                ", userId=" + userId +
                ", category='" + category + '\'' +
                ", brand='" + brand + '\'' +
                ", colour='" + colour + '\'' +
                ", description='" + description + '\'' +
                ", locationLost='" + locationLost + '\'' +
                ", dateLost=" + dateLost +
                ", status=" + status +
                '}';
    }
}
