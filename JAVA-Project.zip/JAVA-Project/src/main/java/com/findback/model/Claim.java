package com.findback.model;

import java.time.LocalDateTime;

/**
 * Claim model class representing a user's claim on a matched item.
 * 
 * Users can claim matched items, which then go through an ownership
 * verification process by administrators.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public class Claim {
    
    private Integer claimId;
    private Integer matchId;
    private Integer userId;
    private ClaimStatus claimStatus;
    private String verificationNotes;
    private Integer adminId;
    private LocalDateTime verifiedAt;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    
    /**
     * Enum for claim status.
     */
    public enum ClaimStatus {
        PENDING,
        UNDER_REVIEW,
        VERIFIED,
        REJECTED
    }
    
    /**
     * Default constructor.
     */
    public Claim() {
        this.claimStatus = ClaimStatus.PENDING;
    }
    
    /**
     * Constructor with required fields.
     * 
     * @param matchId the match ID being claimed
     * @param userId the user ID making the claim
     */
    public Claim(Integer matchId, Integer userId) {
        this();
        this.matchId = matchId;
        this.userId = userId;
    }
    
    /**
     * Full constructor with all fields except ID and timestamps.
     */
    public Claim(Integer matchId, Integer userId, ClaimStatus claimStatus, 
                String verificationNotes, Integer adminId, LocalDateTime verifiedAt) {
        this.matchId = matchId;
        this.userId = userId;
        this.claimStatus = claimStatus;
        this.verificationNotes = verificationNotes;
        this.adminId = adminId;
        this.verifiedAt = verifiedAt;
    }
    
    /**
     * Full constructor with all fields.
     */
    public Claim(Integer claimId, Integer matchId, Integer userId, ClaimStatus claimStatus, 
                String verificationNotes, Integer adminId, LocalDateTime verifiedAt, 
                LocalDateTime createdAt, LocalDateTime updatedAt) {
        this.claimId = claimId;
        this.matchId = matchId;
        this.userId = userId;
        this.claimStatus = claimStatus;
        this.verificationNotes = verificationNotes;
        this.adminId = adminId;
        this.verifiedAt = verifiedAt;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }
    
    // Getters and Setters
    
    public Integer getClaimId() {
        return claimId;
    }
    
    public void setClaimId(Integer claimId) {
        this.claimId = claimId;
    }
    
    public Integer getMatchId() {
        return matchId;
    }
    
    public void setMatchId(Integer matchId) {
        this.matchId = matchId;
    }
    
    public Integer getUserId() {
        return userId;
    }
    
    public void setUserId(Integer userId) {
        this.userId = userId;
    }
    
    public ClaimStatus getClaimStatus() {
        return claimStatus;
    }
    
    public void setClaimStatus(ClaimStatus claimStatus) {
        this.claimStatus = claimStatus;
    }
    
    public String getVerificationNotes() {
        return verificationNotes;
    }
    
    public void setVerificationNotes(String verificationNotes) {
        this.verificationNotes = verificationNotes;
    }
    
    public Integer getAdminId() {
        return adminId;
    }
    
    public void setAdminId(Integer adminId) {
        this.adminId = adminId;
    }
    
    public LocalDateTime getVerifiedAt() {
        return verifiedAt;
    }
    
    public void setVerifiedAt(LocalDateTime verifiedAt) {
        this.verifiedAt = verifiedAt;
    }
    
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
    
    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }
    
    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
    
    /**
     * Check if claim is verified.
     * 
     * @return true if verified, false otherwise
     */
    public boolean isVerified() {
        return claimStatus == ClaimStatus.VERIFIED;
    }
    
    /**
     * Check if claim is pending.
     * 
     * @return true if pending, false otherwise
     */
    public boolean isPending() {
        return claimStatus == ClaimStatus.PENDING;
    }
    
    @Override
    public String toString() {
        return "Claim{" +
                "claimId=" + claimId +
                ", matchId=" + matchId +
                ", userId=" + userId +
                ", claimStatus=" + claimStatus +
                ", adminId=" + adminId +
                ", verifiedAt=" + verifiedAt +
                '}';
    }
}
