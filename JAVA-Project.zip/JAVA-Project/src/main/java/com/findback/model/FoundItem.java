package com.findback.model;

import java.time.LocalDateTime;

/**
 * FoundItem model class representing a found item reported by a user.
 * 
 * Found items are reported by users and matched with lost items
 * using AI-powered similarity analysis.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public class FoundItem {
    
    private Integer foundItemId;
    private Integer userId;
    private String category;
    private String brand;
    private String colour;
    private String description;
    private String locationFound;
    private LocalDateTime dateFound;
    private String imagePath;
    private ItemStatus status;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    
    /**
     * Enum for item status.
     */
    public enum ItemStatus {
        ACTIVE,
        RESOLVED
    }
    
    /**
     * Default constructor.
     */
    public FoundItem() {
        this.status = ItemStatus.ACTIVE;
    }
    
    /**
     * Constructor with required fields.
     * 
     * @param userId the user ID who reported the item
     * @param category the item category
     * @param description the item description
     * @param locationFound where the item was found
     * @param dateFound when the item was found
     */
    public FoundItem(Integer userId, String category, String description, 
                    String locationFound, LocalDateTime dateFound) {
        this();
        this.userId = userId;
        this.category = category;
        this.description = description;
        this.locationFound = locationFound;
        this.dateFound = dateFound;
    }
    
    /**
     * Full constructor with all fields except ID and timestamps.
     */
    public FoundItem(Integer userId, String category, String brand, String colour, 
                   String description, String locationFound, LocalDateTime dateFound, 
                   String imagePath, ItemStatus status) {
        this.userId = userId;
        this.category = category;
        this.brand = brand;
        this.colour = colour;
        this.description = description;
        this.locationFound = locationFound;
        this.dateFound = dateFound;
        this.imagePath = imagePath;
        this.status = status;
    }
    
    /**
     * Full constructor with all fields.
     */
    public FoundItem(Integer foundItemId, Integer userId, String category, String brand, 
                    String colour, String description, String locationFound, 
                    LocalDateTime dateFound, String imagePath, ItemStatus status, 
                    LocalDateTime createdAt, LocalDateTime updatedAt) {
        this.foundItemId = foundItemId;
        this.userId = userId;
        this.category = category;
        this.brand = brand;
        this.colour = colour;
        this.description = description;
        this.locationFound = locationFound;
        this.dateFound = dateFound;
        this.imagePath = imagePath;
        this.status = status;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }
    
    // Getters and Setters
    
    public Integer getFoundItemId() {
        return foundItemId;
    }
    
    public void setFoundItemId(Integer foundItemId) {
        this.foundItemId = foundItemId;
    }
    
    public Integer getUserId() {
        return userId;
    }
    
    public void setUserId(Integer userId) {
        this.userId = userId;
    }
    
    public String getCategory() {
        return category;
    }
    
    public void setCategory(String category) {
        this.category = category;
    }
    
    public String getBrand() {
        return brand;
    }
    
    public void setBrand(String brand) {
        this.brand = brand;
    }
    
    public String getColour() {
        return colour;
    }
    
    public void setColour(String colour) {
        this.colour = colour;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public String getLocationFound() {
        return locationFound;
    }
    
    public void setLocationFound(String locationFound) {
        this.locationFound = locationFound;
    }
    
    public LocalDateTime getDateFound() {
        return dateFound;
    }
    
    public void setDateFound(LocalDateTime dateFound) {
        this.dateFound = dateFound;
    }
    
    public String getImagePath() {
        return imagePath;
    }
    
    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }
    
    public ItemStatus getStatus() {
        return status;
    }
    
    public void setStatus(ItemStatus status) {
        this.status = status;
    }
    
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
    
    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }
    
    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
    
    /**
     * Check if item is active.
     * 
     * @return true if item is active, false otherwise
     */
    public boolean isActive() {
        return status == ItemStatus.ACTIVE;
    }
    
    @Override
    public String toString() {
        return "FoundItem{" +
                "foundItemId=" + foundItemId +
                ", userId=" + userId +
                ", category='" + category + '\'' +
                ", brand='" + brand + '\'' +
                ", colour='" + colour + '\'' +
                ", description='" + description + '\'' +
                ", locationFound='" + locationFound + '\'' +
                ", dateFound=" + dateFound +
                ", status=" + status +
                '}';
    }
}
