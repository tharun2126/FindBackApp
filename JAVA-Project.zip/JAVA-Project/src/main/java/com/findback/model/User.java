package com.findback.model;

import java.time.LocalDateTime;

/**
 * User model class representing a user in the FindBack system.
 * 
 * Users can be either regular users or administrators.
 * Each user has a unique username and email.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public class User {
    
    private Integer userId;
    private String username;
    private String email;
    private String passwordHash;
    private String fullName;
    private String phone;
    private UserRole role;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    
    /**
     * Enum for user roles.
     */
    public enum UserRole {
        USER,
        ADMIN
    }
    
    /**
     * Default constructor.
     */
    public User() {
        this.role = UserRole.USER;
    }
    
    /**
     * Constructor with required fields.
     * 
     * @param username the unique username
     * @param email the unique email
     * @param passwordHash the hashed password
     * @param fullName the user's full name
     */
    public User(String username, String email, String passwordHash, String fullName) {
        this();
        this.username = username;
        this.email = email;
        this.passwordHash = passwordHash;
        this.fullName = fullName;
    }
    
    /**
     * Constructor with all fields except ID and timestamps.
     * 
     * @param username the unique username
     * @param email the unique email
     * @param passwordHash the hashed password
     * @param fullName the user's full name
     * @param phone the phone number
     * @param role the user role
     */
    public User(String username, String email, String passwordHash, String fullName, 
                String phone, UserRole role) {
        this.username = username;
        this.email = email;
        this.passwordHash = passwordHash;
        this.fullName = fullName;
        this.phone = phone;
        this.role = role;
    }
    
    /**
     * Full constructor with all fields.
     */
    public User(Integer userId, String username, String email, String passwordHash, 
                String fullName, String phone, UserRole role, LocalDateTime createdAt, 
                LocalDateTime updatedAt) {
        this.userId = userId;
        this.username = username;
        this.email = email;
        this.passwordHash = passwordHash;
        this.fullName = fullName;
        this.phone = phone;
        this.role = role;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }
    
    // Getters and Setters
    
    public Integer getUserId() {
        return userId;
    }
    
    public void setUserId(Integer userId) {
        this.userId = userId;
    }
    
    public String getUsername() {
        return username;
    }
    
    public void setUsername(String username) {
        this.username = username;
    }
    
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public String getPasswordHash() {
        return passwordHash;
    }
    
    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }
    
    public String getFullName() {
        return fullName;
    }
    
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }
    
    public String getPhone() {
        return phone;
    }
    
    public void setPhone(String phone) {
        this.phone = phone;
    }
    
    public UserRole getRole() {
        return role;
    }
    
    public void setRole(UserRole role) {
        this.role = role;
    }
    
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
    
    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }
    
    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
    
    /**
     * Check if user is an admin.
     * 
     * @return true if user is admin, false otherwise
     */
    public boolean isAdmin() {
        return role == UserRole.ADMIN;
    }
    
    @Override
    public String toString() {
        return "User{" +
                "userId=" + userId +
                ", username='" + username + '\'' +
                ", email='" + email + '\'' +
                ", fullName='" + fullName + '\'' +
                ", role=" + role +
                '}';
    }
}
