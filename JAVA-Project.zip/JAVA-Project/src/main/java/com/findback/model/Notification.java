package com.findback.model;

import java.time.LocalDateTime;

/**
 * Notification model class representing in-app notifications for users.
 * 
 * Notifications are generated for various events such as match found,
 * claim status updates, and item returns.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public class Notification {
    
    private Integer notificationId;
    private Integer userId;
    private String title;
    private String message;
    private NotificationType notificationType;
    private Integer relatedMatchId;
    private boolean isRead;
    private LocalDateTime createdAt;
    
    /**
     * Enum for notification types.
     */
    public enum NotificationType {
        MATCH_FOUND,
        CLAIM_STATUS,
        ITEM_RETURNED,
        SYSTEM
    }
    
    /**
     * Default constructor.
     */
    public Notification() {
        this.isRead = false;
    }
    
    /**
     * Constructor with required fields.
     * 
     * @param userId the user ID to receive the notification
     * @param title the notification title
     * @param message the notification message
     * @param notificationType the type of notification
     */
    public Notification(Integer userId, String title, String message, NotificationType notificationType) {
        this();
        this.userId = userId;
        this.title = title;
        this.message = message;
        this.notificationType = notificationType;
    }
    
    /**
     * Constructor with related match ID.
     * 
     * @param userId the user ID to receive the notification
     * @param title the notification title
     * @param message the notification message
     * @param notificationType the type of notification
     * @param relatedMatchId the related match ID (if applicable)
     */
    public Notification(Integer userId, String title, String message, 
                       NotificationType notificationType, Integer relatedMatchId) {
        this(userId, title, message, notificationType);
        this.relatedMatchId = relatedMatchId;
    }
    
    /**
     * Full constructor with all fields.
     */
    public Notification(Integer notificationId, Integer userId, String title, String message, 
                       NotificationType notificationType, Integer relatedMatchId, 
                       boolean isRead, LocalDateTime createdAt) {
        this.notificationId = notificationId;
        this.userId = userId;
        this.title = title;
        this.message = message;
        this.notificationType = notificationType;
        this.relatedMatchId = relatedMatchId;
        this.isRead = isRead;
        this.createdAt = createdAt;
    }
    
    // Getters and Setters
    
    public Integer getNotificationId() {
        return notificationId;
    }
    
    public void setNotificationId(Integer notificationId) {
        this.notificationId = notificationId;
    }
    
    public Integer getUserId() {
        return userId;
    }
    
    public void setUserId(Integer userId) {
        this.userId = userId;
    }
    
    public String getTitle() {
        return title;
    }
    
    public void setTitle(String title) {
        this.title = title;
    }
    
    public String getMessage() {
        return message;
    }
    
    public void setMessage(String message) {
        this.message = message;
    }
    
    public NotificationType getNotificationType() {
        return notificationType;
    }
    
    public void setNotificationType(NotificationType notificationType) {
        this.notificationType = notificationType;
    }
    
    public Integer getRelatedMatchId() {
        return relatedMatchId;
    }
    
    public void setRelatedMatchId(Integer relatedMatchId) {
        this.relatedMatchId = relatedMatchId;
    }
    
    public boolean isRead() {
        return isRead;
    }
    
    public void setRead(boolean read) {
        isRead = read;
    }
    
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
    
    /**
     * Mark notification as read.
     */
    public void markAsRead() {
        this.isRead = true;
    }
    
    @Override
    public String toString() {
        return "Notification{" +
                "notificationId=" + notificationId +
                ", userId=" + userId +
                ", title='" + title + '\'' +
                ", notificationType=" + notificationType +
                ", isRead=" + isRead +
                ", createdAt=" + createdAt +
                '}';
    }
}
