package com.findback.service;

import com.findback.model.Match;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

/**
 * Service interface for match-related business logic.
 * 
 * Defines the business operations for AI-generated match management.
 * This service will receive AI-generated scores from the AI/ML layer.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public interface MatchService {
    
    /**
     * Save a match result from AI/ML analysis.
     * 
     * @param match the match to save with similarity scores
     * @return the saved match with generated ID
     * @throws IllegalArgumentException if match data or scores are invalid
     */
    Match saveMatch(Match match);
    
    /**
     * Update an existing match.
     * 
     * @param match the match to update
     * @return the updated match
     * @throws IllegalArgumentException if match data is invalid
     */
    Match updateMatch(Match match);
    
    /**
     * Delete a match by ID.
     * 
     * @param matchId the match ID to delete
     * @return true if deleted successfully
     */
    boolean deleteMatch(Integer matchId);
    
    /**
     * Find a match by ID.
     * 
     * @param matchId the match ID
     * @return Optional containing the match if found
     */
    Optional<Match> findMatchById(Integer matchId);
    
    /**
     * Get all matches for a specific lost item.
     * 
     * @param lostItemId the lost item ID
     * @return list of matches for the lost item
     */
    List<Match> getMatchesByLostItem(Integer lostItemId);
    
    /**
     * Get all matches for a specific found item.
     * 
     * @param foundItemId the found item ID
     * @return list of matches for the found item
     */
    List<Match> getMatchesByFoundItem(Integer foundItemId);
    
    /**
     * Get all high-confidence matches.
     * 
     * @param threshold the confidence threshold (0.0 to 1.0)
     * @return list of high-confidence matches
     * @throws IllegalArgumentException if threshold is invalid
     */
    List<Match> getHighConfidenceMatches(double threshold);
    
    /**
     * Update match status.
     * 
     * @param matchId the match ID
     * @param status the new status
     * @return true if updated successfully
     */
    boolean updateMatchStatus(Integer matchId, Match.MatchStatus status);
    
    /**
     * Validate match scores.
     * 
     * @param semanticScore semantic similarity score (0.0 to 1.0)
     * @param imageScore image similarity score (0.0 to 1.0)
     * @param attributeScore attribute similarity score (0.0 to 1.0)
     * @param overallScore overall confidence score (0.0 to 1.0)
     * @return true if all scores are valid
     */
    boolean validateMatchScores(BigDecimal semanticScore, BigDecimal imageScore, 
                                 BigDecimal attributeScore, BigDecimal overallScore);
    
    /**
     * Trigger AI matching for a newly reported found item.
     * 
     * Compares the found item with all active lost items,
     * calculates similarity scores, and saves significant matches.
     * 
     * @param foundItemId the ID of the newly reported found item
     * @return number of matches created
     */
    int triggerMatchingForFoundItem(Integer foundItemId);
    
    /**
     * Trigger AI matching for a newly reported lost item.
     * 
     * Compares the lost item with all active found items,
     * calculates similarity scores, and saves significant matches.
     * 
     * @param lostItemId the ID of the newly reported lost item
     * @return number of matches created
     */
    int triggerMatchingForLostItem(Integer lostItemId);
}
