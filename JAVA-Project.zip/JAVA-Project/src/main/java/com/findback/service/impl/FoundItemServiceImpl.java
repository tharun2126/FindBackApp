package com.findback.service.impl;

import com.findback.dao.FoundItemDAO;
import com.findback.exception.DatabaseException;
import com.findback.model.FoundItem;
import com.findback.service.FoundItemService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Optional;

/**
 * Implementation of FoundItemService interface.
 * 
 * Provides business logic for found item management.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public class FoundItemServiceImpl implements FoundItemService {
    
    private static final Logger logger = LoggerFactory.getLogger(FoundItemServiceImpl.class);
    
    private final FoundItemDAO foundItemDAO;
    
    /**
     * Constructor with dependency injection.
     * 
     * @param foundItemDAO the FoundItemDAO to use
     */
    public FoundItemServiceImpl(FoundItemDAO foundItemDAO) {
        this.foundItemDAO = foundItemDAO;
    }
    
    @Override
    public FoundItem createFoundItem(FoundItem foundItem) {
        logger.debug("Creating found item for user ID: {}", foundItem.getUserId());
        
        // Validate found item data
        validateFoundItem(foundItem);
        
        // Set default status if not set
        if (foundItem.getStatus() == null) {
            foundItem.setStatus(FoundItem.ItemStatus.ACTIVE);
        }
        
        return foundItemDAO.save(foundItem);
    }
    
    @Override
    public FoundItem updateFoundItem(FoundItem foundItem) {
        logger.debug("Updating found item with ID: {}", foundItem.getFoundItemId());
        
        // Validate found item data
        validateFoundItem(foundItem);
        
        // Ensure found item ID is set
        if (foundItem.getFoundItemId() == null) {
            throw new IllegalArgumentException("Found item ID cannot be null for update");
        }
        
        // Check if found item exists
        Optional<FoundItem> existingItem = foundItemDAO.findById(foundItem.getFoundItemId());
        if (existingItem.isEmpty()) {
            throw new IllegalArgumentException("Found item not found with ID: " + foundItem.getFoundItemId());
        }
        
        return foundItemDAO.update(foundItem);
    }
    
    @Override
    public boolean deleteFoundItem(Integer foundItemId) {
        logger.debug("Deleting found item with ID: {}", foundItemId);
        return foundItemDAO.delete(foundItemId);
    }
    
    @Override
    public Optional<FoundItem> findFoundItemById(Integer foundItemId) {
        logger.debug("Finding found item by ID: {}", foundItemId);
        return foundItemDAO.findById(foundItemId);
    }
    
    @Override
    public List<FoundItem> getFoundItemsByUser(Integer userId) {
        logger.debug("Getting found items for user ID: {}", userId);
        return foundItemDAO.findByUserId(userId);
    }
    
    @Override
    public List<FoundItem> getActiveFoundItems() {
        logger.debug("Getting all active found items");
        return foundItemDAO.findActive();
    }
    
    @Override
    public List<FoundItem> getFoundItemsByCategory(String category) {
        logger.debug("Getting found items by category: {}", category);
        return foundItemDAO.findByCategory(category);
    }
    
    @Override
    public boolean markAsResolved(Integer foundItemId) {
        logger.debug("Marking found item as resolved: {}", foundItemId);
        
        Optional<FoundItem> foundItemOptional = foundItemDAO.findById(foundItemId);
        if (foundItemOptional.isEmpty()) {
            throw new IllegalArgumentException("Found item not found with ID: " + foundItemId);
        }
        
        FoundItem foundItem = foundItemOptional.get();
        foundItem.setStatus(FoundItem.ItemStatus.RESOLVED);
        foundItemDAO.update(foundItem);
        
        return true;
    }
    
    @Override
    public boolean markAsActive(Integer foundItemId) {
        logger.debug("Marking found item as active: {}", foundItemId);
        
        Optional<FoundItem> foundItemOptional = foundItemDAO.findById(foundItemId);
        if (foundItemOptional.isEmpty()) {
            throw new IllegalArgumentException("Found item not found with ID: " + foundItemId);
        }
        
        FoundItem foundItem = foundItemOptional.get();
        foundItem.setStatus(FoundItem.ItemStatus.ACTIVE);
        foundItemDAO.update(foundItem);
        
        return true;
    }
    
    /**
     * Validate found item data.
     * 
     * @param foundItem the found item to validate
     * @throws IllegalArgumentException if found item data is invalid
     */
    private void validateFoundItem(FoundItem foundItem) {
        if (foundItem == null) {
            throw new IllegalArgumentException("Found item cannot be null");
        }
        if (foundItem.getUserId() == null) {
            throw new IllegalArgumentException("User ID cannot be null");
        }
        if (foundItem.getCategory() == null || foundItem.getCategory().trim().isEmpty()) {
            throw new IllegalArgumentException("Category cannot be null or empty");
        }
        if (foundItem.getDescription() == null || foundItem.getDescription().trim().isEmpty()) {
            throw new IllegalArgumentException("Description cannot be null or empty");
        }
        if (foundItem.getLocationFound() == null || foundItem.getLocationFound().trim().isEmpty()) {
            throw new IllegalArgumentException("Location found cannot be null or empty");
        }
        if (foundItem.getDateFound() == null) {
            throw new IllegalArgumentException("Date found cannot be null");
        }
    }
}
