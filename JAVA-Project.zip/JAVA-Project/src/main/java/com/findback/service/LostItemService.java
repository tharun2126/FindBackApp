package com.findback.service;

import com.findback.model.LostItem;

import java.util.List;
import java.util.Optional;

/**
 * Service interface for lost item-related business logic.
 * 
 * Defines the business operations for lost item management including
 * reporting, updating, and retrieving lost items.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public interface LostItemService {
    
    /**
     * Create a new lost item report.
     * 
     * @param lostItem the lost item to report
     * @return the created lost item with generated ID
     * @throws IllegalArgumentException if lost item data is invalid
     */
    LostItem createLostItem(LostItem lostItem);
    
    /**
     * Update an existing lost item.
     * 
     * @param lostItem the lost item to update
     * @return the updated lost item
     * @throws IllegalArgumentException if lost item data is invalid
     */
    LostItem updateLostItem(LostItem lostItem);
    
    /**
     * Delete a lost item by ID.
     * 
     * @param lostItemId the lost item ID to delete
     * @return true if deleted successfully
     */
    boolean deleteLostItem(Integer lostItemId);
    
    /**
     * Find a lost item by ID.
     * 
     * @param lostItemId the lost item ID
     * @return Optional containing the lost item if found
     */
    Optional<LostItem> findLostItemById(Integer lostItemId);
    
    /**
     * Get all lost items for a specific user.
     * 
     * @param userId the user ID
     * @return list of lost items for the user
     */
    List<LostItem> getLostItemsByUser(Integer userId);
    
    /**
     * Get all active lost items in the system.
     * 
     * @return list of active lost items
     */
    List<LostItem> getActiveLostItems();
    
    /**
     * Get lost items by category.
     * 
     * @param category the category
     * @return list of lost items in the category
     */
    List<LostItem> getLostItemsByCategory(String category);
    
    /**
     * Mark a lost item as resolved.
     * 
     * @param lostItemId the lost item ID
     * @return true if marked as resolved successfully
     */
    boolean markAsResolved(Integer lostItemId);
    
    /**
     * Mark a lost item as active.
     * 
     * @param lostItemId the lost item ID
     * @return true if marked as active successfully
     */
    boolean markAsActive(Integer lostItemId);
}
