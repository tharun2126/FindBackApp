package com.findback.service.impl;

import com.findback.dao.ClaimDAO;
import com.findback.dao.MatchDAO;
import com.findback.exception.DatabaseException;
import com.findback.model.Claim;
import com.findback.model.Match;
import com.findback.service.ClaimService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * Implementation of ClaimService interface.
 * 
 * Provides business logic for claim management including
 * submission, verification, and status tracking.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public class ClaimServiceImpl implements ClaimService {
    
    private static final Logger logger = LoggerFactory.getLogger(ClaimServiceImpl.class);
    
    private final ClaimDAO claimDAO;
    private final MatchDAO matchDAO;
    
    /**
     * Constructor with dependency injection.
     * 
     * @param claimDAO the ClaimDAO to use
     * @param matchDAO the MatchDAO to use
     */
    public ClaimServiceImpl(ClaimDAO claimDAO, MatchDAO matchDAO) {
        this.claimDAO = claimDAO;
        this.matchDAO = matchDAO;
    }
    
    @Override
    public Claim createClaim(Claim claim) {
        logger.debug("Creating claim for match ID: {} by user ID: {}", 
                    claim.getMatchId(), claim.getUserId());
        
        // Validate claim data
        validateClaim(claim);
        
        // Set default status if not set
        if (claim.getClaimStatus() == null) {
            claim.setClaimStatus(Claim.ClaimStatus.PENDING);
        }
        
        // Check if match exists
        Optional<Match> matchOptional = matchDAO.findById(claim.getMatchId());
        if (matchOptional.isEmpty()) {
            throw new IllegalArgumentException("Match not found with ID: " + claim.getMatchId());
        }
        
        return claimDAO.save(claim);
    }
    
    @Override
    public Claim updateClaim(Claim claim) {
        logger.debug("Updating claim with ID: {}", claim.getClaimId());
        
        // Validate claim data
        validateClaim(claim);
        
        // Ensure claim ID is set
        if (claim.getClaimId() == null) {
            throw new IllegalArgumentException("Claim ID cannot be null for update");
        }
        
        // Check if claim exists
        Optional<Claim> existingClaim = claimDAO.findById(claim.getClaimId());
        if (existingClaim.isEmpty()) {
            throw new IllegalArgumentException("Claim not found with ID: " + claim.getClaimId());
        }
        
        // Validate status transition
        Claim existing = existingClaim.get();
        if (claim.getClaimStatus() != null && 
            !isValidStatusTransition(existing.getClaimStatus(), claim.getClaimStatus())) {
            throw new IllegalStateException("Invalid status transition from " + 
                existing.getClaimStatus() + " to " + claim.getClaimStatus());
        }
        
        return claimDAO.update(claim);
    }
    
    @Override
    public boolean deleteClaim(Integer claimId) {
        logger.debug("Deleting claim with ID: {}", claimId);
        return claimDAO.delete(claimId);
    }
    
    @Override
    public Optional<Claim> findClaimById(Integer claimId) {
        logger.debug("Finding claim by ID: {}", claimId);
        return claimDAO.findById(claimId);
    }
    
    @Override
    public List<Claim> getClaimsByUser(Integer userId) {
        logger.debug("Getting claims for user ID: {}", userId);
        return claimDAO.findByUserId(userId);
    }
    
    @Override
    public List<Claim> getClaimsByMatch(Integer matchId) {
        logger.debug("Getting claims for match ID: {}", matchId);
        return claimDAO.findByMatchId(matchId);
    }
    
    @Override
    public List<Claim> getClaimsByStatus(Claim.ClaimStatus status) {
        logger.debug("Getting claims with status: {}", status);
        return claimDAO.findByStatus(status);
    }
    
    @Override
    public Claim updateClaimStatus(Integer claimId, Claim.ClaimStatus newStatus, 
                                   Integer adminId, String verificationNotes) {
        logger.debug("Updating claim {} status to {} by admin {}", claimId, newStatus, adminId);
        
        if (claimId == null) {
            throw new IllegalArgumentException("Claim ID cannot be null");
        }
        if (newStatus == null) {
            throw new IllegalArgumentException("New status cannot be null");
        }
        if (adminId == null) {
            throw new IllegalArgumentException("Admin ID cannot be null");
        }
        
        // Find claim
        Optional<Claim> claimOptional = claimDAO.findById(claimId);
        if (claimOptional.isEmpty()) {
            throw new IllegalArgumentException("Claim not found with ID: " + claimId);
        }
        
        Claim claim = claimOptional.get();
        
        // Validate status transition
        if (!isValidStatusTransition(claim.getClaimStatus(), newStatus)) {
            throw new IllegalStateException("Invalid status transition from " + 
                claim.getClaimStatus() + " to " + newStatus);
        }
        
        // Update claim
        claim.setClaimStatus(newStatus);
        claim.setAdminId(adminId);
        claim.setVerificationNotes(verificationNotes);
        
        // Set verified timestamp if status is VERIFIED or REJECTED
        if (newStatus == Claim.ClaimStatus.VERIFIED || newStatus == Claim.ClaimStatus.REJECTED) {
            claim.setVerifiedAt(LocalDateTime.now());
        }
        
        return claimDAO.update(claim);
    }
    
    @Override
    public boolean isValidStatusTransition(Claim.ClaimStatus currentStatus, Claim.ClaimStatus newStatus) {
        if (currentStatus == null || newStatus == null) {
            return false;
        }
        
        // Allow same status (no change)
        if (currentStatus == newStatus) {
            return true;
        }
        
        // Define valid transitions
        switch (currentStatus) {
            case PENDING:
                return newStatus == Claim.ClaimStatus.UNDER_REVIEW || 
                       newStatus == Claim.ClaimStatus.VERIFIED || 
                       newStatus == Claim.ClaimStatus.REJECTED;
            case UNDER_REVIEW:
                return newStatus == Claim.ClaimStatus.VERIFIED || 
                       newStatus == Claim.ClaimStatus.REJECTED;
            case VERIFIED:
                // Once verified, cannot change status
                return false;
            case REJECTED:
                // Once rejected, cannot change status
                return false;
            default:
                return false;
        }
    }
    
    /**
     * Validate claim data.
     * 
     * @param claim the claim to validate
     * @throws IllegalArgumentException if claim data is invalid
     */
    private void validateClaim(Claim claim) {
        if (claim == null) {
            throw new IllegalArgumentException("Claim cannot be null");
        }
        if (claim.getMatchId() == null) {
            throw new IllegalArgumentException("Match ID cannot be null");
        }
        if (claim.getUserId() == null) {
            throw new IllegalArgumentException("User ID cannot be null");
        }
    }
}
