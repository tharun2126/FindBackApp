package com.findback.service;

import com.findback.model.User;

import java.util.List;
import java.util.Optional;

/**
 * Service interface for user-related business logic.
 * 
 * Defines the business operations for user management including
 * registration, authentication, and profile management.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public interface UserService {
    
    /**
     * Register a new user with the system.
     * 
     * @param user the user to register
     * @param plainPassword the plain text password (will be hashed)
     * @return the registered user with generated ID
     * @throws IllegalArgumentException if user data is invalid
     * @throws IllegalStateException if username or email already exists
     */
    User registerUser(User user, String plainPassword);
    
    /**
     * Authenticate a user with username and password.
     * 
     * @param username the username
     * @param plainPassword the plain text password
     * @return the authenticated user
     * @throws IllegalArgumentException if credentials are invalid
     * @throws com.findback.exception.AuthenticationException if authentication fails
     */
    User authenticateUser(String username, String plainPassword);
    
    /**
     * Find a user by ID.
     * 
     * @param userId the user ID
     * @return Optional containing the user if found
     */
    Optional<User> findUserById(Integer userId);
    
    /**
     * Find a user by username.
     * 
     * @param username the username
     * @return Optional containing the user if found
     */
    Optional<User> findUserByUsername(String username);
    
    /**
     * Find a user by email.
     * 
     * @param email the email
     * @return Optional containing the user if found
     */
    Optional<User> findUserByEmail(String email);
    
    /**
     * Update user profile information.
     * 
     * @param user the user to update
     * @return the updated user
     * @throws IllegalArgumentException if user data is invalid
     */
    User updateUser(User user);
    
    /**
     * Update user password.
     * 
     * @param userId the user ID
     * @param oldPassword the old plain text password
     * @param newPassword the new plain text password
     * @return true if password updated successfully
     * @throws IllegalArgumentException if passwords are invalid
     * @throws com.findback.exception.AuthenticationException if old password doesn't match
     */
    boolean updatePassword(Integer userId, String oldPassword, String newPassword);
    
    /**
     * Delete a user by ID.
     * 
     * @param userId the user ID to delete
     * @return true if deleted successfully
     */
    boolean deleteUser(Integer userId);
    
    /**
     * Get all users in the system.
     * 
     * @return list of all users
     */
    List<User> getAllUsers();
    
    /**
     * Check if a username already exists.
     * 
     * @param username the username to check
     * @return true if username exists, false otherwise
     */
    boolean usernameExists(String username);
    
    /**
     * Check if an email already exists.
     * 
     * @param email the email to check
     * @return true if email exists, false otherwise
     */
    boolean emailExists(String email);
}
