package com.findback.service;

import com.findback.model.Notification;

import java.util.List;
import java.util.Optional;

/**
 * Service interface for notification-related business logic.
 * 
 * Defines the business operations for in-app notification management.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public interface NotificationService {
    
    /**
     * Create a new notification for a user.
     * 
     * @param notification the notification to create
     * @return the created notification with generated ID
     * @throws IllegalArgumentException if notification data is invalid
     */
    Notification createNotification(Notification notification);
    
    /**
     * Create a notification with simplified parameters.
     * 
     * @param userId the user ID to receive the notification
     * @param title the notification title
     * @param message the notification message
     * @param type the notification type
     * @return the created notification
     */
    Notification createNotification(Integer userId, String title, String message, 
                                   Notification.NotificationType type);
    
    /**
     * Create a notification with related match ID.
     * 
     * @param userId the user ID to receive the notification
     * @param title the notification title
     * @param message the notification message
     * @param type the notification type
     * @param relatedMatchId the related match ID
     * @return the created notification
     */
    Notification createNotification(Integer userId, String title, String message, 
                                   Notification.NotificationType type, Integer relatedMatchId);
    
    /**
     * Update an existing notification.
     * 
     * @param notification the notification to update
     * @return the updated notification
     */
    Notification updateNotification(Notification notification);
    
    /**
     * Delete a notification by ID.
     * 
     * @param notificationId the notification ID to delete
     * @return true if deleted successfully
     */
    boolean deleteNotification(Integer notificationId);
    
    /**
     * Find a notification by ID.
     * 
     * @param notificationId the notification ID
     * @return Optional containing the notification if found
     */
    Optional<Notification> findNotificationById(Integer notificationId);
    
    /**
     * Get all notifications for a specific user.
     * 
     * @param userId the user ID
     * @return list of notifications for the user
     */
    List<Notification> getNotificationsByUser(Integer userId);
    
    /**
     * Get all unread notifications for a specific user.
     * 
     * @param userId the user ID
     * @return list of unread notifications for the user
     */
    List<Notification> getUnreadNotifications(Integer userId);
    
    /**
     * Mark a notification as read.
     * 
     * @param notificationId the notification ID
     * @return true if marked as read successfully
     */
    boolean markAsRead(Integer notificationId);
    
    /**
     * Mark all notifications as read for a specific user.
     * 
     * @param userId the user ID
     * @return the number of notifications marked as read
     */
    int markAllAsRead(Integer userId);
    
    /**
     * Get the count of unread notifications for a user.
     * 
     * @param userId the user ID
     * @return the count of unread notifications
     */
    int getUnreadCount(Integer userId);
}
