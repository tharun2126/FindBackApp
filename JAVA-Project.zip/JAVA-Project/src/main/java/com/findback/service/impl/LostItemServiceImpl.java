package com.findback.service.impl;

import com.findback.dao.LostItemDAO;
import com.findback.exception.DatabaseException;
import com.findback.model.LostItem;
import com.findback.service.LostItemService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Optional;

/**
 * Implementation of LostItemService interface.
 * 
 * Provides business logic for lost item management.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public class LostItemServiceImpl implements LostItemService {
    
    private static final Logger logger = LoggerFactory.getLogger(LostItemServiceImpl.class);
    
    private final LostItemDAO lostItemDAO;
    
    /**
     * Constructor with dependency injection.
     * 
     * @param lostItemDAO the LostItemDAO to use
     */
    public LostItemServiceImpl(LostItemDAO lostItemDAO) {
        this.lostItemDAO = lostItemDAO;
    }
    
    @Override
    public LostItem createLostItem(LostItem lostItem) {
        logger.debug("Creating lost item for user ID: {}", lostItem.getUserId());
        
        // Validate lost item data
        validateLostItem(lostItem);
        
        // Set default status if not set
        if (lostItem.getStatus() == null) {
            lostItem.setStatus(LostItem.ItemStatus.ACTIVE);
        }
        
        return lostItemDAO.save(lostItem);
    }
    
    @Override
    public LostItem updateLostItem(LostItem lostItem) {
        logger.debug("Updating lost item with ID: {}", lostItem.getLostItemId());
        
        // Validate lost item data
        validateLostItem(lostItem);
        
        // Ensure lost item ID is set
        if (lostItem.getLostItemId() == null) {
            throw new IllegalArgumentException("Lost item ID cannot be null for update");
        }
        
        // Check if lost item exists
        Optional<LostItem> existingItem = lostItemDAO.findById(lostItem.getLostItemId());
        if (existingItem.isEmpty()) {
            throw new IllegalArgumentException("Lost item not found with ID: " + lostItem.getLostItemId());
        }
        
        return lostItemDAO.update(lostItem);
    }
    
    @Override
    public boolean deleteLostItem(Integer lostItemId) {
        logger.debug("Deleting lost item with ID: {}", lostItemId);
        return lostItemDAO.delete(lostItemId);
    }
    
    @Override
    public Optional<LostItem> findLostItemById(Integer lostItemId) {
        logger.debug("Finding lost item by ID: {}", lostItemId);
        return lostItemDAO.findById(lostItemId);
    }
    
    @Override
    public List<LostItem> getLostItemsByUser(Integer userId) {
        logger.debug("Getting lost items for user ID: {}", userId);
        return lostItemDAO.findByUserId(userId);
    }
    
    @Override
    public List<LostItem> getActiveLostItems() {
        logger.debug("Getting all active lost items");
        return lostItemDAO.findActive();
    }
    
    @Override
    public List<LostItem> getLostItemsByCategory(String category) {
        logger.debug("Getting lost items by category: {}", category);
        return lostItemDAO.findByCategory(category);
    }
    
    @Override
    public boolean markAsResolved(Integer lostItemId) {
        logger.debug("Marking lost item as resolved: {}", lostItemId);
        
        Optional<LostItem> lostItemOptional = lostItemDAO.findById(lostItemId);
        if (lostItemOptional.isEmpty()) {
            throw new IllegalArgumentException("Lost item not found with ID: " + lostItemId);
        }
        
        LostItem lostItem = lostItemOptional.get();
        lostItem.setStatus(LostItem.ItemStatus.RESOLVED);
        lostItemDAO.update(lostItem);
        
        return true;
    }
    
    @Override
    public boolean markAsActive(Integer lostItemId) {
        logger.debug("Marking lost item as active: {}", lostItemId);
        
        Optional<LostItem> lostItemOptional = lostItemDAO.findById(lostItemId);
        if (lostItemOptional.isEmpty()) {
            throw new IllegalArgumentException("Lost item not found with ID: " + lostItemId);
        }
        
        LostItem lostItem = lostItemOptional.get();
        lostItem.setStatus(LostItem.ItemStatus.ACTIVE);
        lostItemDAO.update(lostItem);
        
        return true;
    }
    
    /**
     * Validate lost item data.
     * 
     * @param lostItem the lost item to validate
     * @throws IllegalArgumentException if lost item data is invalid
     */
    private void validateLostItem(LostItem lostItem) {
        if (lostItem == null) {
            throw new IllegalArgumentException("Lost item cannot be null");
        }
        if (lostItem.getUserId() == null) {
            throw new IllegalArgumentException("User ID cannot be null");
        }
        if (lostItem.getCategory() == null || lostItem.getCategory().trim().isEmpty()) {
            throw new IllegalArgumentException("Category cannot be null or empty");
        }
        if (lostItem.getDescription() == null || lostItem.getDescription().trim().isEmpty()) {
            throw new IllegalArgumentException("Description cannot be null or empty");
        }
        if (lostItem.getLocationLost() == null || lostItem.getLocationLost().trim().isEmpty()) {
            throw new IllegalArgumentException("Location lost cannot be null or empty");
        }
        if (lostItem.getDateLost() == null) {
            throw new IllegalArgumentException("Date lost cannot be null");
        }
    }
}
