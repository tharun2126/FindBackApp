package com.findback.service;

import com.findback.model.Claim;

import java.util.List;
import java.util.Optional;

/**
 * Service interface for claim-related business logic.
 * 
 * Defines the business operations for claim management including
 * submission, verification, and status tracking.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public interface ClaimService {
    
    /**
     * Create a new claim on a matched item.
     * 
     * @param claim the claim to create
     * @return the created claim with generated ID
     * @throws IllegalArgumentException if claim data is invalid
     */
    Claim createClaim(Claim claim);
    
    /**
     * Update an existing claim.
     * 
     * @param claim the claim to update
     * @return the updated claim
     * @throws IllegalArgumentException if claim data is invalid
     */
    Claim updateClaim(Claim claim);
    
    /**
     * Delete a claim by ID.
     * 
     * @param claimId the claim ID to delete
     * @return true if deleted successfully
     */
    boolean deleteClaim(Integer claimId);
    
    /**
     * Find a claim by ID.
     * 
     * @param claimId the claim ID
     * @return Optional containing the claim if found
     */
    Optional<Claim> findClaimById(Integer claimId);
    
    /**
     * Get all claims for a specific user.
     * 
     * @param userId the user ID
     * @return list of claims for the user
     */
    List<Claim> getClaimsByUser(Integer userId);
    
    /**
     * Get all claims for a specific match.
     * 
     * @param matchId the match ID
     * @return list of claims for the match
     */
    List<Claim> getClaimsByMatch(Integer matchId);
    
    /**
     * Get all claims with a specific status.
     * 
     * @param status the claim status
     * @return list of claims with the status
     */
    List<Claim> getClaimsByStatus(Claim.ClaimStatus status);
    
    /**
     * Update claim status with admin verification.
     * 
     * @param claimId the claim ID
     * @param newStatus the new status
     * @param adminId the admin user ID performing the verification
     * @param verificationNotes optional verification notes
     * @return the updated claim
     * @throws IllegalArgumentException if parameters are invalid
     */
    Claim updateClaimStatus(Integer claimId, Claim.ClaimStatus newStatus, 
                            Integer adminId, String verificationNotes);
    
    /**
     * Check if a claim status transition is valid.
     * 
     * @param currentStatus the current status
     * @param newStatus the proposed new status
     * @return true if the transition is valid
     */
    boolean isValidStatusTransition(Claim.ClaimStatus currentStatus, Claim.ClaimStatus newStatus);
}
