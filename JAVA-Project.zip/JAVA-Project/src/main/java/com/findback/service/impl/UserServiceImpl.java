package com.findback.service.impl;

import com.findback.dao.UserDAO;
import com.findback.exception.AuthenticationException;
import com.findback.exception.DatabaseException;
import com.findback.model.User;
import com.findback.service.UserService;
import com.findback.util.PasswordUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Optional;

/**
 * Implementation of UserService interface.
 * 
 * Provides business logic for user management including registration,
 * authentication, and profile management.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public class UserServiceImpl implements UserService {
    
    private static final Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);
    
    private final UserDAO userDAO;
    
    /**
     * Constructor with dependency injection.
     * 
     * @param userDAO the UserDAO to use
     */
    public UserServiceImpl(UserDAO userDAO) {
        this.userDAO = userDAO;
    }
    
    @Override
    public User registerUser(User user, String plainPassword) {
        logger.debug("Registering new user: {}", user.getUsername());
        
        // Validate user data
        validateUser(user);
        validatePassword(plainPassword);
        
        // Check if username already exists
        if (usernameExists(user.getUsername())) {
            throw new IllegalStateException("Username already exists: " + user.getUsername());
        }
        
        // Check if email already exists
        if (emailExists(user.getEmail())) {
            throw new IllegalStateException("Email already exists: " + user.getEmail());
        }
        
        // Hash the password
        String hashedPassword = PasswordUtil.hashPassword(plainPassword);
        user.setPasswordHash(hashedPassword);
        
        // Save user
        return userDAO.save(user);
    }
    
    @Override
    public User authenticateUser(String username, String plainPassword) {
        logger.debug("Authenticating user: {}", username);
        
        // Validate input
        if (username == null || username.trim().isEmpty()) {
            throw new IllegalArgumentException("Username cannot be null or empty");
        }
        if (plainPassword == null || plainPassword.trim().isEmpty()) {
            throw new IllegalArgumentException("Password cannot be null or empty");
        }
        
        // Find user by username
        Optional<User> userOptional = userDAO.findByUsername(username);
        if (userOptional.isEmpty()) {
            throw new AuthenticationException("Invalid username or password");
        }
        
        User user = userOptional.get();
        
        // Verify password
        if (!PasswordUtil.verifyPassword(plainPassword, user.getPasswordHash())) {
            throw new AuthenticationException("Invalid username or password");
        }
        
        logger.info("User authenticated successfully: {}", username);
        return user;
    }
    
    @Override
    public Optional<User> findUserById(Integer userId) {
        logger.debug("Finding user by ID: {}", userId);
        return userDAO.findById(userId);
    }
    
    @Override
    public Optional<User> findUserByUsername(String username) {
        logger.debug("Finding user by username: {}", username);
        return userDAO.findByUsername(username);
    }
    
    @Override
    public Optional<User> findUserByEmail(String email) {
        logger.debug("Finding user by email: {}", email);
        return userDAO.findByEmail(email);
    }
    
    @Override
    public User updateUser(User user) {
        logger.debug("Updating user: {}", user.getUsername());
        
        // Validate user data
        validateUser(user);
        
        // Ensure user ID is set
        if (user.getUserId() == null) {
            throw new IllegalArgumentException("User ID cannot be null for update");
        }
        
        // Check if user exists
        Optional<User> existingUser = userDAO.findById(user.getUserId());
        if (existingUser.isEmpty()) {
            throw new IllegalArgumentException("User not found with ID: " + user.getUserId());
        }
        
        // If username/email is being changed, check for conflicts
        User existing = existingUser.get();
        if (!existing.getUsername().equals(user.getUsername()) && usernameExists(user.getUsername())) {
            throw new IllegalStateException("Username already exists: " + user.getUsername());
        }
        if (!existing.getEmail().equals(user.getEmail()) && emailExists(user.getEmail())) {
            throw new IllegalStateException("Email already exists: " + user.getEmail());
        }
        
        // Preserve password hash if not being changed
        if (user.getPasswordHash() == null || user.getPasswordHash().isEmpty()) {
            user.setPasswordHash(existing.getPasswordHash());
        }
        
        return userDAO.update(user);
    }
    
    @Override
    public boolean updatePassword(Integer userId, String oldPassword, String newPassword) {
        logger.debug("Updating password for user ID: {}", userId);
        
        // Validate input
        if (userId == null) {
            throw new IllegalArgumentException("User ID cannot be null");
        }
        validatePassword(oldPassword);
        validatePassword(newPassword);
        
        // Find user
        Optional<User> userOptional = userDAO.findById(userId);
        if (userOptional.isEmpty()) {
            throw new IllegalArgumentException("User not found with ID: " + userId);
        }
        
        User user = userOptional.get();
        
        // Verify old password
        if (!PasswordUtil.verifyPassword(oldPassword, user.getPasswordHash())) {
            throw new AuthenticationException("Old password is incorrect");
        }
        
        // Hash new password and update
        String hashedNewPassword = PasswordUtil.hashPassword(newPassword);
        user.setPasswordHash(hashedNewPassword);
        
        userDAO.update(user);
        logger.info("Password updated successfully for user ID: {}", userId);
        return true;
    }
    
    @Override
    public boolean deleteUser(Integer userId) {
        logger.debug("Deleting user with ID: {}", userId);
        return userDAO.delete(userId);
    }
    
    @Override
    public List<User> getAllUsers() {
        logger.debug("Getting all users");
        return userDAO.findAll();
    }
    
    @Override
    public boolean usernameExists(String username) {
        return userDAO.findByUsername(username).isPresent();
    }
    
    @Override
    public boolean emailExists(String email) {
        return userDAO.findByEmail(email).isPresent();
    }
    
    /**
     * Validate user data.
     * 
     * @param user the user to validate
     * @throws IllegalArgumentException if user data is invalid
     */
    private void validateUser(User user) {
        if (user == null) {
            throw new IllegalArgumentException("User cannot be null");
        }
        if (user.getUsername() == null || user.getUsername().trim().isEmpty()) {
            throw new IllegalArgumentException("Username cannot be null or empty");
        }
        if (user.getEmail() == null || user.getEmail().trim().isEmpty()) {
            throw new IllegalArgumentException("Email cannot be null or empty");
        }
        if (user.getFullName() == null || user.getFullName().trim().isEmpty()) {
            throw new IllegalArgumentException("Full name cannot be null or empty");
        }
        if (user.getRole() == null) {
            throw new IllegalArgumentException("Role cannot be null");
        }
        
        // Basic email validation
        if (!user.getEmail().contains("@") || !user.getEmail().contains(".")) {
            throw new IllegalArgumentException("Invalid email format");
        }
    }
    
    /**
     * Validate password.
     * 
     * @param password the password to validate
     * @throws IllegalArgumentException if password is invalid
     */
    private void validatePassword(String password) {
        if (password == null || password.trim().isEmpty()) {
            throw new IllegalArgumentException("Password cannot be null or empty");
        }
        if (password.length() < 6) {
            throw new IllegalArgumentException("Password must be at least 6 characters long");
        }
    }
}
