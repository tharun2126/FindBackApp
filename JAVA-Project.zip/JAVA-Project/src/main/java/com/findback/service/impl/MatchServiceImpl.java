package com.findback.service.impl;

import com.findback.ai.MatchingEngine;
import com.findback.dao.FoundItemDAO;
import com.findback.dao.LostItemDAO;
import com.findback.dao.MatchDAO;
import com.findback.exception.DatabaseException;
import com.findback.model.FoundItem;
import com.findback.model.LostItem;
import com.findback.model.Match;
import com.findback.service.MatchService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

/**
 * Implementation of MatchService interface.
 * 
 * Provides business logic for AI-generated match management.
 * This service receives AI-generated scores from the AI/ML layer.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public class MatchServiceImpl implements MatchService {
    
    private static final Logger logger = LoggerFactory.getLogger(MatchServiceImpl.class);
    
    private final MatchDAO matchDAO;
    private final LostItemDAO lostItemDAO;
    private final FoundItemDAO foundItemDAO;
    private final MatchingEngine matchingEngine;
    
    /**
     * Constructor with dependency injection (without AI engine).
     * 
     * @param matchDAO the MatchDAO to use
     */
    public MatchServiceImpl(MatchDAO matchDAO) {
        this.matchDAO = matchDAO;
        this.lostItemDAO = null;
        this.foundItemDAO = null;
        this.matchingEngine = null;
    }
    
    /**
     * Constructor with dependency injection (with AI engine).
     * 
     * @param matchDAO the MatchDAO to use
     * @param lostItemDAO the LostItemDAO to use
     * @param foundItemDAO the FoundItemDAO to use
     * @param matchingEngine the MatchingEngine to use
     */
    public MatchServiceImpl(MatchDAO matchDAO, LostItemDAO lostItemDAO, 
                          FoundItemDAO foundItemDAO, MatchingEngine matchingEngine) {
        this.matchDAO = matchDAO;
        this.lostItemDAO = lostItemDAO;
        this.foundItemDAO = foundItemDAO;
        this.matchingEngine = matchingEngine;
    }
    
    @Override
    public Match saveMatch(Match match) {
        logger.debug("Saving match between lost item {} and found item {}", 
                    match.getLostItemId(), match.getFoundItemId());
        
        // Validate match data
        validateMatch(match);
        
        // Validate similarity scores
        if (!validateMatchScores(match.getSemanticSimilarityScore(), 
                                match.getImageSimilarityScore(),
                                match.getAttributeSimilarityScore(),
                                match.getOverallConfidenceScore())) {
            throw new IllegalArgumentException("Invalid match scores");
        }
        
        // Set default status if not set
        if (match.getMatchStatus() == null) {
            match.setMatchStatus(Match.MatchStatus.PENDING);
        }
        
        return matchDAO.save(match);
    }
    
    @Override
    public Match updateMatch(Match match) {
        logger.debug("Updating match with ID: {}", match.getMatchId());
        
        // Validate match data
        validateMatch(match);
        
        // Ensure match ID is set
        if (match.getMatchId() == null) {
            throw new IllegalArgumentException("Match ID cannot be null for update");
        }
        
        // Check if match exists
        Optional<Match> existingMatch = matchDAO.findById(match.getMatchId());
        if (existingMatch.isEmpty()) {
            throw new IllegalArgumentException("Match not found with ID: " + match.getMatchId());
        }
        
        // Validate similarity scores if provided
        if (match.getOverallConfidenceScore() != null) {
            if (!validateMatchScores(match.getSemanticSimilarityScore(), 
                                    match.getImageSimilarityScore(),
                                    match.getAttributeSimilarityScore(),
                                    match.getOverallConfidenceScore())) {
                throw new IllegalArgumentException("Invalid match scores");
            }
        }
        
        return matchDAO.update(match);
    }
    
    @Override
    public boolean deleteMatch(Integer matchId) {
        logger.debug("Deleting match with ID: {}", matchId);
        return matchDAO.delete(matchId);
    }
    
    @Override
    public Optional<Match> findMatchById(Integer matchId) {
        logger.debug("Finding match by ID: {}", matchId);
        return matchDAO.findById(matchId);
    }
    
    @Override
    public List<Match> getMatchesByLostItem(Integer lostItemId) {
        logger.debug("Getting matches for lost item ID: {}", lostItemId);
        return matchDAO.findByLostItemId(lostItemId);
    }
    
    @Override
    public List<Match> getMatchesByFoundItem(Integer foundItemId) {
        logger.debug("Getting matches for found item ID: {}", foundItemId);
        return matchDAO.findByFoundItemId(foundItemId);
    }
    
    @Override
    public List<Match> getHighConfidenceMatches(double threshold) {
        logger.debug("Getting high confidence matches with threshold: {}", threshold);
        
        // Validate threshold
        if (threshold < 0.0 || threshold > 1.0) {
            throw new IllegalArgumentException("Threshold must be between 0.0 and 1.0");
        }
        
        return matchDAO.findHighConfidenceMatches(threshold);
    }
    
    @Override
    public boolean updateMatchStatus(Integer matchId, Match.MatchStatus status) {
        logger.debug("Updating match {} status to: {}", matchId, status);
        
        if (matchId == null) {
            throw new IllegalArgumentException("Match ID cannot be null");
        }
        if (status == null) {
            throw new IllegalArgumentException("Status cannot be null");
        }
        
        Optional<Match> matchOptional = matchDAO.findById(matchId);
        if (matchOptional.isEmpty()) {
            throw new IllegalArgumentException("Match not found with ID: " + matchId);
        }
        
        Match match = matchOptional.get();
        match.setMatchStatus(status);
        matchDAO.update(match);
        
        return true;
    }
    
    @Override
    public boolean validateMatchScores(BigDecimal semanticScore, BigDecimal imageScore, 
                                       BigDecimal attributeScore, BigDecimal overallScore) {
        // Overall score is required
        if (overallScore == null) {
            return false;
        }
        
        // Overall score must be between 0 and 1
        if (overallScore.compareTo(BigDecimal.ZERO) < 0 || overallScore.compareTo(BigDecimal.ONE) > 0) {
            return false;
        }
        
        // Individual scores are optional but must be valid if provided
        if (semanticScore != null) {
            if (semanticScore.compareTo(BigDecimal.ZERO) < 0 || semanticScore.compareTo(BigDecimal.ONE) > 0) {
                return false;
            }
        }
        
        if (imageScore != null) {
            if (imageScore.compareTo(BigDecimal.ZERO) < 0 || imageScore.compareTo(BigDecimal.ONE) > 0) {
                return false;
            }
        }
        
        if (attributeScore != null) {
            if (attributeScore.compareTo(BigDecimal.ZERO) < 0 || attributeScore.compareTo(BigDecimal.ONE) > 0) {
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * Validate match data.
     * 
     * @param match the match to validate
     * @throws IllegalArgumentException if match data is invalid
     */
    private void validateMatch(Match match) {
        if (match == null) {
            throw new IllegalArgumentException("Match cannot be null");
        }
        if (match.getLostItemId() == null) {
            throw new IllegalArgumentException("Lost item ID cannot be null");
        }
        if (match.getFoundItemId() == null) {
            throw new IllegalArgumentException("Found item ID cannot be null");
        }
    }
    
    /**
     * Trigger AI matching for a newly reported found item.
     * 
     * This method compares the found item with all active lost items,
     * calculates similarity scores, and saves significant matches.
     * 
     * @param foundItemId the ID of the newly reported found item
     * @return number of matches created
     */
    @Override
    public int triggerMatchingForFoundItem(Integer foundItemId) {
        if (matchingEngine == null || lostItemDAO == null || foundItemDAO == null) {
            logger.warn("Matching engine or DAOs not initialized, cannot trigger matching");
            return 0;
        }
        
        logger.info("Triggering AI matching for found item ID: {}", foundItemId);
        
        try {
            // Get the found item
            Optional<FoundItem> foundItemOptional = foundItemDAO.findById(foundItemId);
            if (foundItemOptional.isEmpty()) {
                logger.warn("Found item not found with ID: {}", foundItemId);
                return 0;
            }
            
            FoundItem foundItem = foundItemOptional.get();
            
            // Get all active lost items
            List<LostItem> activeLostItems = lostItemDAO.findActive();
            logger.debug("Found {} active lost items to compare against", activeLostItems.size());
            
            // Calculate matches
            List<Match> matches = matchingEngine.findMatches(foundItem, activeLostItems);
            logger.info("Generated {} potential matches", matches.size());
            
            // Save matches (avoiding duplicates)
            int matchesSaved = 0;
            for (Match match : matches) {
                if (!matchExists(match.getLostItemId(), match.getFoundItemId())) {
                    saveMatch(match);
                    matchesSaved++;
                    logger.debug("Saved match with confidence: {}", match.getOverallConfidenceScore());
                } else {
                    logger.debug("Match already exists for lost item {} and found item {}", 
                               match.getLostItemId(), match.getFoundItemId());
                }
            }
            
            logger.info("Matching complete. {} new matches saved for found item {}", 
                       matchesSaved, foundItemId);
            return matchesSaved;
            
        } catch (Exception e) {
            logger.error("Error triggering matching for found item: {}", foundItemId, e);
            return 0;
        }
    }
    
    /**
     * Trigger AI matching for a newly reported lost item.
     * 
     * This method compares the lost item with all active found items,
     * calculates similarity scores, and saves significant matches.
     * 
     * @param lostItemId the ID of the newly reported lost item
     * @return number of matches created
     */
    @Override
    public int triggerMatchingForLostItem(Integer lostItemId) {
        if (matchingEngine == null || lostItemDAO == null || foundItemDAO == null) {
            logger.warn("Matching engine or DAOs not initialized, cannot trigger matching");
            return 0;
        }
        
        logger.info("Triggering AI matching for lost item ID: {}", lostItemId);
        
        try {
            // Get the lost item
            Optional<LostItem> lostItemOptional = lostItemDAO.findById(lostItemId);
            if (lostItemOptional.isEmpty()) {
                logger.warn("Lost item not found with ID: {}", lostItemId);
                return 0;
            }
            
            LostItem lostItem = lostItemOptional.get();
            
            // Get all active found items
            List<FoundItem> activeFoundItems = foundItemDAO.findActive();
            logger.debug("Found {} active found items to compare against", activeFoundItems.size());
            
            // Calculate matches
            List<Match> matches = matchingEngine.findMatches(lostItem, activeFoundItems);
            logger.info("Generated {} potential matches", matches.size());
            
            // Save matches (avoiding duplicates)
            int matchesSaved = 0;
            for (Match match : matches) {
                if (!matchExists(match.getLostItemId(), match.getFoundItemId())) {
                    saveMatch(match);
                    matchesSaved++;
                    logger.debug("Saved match with confidence: {}", match.getOverallConfidenceScore());
                } else {
                    logger.debug("Match already exists for lost item {} and found item {}", 
                               match.getLostItemId(), match.getFoundItemId());
                }
            }
            
            logger.info("Matching complete. {} new matches saved for lost item {}", 
                       matchesSaved, lostItemId);
            return matchesSaved;
            
        } catch (Exception e) {
            logger.error("Error triggering matching for lost item: {}", lostItemId, e);
            return 0;
        }
    }
    
    /**
     * Check if a match already exists between a lost item and found item.
     * 
     * @param lostItemId the lost item ID
     * @param foundItemId the found item ID
     * @return true if match exists, false otherwise
     */
    private boolean matchExists(Integer lostItemId, Integer foundItemId) {
        List<Match> existingMatches = matchDAO.findByLostItemId(lostItemId);
        for (Match match : existingMatches) {
            if (match.getFoundItemId().equals(foundItemId)) {
                return true;
            }
        }
        return false;
    }
}
