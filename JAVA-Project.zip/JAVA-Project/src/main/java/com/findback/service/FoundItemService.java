package com.findback.service;

import com.findback.model.FoundItem;

import java.util.List;
import java.util.Optional;

/**
 * Service interface for found item-related business logic.
 * 
 * Defines the business operations for found item management including
 * reporting, updating, and retrieving found items.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public interface FoundItemService {
    
    /**
     * Create a new found item report.
     * 
     * @param foundItem the found item to report
     * @return the created found item with generated ID
     * @throws IllegalArgumentException if found item data is invalid
     */
    FoundItem createFoundItem(FoundItem foundItem);
    
    /**
     * Update an existing found item.
     * 
     * @param foundItem the found item to update
     * @return the updated found item
     * @throws IllegalArgumentException if found item data is invalid
     */
    FoundItem updateFoundItem(FoundItem foundItem);
    
    /**
     * Delete a found item by ID.
     * 
     * @param foundItemId the found item ID to delete
     * @return true if deleted successfully
     */
    boolean deleteFoundItem(Integer foundItemId);
    
    /**
     * Find a found item by ID.
     * 
     * @param foundItemId the found item ID
     * @return Optional containing the found item if found
     */
    Optional<FoundItem> findFoundItemById(Integer foundItemId);
    
    /**
     * Get all found items for a specific user.
     * 
     * @param userId the user ID
     * @return list of found items for the user
     */
    List<FoundItem> getFoundItemsByUser(Integer userId);
    
    /**
     * Get all active found items in the system.
     * 
     * @return list of active found items
     */
    List<FoundItem> getActiveFoundItems();
    
    /**
     * Get found items by category.
     * 
     * @param category the category
     * @return list of found items in the category
     */
    List<FoundItem> getFoundItemsByCategory(String category);
    
    /**
     * Mark a found item as resolved.
     * 
     * @param foundItemId the found item ID
     * @return true if marked as resolved successfully
     */
    boolean markAsResolved(Integer foundItemId);
    
    /**
     * Mark a found item as active.
     * 
     * @param foundItemId the found item ID
     * @return true if marked as active successfully
     */
    boolean markAsActive(Integer foundItemId);
}
