package com.findback.service.impl;

import com.findback.dao.NotificationDAO;
import com.findback.exception.DatabaseException;
import com.findback.model.Notification;
import com.findback.service.NotificationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Optional;

/**
 * Implementation of NotificationService interface.
 * 
 * Provides business logic for in-app notification management.
 * 
 * @author FindBack Team
 * @version 1.0.0
 */
public class NotificationServiceImpl implements NotificationService {
    
    private static final Logger logger = LoggerFactory.getLogger(NotificationServiceImpl.class);
    
    private final NotificationDAO notificationDAO;
    
    /**
     * Constructor with dependency injection.
     * 
     * @param notificationDAO the NotificationDAO to use
     */
    public NotificationServiceImpl(NotificationDAO notificationDAO) {
        this.notificationDAO = notificationDAO;
    }
    
    @Override
    public Notification createNotification(Notification notification) {
        logger.debug("Creating notification for user ID: {}", notification.getUserId());
        
        // Validate notification data
        validateNotification(notification);
        
        // Set default read status if not set
        if (notification.isRead()) {
            notification.setRead(false);
        }
        
        return notificationDAO.save(notification);
    }
    
    @Override
    public Notification createNotification(Integer userId, String title, String message, 
                                          Notification.NotificationType type) {
        logger.debug("Creating notification for user ID: {}", userId);
        
        Notification notification = new Notification(userId, title, message, type);
        return createNotification(notification);
    }
    
    @Override
    public Notification createNotification(Integer userId, String title, String message, 
                                          Notification.NotificationType type, Integer relatedMatchId) {
        logger.debug("Creating notification for user ID: {} with related match: {}", userId, relatedMatchId);
        
        Notification notification = new Notification(userId, title, message, type, relatedMatchId);
        return createNotification(notification);
    }
    
    @Override
    public Notification updateNotification(Notification notification) {
        logger.debug("Updating notification with ID: {}", notification.getNotificationId());
        
        // Validate notification data
        validateNotification(notification);
        
        // Ensure notification ID is set
        if (notification.getNotificationId() == null) {
            throw new IllegalArgumentException("Notification ID cannot be null for update");
        }
        
        // Check if notification exists
        Optional<Notification> existingNotification = notificationDAO.findById(notification.getNotificationId());
        if (existingNotification.isEmpty()) {
            throw new IllegalArgumentException("Notification not found with ID: " + notification.getNotificationId());
        }
        
        return notificationDAO.update(notification);
    }
    
    @Override
    public boolean deleteNotification(Integer notificationId) {
        logger.debug("Deleting notification with ID: {}", notificationId);
        return notificationDAO.delete(notificationId);
    }
    
    @Override
    public Optional<Notification> findNotificationById(Integer notificationId) {
        logger.debug("Finding notification by ID: {}", notificationId);
        return notificationDAO.findById(notificationId);
    }
    
    @Override
    public List<Notification> getNotificationsByUser(Integer userId) {
        logger.debug("Getting notifications for user ID: {}", userId);
        return notificationDAO.findByUserId(userId);
    }
    
    @Override
    public List<Notification> getUnreadNotifications(Integer userId) {
        logger.debug("Getting unread notifications for user ID: {}", userId);
        return notificationDAO.findUnread(userId);
    }
    
    @Override
    public boolean markAsRead(Integer notificationId) {
        logger.debug("Marking notification as read: {}", notificationId);
        return notificationDAO.markAsRead(notificationId);
    }
    
    @Override
    public int markAllAsRead(Integer userId) {
        logger.debug("Marking all notifications as read for user ID: {}", userId);
        
        List<Notification> unreadNotifications = notificationDAO.findUnread(userId);
        int markedCount = 0;
        
        for (Notification notification : unreadNotifications) {
            if (notificationDAO.markAsRead(notification.getNotificationId())) {
                markedCount++;
            }
        }
        
        logger.info("Marked {} notifications as read for user ID: {}", markedCount, userId);
        return markedCount;
    }
    
    @Override
    public int getUnreadCount(Integer userId) {
        logger.debug("Getting unread count for user ID: {}", userId);
        return notificationDAO.findUnread(userId).size();
    }
    
    /**
     * Validate notification data.
     * 
     * @param notification the notification to validate
     * @throws IllegalArgumentException if notification data is invalid
     */
    private void validateNotification(Notification notification) {
        if (notification == null) {
            throw new IllegalArgumentException("Notification cannot be null");
        }
        if (notification.getUserId() == null) {
            throw new IllegalArgumentException("User ID cannot be null");
        }
        if (notification.getTitle() == null || notification.getTitle().trim().isEmpty()) {
            throw new IllegalArgumentException("Title cannot be null or empty");
        }
        if (notification.getMessage() == null || notification.getMessage().trim().isEmpty()) {
            throw new IllegalArgumentException("Message cannot be null or empty");
        }
        if (notification.getNotificationType() == null) {
            throw new IllegalArgumentException("Notification type cannot be null");
        }
    }
}
