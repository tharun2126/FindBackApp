package com.findback.ai.impl;

import com.findback.ai.SemanticSimilarityService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for SemanticSimilarityService.
 * 
 * Tests TF-IDF vectorization and cosine similarity calculations.
 */
class SemanticSimilarityTest {
    
    private SemanticSimilarityService semanticSimilarityService;
    
    @BeforeEach
    void setUp() {
        semanticSimilarityService = new SemanticSimilarityServiceImpl();
    }
    
    @Test
    void testIdenticalDescriptions_ShouldReturnHighSimilarity() {
        String text1 = "black leather wallet with silver zipper";
        String text2 = "black leather wallet with silver zipper";
        
        double similarity = semanticSimilarityService.calculateSimilarity(text1, text2);
        
        assertTrue(similarity >= 0.0 && similarity <= 1.0, "Similarity should be between 0 and 1");
        // Identical descriptions should have high similarity (TF-IDF may not be exactly 1.0 due to normalization)
        assertTrue(similarity > 0.8, "Identical descriptions should have very high similarity");
    }
    
    @Test
    void testVerySimilarDescriptions_ShouldReturnHighSimilarity() {
        String text1 = "black leather wallet with silver zipper";
        String text2 = "black leather wallet silver zipper";
        
        double similarity = semanticSimilarityService.calculateSimilarity(text1, text2);
        
        assertTrue(similarity >= 0.0 && similarity <= 1.0, "Similarity should be between 0 and 1");
        // Very similar descriptions should have high similarity
        assertTrue(similarity > 0.5, "Very similar descriptions should have high similarity");
    }
    
    @Test
    void testPartiallySimilarDescriptions_ShouldReturnMediumSimilarity() {
        String text1 = "black leather wallet with silver zipper";
        String text2 = "brown leather bag with gold clasp";
        
        double similarity = semanticSimilarityService.calculateSimilarity(text1, text2);
        
        assertTrue(similarity >= 0.0 && similarity <= 1.0, "Similarity should be between 0 and 1");
        assertTrue(similarity < 0.7, "Partially similar descriptions should have medium similarity");
    }
    
    @Test
    void testUnrelatedDescriptions_ShouldReturnLowSimilarity() {
        String text1 = "black leather wallet with silver zipper";
        String text2 = "red bicycle with mountain tires";
        
        double similarity = semanticSimilarityService.calculateSimilarity(text1, text2);
        
        assertTrue(similarity >= 0.0 && similarity <= 1.0, "Similarity should be between 0 and 1");
        assertTrue(similarity < 0.3, "Unrelated descriptions should have low similarity");
    }
    
    @Test
    void testNullTexts_ShouldReturnZero() {
        double similarity = semanticSimilarityService.calculateSimilarity(null, null);
        
        assertEquals(0.0, similarity, "Null texts should return 0.0");
    }
    
    @Test
    void testOneNullText_ShouldReturnZero() {
        String text1 = "black leather wallet";
        double similarity = semanticSimilarityService.calculateSimilarity(text1, null);
        
        assertEquals(0.0, similarity, "One null text should return 0.0");
    }
    
    @Test
    void testEmptyTexts_ShouldReturnZero() {
        double similarity = semanticSimilarityService.calculateSimilarity("", "");
        
        assertEquals(0.0, similarity, "Empty texts should return 0.0");
    }
    
    @Test
    void testTextNormalization_ShouldHandleCase() {
        String text1 = "BLACK LEATHER WALLET";
        String text2 = "black leather wallet";
        
        double similarity = semanticSimilarityService.calculateSimilarity(text1, text2);
        
        // Case differences should be normalized (should be high similarity)
        assertTrue(similarity > 0.8, "Case differences should be normalized");
    }
    
    @Test
    void testTextNormalization_ShouldHandlePunctuation() {
        String text1 = "black leather, wallet!";
        String text2 = "black leather wallet";
        
        double similarity = semanticSimilarityService.calculateSimilarity(text1, text2);
        
        // Punctuation should be normalized (should be high similarity)
        assertTrue(similarity > 0.8, "Punctuation should be normalized");
    }
    
    @Test
    void testNormalizeText() {
        String input = "Hello, World! This is a TEST.";
        String normalized = semanticSimilarityService.normalizeText(input);
        
        assertEquals("hello world this is a test", normalized, "Text should be normalized");
    }
}
