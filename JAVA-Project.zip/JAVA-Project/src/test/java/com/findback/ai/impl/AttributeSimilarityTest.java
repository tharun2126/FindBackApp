package com.findback.ai.impl;

import com.findback.ai.AttributeSimilarityService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for AttributeSimilarityService.
 * 
 * Tests weighted attribute comparison.
 */
class AttributeSimilarityTest {
    
    private AttributeSimilarityService attributeSimilarityService;
    
    @BeforeEach
    void setUp() {
        attributeSimilarityService = new AttributeSimilarityServiceImpl();
    }
    
    @Test
    void testMatchingAllAttributes_ShouldReturnHighSimilarity() {
        double similarity = attributeSimilarityService.calculateSimilarity(
            "wallet", "leather", "black", "library", LocalDateTime.now(),
            "wallet", "leather", "black", "library", LocalDateTime.now()
        );
        
        assertTrue(similarity > 0.9, "Matching all attributes should return high similarity");
    }
    
    @Test
    void testMatchingCategoryOnly_ShouldReturnMediumSimilarity() {
        double similarity = attributeSimilarityService.calculateSimilarity(
            "wallet", "leather", "black", "library", LocalDateTime.now(),
            "wallet", "canvas", "brown", "park", LocalDateTime.now().plusDays(1)
        );
        
        assertTrue(similarity >= 0.3 && similarity <= 0.6, "Matching only category should return medium similarity");
    }
    
    @Test
    void testNoMatchingAttributes_ShouldReturnLowSimilarity() {
        double similarity = attributeSimilarityService.calculateSimilarity(
            "wallet", "leather", "black", "library", LocalDateTime.now(),
            "bicycle", "metal", "red", "park", LocalDateTime.now().plusDays(10)
        );
        
        assertTrue(similarity >= 0.0 && similarity <= 0.3, "No matching attributes should return low similarity");
    }
    
    @Test
    void testExactCategoryMatch_ShouldContributeStrongly() {
        double similarity1 = attributeSimilarityService.calculateSimilarity(
            "wallet", null, null, null, null,
            "wallet", null, null, null, null
        );
        
        double similarity2 = attributeSimilarityService.calculateSimilarity(
            "wallet", null, null, null, null,
            "phone", null, null, null, null
        );
        
        assertTrue(similarity1 > similarity2, "Exact category match should contribute strongly");
    }
    
    @Test
    void testBrandMatch_ShouldContributeStrongly() {
        double similarity1 = attributeSimilarityService.calculateSimilarity(
            null, "gucci", null, null, null,
            null, "gucci", null, null, null
        );
        
        double similarity2 = attributeSimilarityService.calculateSimilarity(
            null, "gucci", null, null, null,
            null, "prada", null, null, null
        );
        
        assertTrue(similarity1 > similarity2, "Brand match should contribute strongly");
    }
    
    @Test
    void testMissingOptionalAttributes_ShouldNotCrash() {
        double similarity = attributeSimilarityService.calculateSimilarity(
            "wallet", null, null, "library", LocalDateTime.now(),
            "wallet", null, null, "library", LocalDateTime.now()
        );
        
        assertTrue(similarity >= 0.0 && similarity <= 1.0, "Missing optional attributes should not crash");
    }
    
    @Test
    void testSameDate_ShouldReturnHighScore() {
        LocalDateTime now = LocalDateTime.now();
        double similarity = attributeSimilarityService.calculateSimilarity(
            null, null, null, null, now,
            null, null, null, null, now
        );
        
        // Same date should contribute to overall score (date weight is 10%)
        assertTrue(similarity >= 0.0 && similarity <= 1.0, "Same date should return valid score");
    }
    
    @Test
    void testDifferentDates_ShouldReturnLowerScore() {
        LocalDateTime date1 = LocalDateTime.now();
        LocalDateTime date2 = LocalDateTime.now().plusDays(20);
        
        double similarity = attributeSimilarityService.calculateSimilarity(
            null, null, null, null, date1,
            null, null, null, null, date2
        );
        
        assertTrue(similarity >= 0.0 && similarity <= 1.0, "Different dates should return valid score");
    }
    
    @Test
    void testVeryDifferentDates_ShouldReturnLowScore() {
        LocalDateTime date1 = LocalDateTime.now();
        LocalDateTime date2 = LocalDateTime.now().plusDays(40);
        
        double similarity = attributeSimilarityService.calculateSimilarity(
            "wallet", "gucci", "black", null, date1,
            "wallet", "gucci", "black", null, date2
        );
        
        // Very different dates should return low score (beyond 30 day threshold)
        // With matching category/brand/colour, but very different dates, score should be reduced
        assertTrue(similarity < 0.8, "Very different dates should reduce the score");
    }
    
    @Test
    void testSameLocation_ShouldReturnHighScore() {
        double similarity = attributeSimilarityService.calculateSimilarity(
            null, null, null, "central library", null,
            null, null, null, "central library", null
        );
        
        // Same location should contribute to overall score (location weight is 15%)
        assertTrue(similarity >= 0.0 && similarity <= 1.0, "Same location should return valid score");
    }
    
    @Test
    void testSimilarLocation_ShouldReturnMediumScore() {
        double similarity = attributeSimilarityService.calculateSimilarity(
            null, null, null, "central library", null,
            null, null, null, "library", null
        );
        
        // Similar location should contribute to overall score
        assertTrue(similarity >= 0.0 && similarity <= 1.0, "Similar location should return valid score");
    }
    
    @Test
    void testNullValues_ShouldHandleGracefully() {
        double similarity = attributeSimilarityService.calculateSimilarity(
            null, null, null, null, null,
            null, null, null, null, null
        );
        
        assertTrue(similarity >= 0.0 && similarity <= 1.0, "Null values should be handled gracefully");
    }
}
