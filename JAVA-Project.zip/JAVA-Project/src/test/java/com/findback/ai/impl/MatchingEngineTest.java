package com.findback.ai.impl;

import com.findback.ai.AttributeSimilarityService;
import com.findback.ai.ImageSimilarityService;
import com.findback.ai.MatchingEngine;
import com.findback.ai.SemanticSimilarityService;
import com.findback.model.FoundItem;
import com.findback.model.LostItem;
import com.findback.model.Match;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for MatchingEngine.
 * 
 * Tests weighted combination of similarity scores.
 */
class MatchingEngineTest {
    
    private MatchingEngine matchingEngine;
    private SemanticSimilarityService semanticSimilarityService;
    private ImageSimilarityService imageSimilarityService;
    private AttributeSimilarityService attributeSimilarityService;
    
    @BeforeEach
    void setUp() {
        semanticSimilarityService = new SemanticSimilarityServiceImpl();
        imageSimilarityService = new ImageSimilarityServiceImpl();
        attributeSimilarityService = new AttributeSimilarityServiceImpl();
        
        matchingEngine = new MatchingEngineImpl(
            semanticSimilarityService,
            imageSimilarityService,
            attributeSimilarityService
        );
    }
    
    @Test
    void testCalculateMatch_ShouldReturnValidMatch() {
        LostItem lostItem = createTestLostItem(1);
        FoundItem foundItem = createTestFoundItem(1);
        
        Match match = matchingEngine.calculateMatch(lostItem, foundItem);
        
        assertNotNull(match, "Match should not be null");
        assertEquals(lostItem.getLostItemId(), match.getLostItemId());
        assertEquals(foundItem.getFoundItemId(), match.getFoundItemId());
        assertNotNull(match.getOverallConfidenceScore());
        assertEquals(Match.MatchStatus.PENDING, match.getMatchStatus());
    }
    
    @Test
    void testWeightedFormula_ShouldCalculateCorrectly() {
        // Create items with known similarities
        LostItem lostItem = createTestLostItem(1);
        FoundItem foundItem = createTestFoundItem(1);
        
        // Make them identical for maximum similarity
        lostItem.setDescription("black leather wallet");
        foundItem.setDescription("black leather wallet");
        lostItem.setCategory("wallet");
        foundItem.setCategory("wallet");
        lostItem.setBrand("gucci");
        foundItem.setBrand("gucci");
        lostItem.setColour("black");
        foundItem.setColour("black");
        lostItem.setLocationLost("library");
        foundItem.setLocationFound("library");
        lostItem.setDateLost(LocalDateTime.now());
        foundItem.setDateFound(LocalDateTime.now());
        
        Match match = matchingEngine.calculateMatch(lostItem, foundItem);
        
        // With identical items but no images, overall confidence should still be reasonably high
        // (semantic + attribute = 60% max, so expect around 0.5-0.6)
        assertTrue(match.getOverallConfidenceScore().doubleValue() > 0.4, 
                   "Identical items should have reasonable overall confidence even without images");
    }
    
    @Test
    void testFindMatches_ShouldFilterByThreshold() {
        FoundItem foundItem = createTestFoundItem(1);
        List<LostItem> lostItems = Arrays.asList(
            createTestLostItem(1),
            createTestLostItem(2),
            createTestLostItem(3)
        );
        
        List<Match> matches = matchingEngine.findMatches(foundItem, lostItems);
        
        assertNotNull(matches, "Matches should not be null");
        // All matches should be above threshold
        for (Match match : matches) {
            assertTrue(match.getOverallConfidenceScore().doubleValue() >= matchingEngine.getMatchingThreshold(),
                       "All matches should be above threshold");
        }
    }
    
    @Test
    void testThresholds_ShouldBeConfigurable() {
        double matchingThreshold = matchingEngine.getMatchingThreshold();
        double notificationThreshold = matchingEngine.getNotificationThreshold();
        
        assertTrue(matchingThreshold >= 0.0 && matchingThreshold <= 1.0, 
                   "Matching threshold should be between 0 and 1");
        assertTrue(notificationThreshold >= 0.0 && notificationThreshold <= 1.0, 
                   "Notification threshold should be between 0 and 1");
        assertTrue(notificationThreshold > matchingThreshold, 
                   "Notification threshold should be higher than matching threshold");
    }
    
    @Test
    void testScores_ShouldBeBetweenZeroAndOne() {
        LostItem lostItem = createTestLostItem(1);
        FoundItem foundItem = createTestFoundItem(1);
        
        Match match = matchingEngine.calculateMatch(lostItem, foundItem);
        
        if (match.getSemanticSimilarityScore() != null) {
            assertTrue(match.getSemanticSimilarityScore().doubleValue() >= 0.0 && 
                       match.getSemanticSimilarityScore().doubleValue() <= 1.0,
                       "Semantic score should be between 0 and 1");
        }
        
        if (match.getImageSimilarityScore() != null) {
            assertTrue(match.getImageSimilarityScore().doubleValue() >= 0.0 && 
                       match.getImageSimilarityScore().doubleValue() <= 1.0,
                       "Image score should be between 0 and 1");
        }
        
        if (match.getAttributeSimilarityScore() != null) {
            assertTrue(match.getAttributeSimilarityScore().doubleValue() >= 0.0 && 
                       match.getAttributeSimilarityScore().doubleValue() <= 1.0,
                       "Attribute score should be between 0 and 1");
        }
        
        assertTrue(match.getOverallConfidenceScore().doubleValue() >= 0.0 && 
                   match.getOverallConfidenceScore().doubleValue() <= 1.0,
                   "Overall score should be between 0 and 1");
    }
    
    @Test
    void testMissingImages_ShouldNotCrash() {
        LostItem lostItem = createTestLostItem(1);
        FoundItem foundItem = createTestFoundItem(1);
        
        lostItem.setImagePath(null);
        foundItem.setImagePath(null);
        
        Match match = matchingEngine.calculateMatch(lostItem, foundItem);
        
        assertNotNull(match, "Match should not be null even without images");
        assertNotNull(match.getOverallConfidenceScore(), "Overall score should still be calculated");
    }
    
    /**
     * Create a test lost item.
     */
    private LostItem createTestLostItem(int id) {
        LostItem item = new LostItem();
        item.setLostItemId(id);
        item.setUserId(1);
        item.setCategory("wallet");
        item.setBrand("gucci");
        item.setColour("black");
        item.setDescription("black leather wallet with silver zipper");
        item.setLocationLost("central library");
        item.setDateLost(LocalDateTime.now());
        item.setImagePath(null);
        item.setStatus(LostItem.ItemStatus.ACTIVE);
        return item;
    }
    
    /**
     * Create a test found item.
     */
    private FoundItem createTestFoundItem(int id) {
        FoundItem item = new FoundItem();
        item.setFoundItemId(id);
        item.setUserId(2);
        item.setCategory("wallet");
        item.setBrand("gucci");
        item.setColour("black");
        item.setDescription("black leather wallet with silver zipper");
        item.setLocationFound("central library");
        item.setDateFound(LocalDateTime.now());
        item.setImagePath(null);
        item.setStatus(FoundItem.ItemStatus.ACTIVE);
        return item;
    }
}
