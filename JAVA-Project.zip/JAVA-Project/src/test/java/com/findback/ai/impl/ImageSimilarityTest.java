package com.findback.ai.impl;

import com.findback.ai.ImageSimilarityService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import javax.imageio.ImageIO;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for ImageSimilarityService.
 * 
 * Tests color histogram extraction and comparison.
 */
class ImageSimilarityTest {
    
    private ImageSimilarityService imageSimilarityService;
    
    @BeforeEach
    void setUp() {
        imageSimilarityService = new ImageSimilarityServiceImpl();
    }
    
    @Test
    void testIdenticalImages_ShouldReturnHighSimilarity() {
        BufferedImage image1 = createTestImage(Color.RED);
        BufferedImage image2 = createTestImage(Color.RED);
        
        double similarity = imageSimilarityService.calculateSimilarity(image1, image2);
        
        assertTrue(similarity > 0.9, "Identical images should have very high similarity");
        assertEquals(1.0, similarity, 0.01, "Identical images should return 1.0");
    }
    
    @Test
    void testSimilarColorImages_ShouldReturnHighSimilarity() {
        BufferedImage image1 = createTestImage(Color.RED);
        BufferedImage image2 = createTestImage(new Color(255, 0, 10)); // Slightly different red
        
        double similarity = imageSimilarityService.calculateSimilarity(image1, image2);
        
        assertTrue(similarity >= 0.0 && similarity <= 1.0, "Similarity should be between 0 and 1");
        // Similar color images should have reasonably high similarity (histogram binning may affect exact score)
        assertTrue(similarity > 0.5, "Similar color images should have reasonably high similarity");
    }
    
    @Test
    void testDifferentColorImages_ShouldReturnLowerSimilarity() {
        BufferedImage image1 = createTestImage(Color.RED);
        BufferedImage image2 = createTestImage(Color.BLUE);
        
        double similarity = imageSimilarityService.calculateSimilarity(image1, image2);
        
        assertTrue(similarity >= 0.0 && similarity <= 1.0, "Similarity should be between 0 and 1");
        assertTrue(similarity < 0.5, "Different color images should have lower similarity");
    }
    
    @Test
    void testNullImages_ShouldReturnZero() {
        double similarity = imageSimilarityService.calculateSimilarity((BufferedImage) null, (BufferedImage) null);
        
        assertEquals(0.0, similarity, "Null images should return 0.0");
    }
    
    @Test
    void testOneNullImage_ShouldReturnZero() {
        BufferedImage image1 = createTestImage(Color.RED);
        double similarity = imageSimilarityService.calculateSimilarity(image1, (BufferedImage) null);
        
        assertEquals(0.0, similarity, "One null image should return 0.0");
    }
    
    @Test
    void testInvalidFilePaths_ShouldReturnZero() {
        double similarity = imageSimilarityService.calculateSimilarity("nonexistent.jpg", "nonexistent2.jpg");
        
        assertEquals(0.0, similarity, "Invalid file paths should return 0.0");
    }
    
    @Test
    void testNullFilePaths_ShouldReturnZero() {
        double similarity = imageSimilarityService.calculateSimilarity((String) null, (String) null);
        
        assertEquals(0.0, similarity, "Null file paths should return 0.0");
    }
    
    @Test
    void testEmptyFilePaths_ShouldReturnZero() {
        double similarity = imageSimilarityService.calculateSimilarity("", "");
        
        assertEquals(0.0, similarity, "Empty file paths should return 0.0");
    }
    
    /**
     * Create a test image with a solid color.
     */
    private BufferedImage createTestImage(Color color) {
        BufferedImage image = new BufferedImage(100, 100, BufferedImage.TYPE_INT_RGB);
        for (int x = 0; x < 100; x++) {
            for (int y = 0; y < 100; y++) {
                image.setRGB(x, y, color.getRGB());
            }
        }
        return image;
    }
}
