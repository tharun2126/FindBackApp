# FindBack: AI-Powered Lost-and-Found Item Matching System

## Overview

FindBack is a standalone desktop application built with Java Swing that uses AI-powered image and semantic similarity analysis to match lost items with found items. The system provides a comprehensive platform for users to report lost or found items, receive AI-generated match suggestions, and manage the claim and verification process.

## Features

### User Features
- User registration and login
- Report lost items with image upload
- Report found items with image upload
- View own lost and found item reports
- AI-powered item matching with confidence scores
- In-app notifications for potential matches
- Claim matched items
- Track claim status and ownership verification
- View returned items

### Admin Features
- Admin login
- System dashboard with statistics
- View and manage users
- View all lost and found items
- Review AI-generated matches
- Verify or reject ownership claims
- Mark items as returned
- Manage reports

### AI/ML Features
- Semantic text similarity analysis using TF-IDF and cosine similarity
- Image similarity analysis using color histogram comparison
- Attribute-based similarity (category, brand, colour, location, date/time)
- Combined confidence score calculation
- Automatic match generation and notification

## Technology Stack

- **Language**: Java 21
- **Build Tool**: Maven
- **GUI Framework**: Java Swing
- **Database**: MySQL 8.0+
- **Database Access**: JDBC with DAO pattern
- **Password Hashing**: BCrypt
- **Logging**: SLF4J + Logback
- **Image Processing**: ImageJ
- **Utilities**: Apache Commons Lang, Apache Commons IO

## Project Structure

```
findback/
├── pom.xml
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── com/
│   │   │       └── findback/
│   │   │           ├── FindBackApp.java
│   │   │           ├── config/
│   │   │           ├── model/
│   │   │           ├── dao/
│   │   │           ├── service/
│   │   │           ├── controller/
│   │   │           ├── ui/
│   │   │           ├── ai/
│   │   │           ├── util/
│   │   │           └── exception/
│   │   └── resources/
│   │       ├── config.properties
│   │       └── db/
│   │           └── schema.sql
│   └── test/
│       └── java/
└── README.md
```

## Prerequisites

- Java Development Kit (JDK) 21 or higher
- Maven 3.8 or higher
- MySQL 8.0 or higher
- IDE (IntelliJ IDEA, Eclipse, or NetBeans)

## Database Setup

1. Create a MySQL database named `findback`:
   ```sql
   CREATE DATABASE findback;
   ```

2. Execute the schema file to create tables:
   ```bash
   mysql -u root -p findback < src/main/resources/db/schema.sql
   ```

3. Update database credentials in `src/main/resources/config.properties`:
   ```properties
   db.url=jdbc:mysql://localhost:3306/findback
   db.username=your_username
   db.password=your_password
   ```

## Building the Project

```bash
mvn clean install
```

## Running the Application

### From Maven
```bash
mvn exec:java -Dexec.mainClass="com.findback.FindBackApp"
```

### From JAR
```bash
java -jar target/findback-1.0.0.jar
```

### From IDE
Run the `FindBackApp.java` main class.

## Default Admin Credentials

- **Username**: admin
- **Password**: admin123

⚠️ **Important**: Change the default admin password after first login.

## Configuration

Edit `src/main/resources/config.properties` to customize:

- Database connection settings
- AI matching thresholds
- Image upload settings
- Logging configuration

## Architecture

The application follows a clean layered architecture:

```
UI Layer (Swing)
    ↓
Controller Layer
    ↓
Service Layer (Business Logic)
    ↓
AI/ML Service Layer
    ↓
DAO Layer (Data Access)
    ↓
JDBC
    ↓
MySQL Database
```

## Development Phases

- **Phase 1**: Maven project setup, package structure, configuration, database schema ✅
- **Phase 2**: Model classes, DAO interfaces and implementations
- **Phase 3**: Service layer and business logic
- **Phase 4**: AI/ML services (semantic and image similarity)
- **Phase 5**: Controller layer
- **Phase 6**: UI layer (Swing frames and panels)
- **Phase 7**: Integration and testing

## License

This is an academic project for Java Programming coursework.

## Authors

FindBack Development Team

## Version

1.0.0
